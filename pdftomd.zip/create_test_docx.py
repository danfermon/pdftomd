from docx import Document

def create_test_docx():
    doc = Document()
    
    doc.add_heading('Teste de Paginação', 0)
    doc.add_paragraph('Este é o conteúdo da primeira página.')
    
    # Adiciona quebra de página
    doc.add_page_break()
    
    doc.add_heading('Página 2', level=1)
    doc.add_paragraph('Este é o conteúdo da segunda página.')
    
    # Adiciona outra quebra de página
    doc.add_page_break()
    
    doc.add_heading('Página 3', level=1)
    doc.add_paragraph('Este é o conteúdo da terceira página.')
    
    doc.save('test_pagination.docx')
    print("Arquivo 'test_pagination.docx' criado com sucesso.")

if __name__ == "__main__":
    create_test_docx()
