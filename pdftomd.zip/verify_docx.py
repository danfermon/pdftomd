from pdf_detector import extract_structured_markitdown
import os

def verify_pagination():
    input_file = "test_pagination.docx"
    output_file = "test_pagination_output.md"
    
    if os.path.exists(output_file):
        os.remove(output_file)
        
    print(f"Processando {input_file}...")
    extract_structured_markitdown(input_file, output_file)
    
    if os.path.exists(output_file):
        with open(output_file, "r", encoding="utf-8") as f:
            content = f.read()
            print("\n--- Conteúdo do Arquivo Gerado ---")
            print(content)
            print("----------------------------------")
            
            if "## PÁGINA 2" in content and "## PÁGINA 3" in content:
                print("SUCESSO: Marcadores de página encontrados!")
            else:
                print("FALHA: Marcadores de página NÃO encontrados.")
    else:
        print("Erro: Arquivo de saída não foi gerado.")

if __name__ == "__main__":
    verify_pagination()
