

## Página 1

05/06/2019                                                   Analisador de Talhão - Minhas Operações

                                Minhas Operações

  2019 Milho Seco: Colheita                                                    6,7
   Camada: Zonas de Rendimento Líquido                                             AGROSERVICE | CARROLL FARMS





                                                         Dados cartográ¦cos ©2019 Imagens ©2019 CNES / Airbus, DigitalGlobe
  Datas de Operação: 15/03/2019 - 03/05/2019

   DADOS AGRONÔMICOS                                                       LEGENDA
   PESO LÍQUIDO        PESO BRUTO MÉDIO
    2.165,23 t              7,07 t/ha                                                                  9,22          11 %
   PESO LÍQUIDO MÉDIO                                                                                13 %                                                                                                     8,36
    6,91 t/ha
                                                                                                      14 %
   UMIDADE MÉDIA                                                                                 7,42
    16,03 %                                                                                            16 %                                                                                                     6,53
   VELOCIDADE MÉDIA                                                                                  20 %                                                                                                     5,72    5,65 km/h
                                                                                                      16 %   ÁREA TRABALHADA                                                                               4,78
    313,47 ha                                                                                          10 %                                                                                           0
   PESO BRUTO
    2.215,67 t

  Copyright © 2011-2019 Deere & Company. Todos os direitos reservados.





https://my.deere.com/map#fieldAnalyzer?overview=829d6a10-33ea-47c1-ad74-3d2afac85892&print=                                               1/1
