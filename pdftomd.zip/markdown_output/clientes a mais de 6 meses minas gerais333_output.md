

## Página 1

Pág. 1 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF


018584  HUMBERTO TOMAZ PEREIRA ME                 Rua Tiradentes                       250   Centro                            38540000 - ABADIA DOS DOURADOS - MG
Fantasia:   BAZAR DOS PRESENTES                            CNPJ/CPF:   25.426.933/0001-76      Rep: 21.496     Insc Estad:   0015221820048        Telefone:    (34) 3847-1334           E-mail:
E-mail NF-e:     humberto.tomas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003110  SAPATARIA DA CIDADE ABAETE LTDA - EPP        MARECHAL DEODORO                 308   CENTRO                          35620000 - ABAETE - MG
Fantasia:    SAPATARIA DA CIDADE ABAETE LTD                  CNPJ/CPF:   20.109.385/0001-37      Rep: 21.564     Insc Estad:   0020782660029        Telefone:    (37)3541-1705            E-mail:
E-mail NF-e:     sapatariadacidadeabaete@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     15/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000500  ZELMA CORDEIRO MACHADO DE ABREU           GETULIO VARGAS                    245   CENTRO                          35620000 - ABAETE - MG
Fantasia:   ZELMA CORDEIRO MACHADO DE ABRE                CNPJ/CPF:   64.385.875/0001-31      Rep: 21.564     Insc Estad:   0021432580000        Telefone:    (37)3541-3065            E-mail:
E-mail NF-e:     palaciodoscalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009523  SANDRA QUEIROZ FERREIRA MORENO - ME        RUA DR CUSTODIO DE PAULA RODRIGUES 22    CENTRO                          35365000 - ABRE CAMPO - MG
Fantasia:   SANDRA QUEIROZ FERREIRA MORENO                CNPJ/CPF:   20.009.292/0001-30      Rep: 22.619     Insc Estad:   0023368420089        Telefone:    (31)99175-5532           E-mail:
E-mail NF-e:     sandraqferreira@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005834  REINALDO GOMES CARNEIRO ME               ADAO ROLIM                        75    CENTRO                          35438000 - ACAIACA - MG
Fantasia:    REINALDO GOMES CARNEIRO ME                    CNPJ/CPF:   05.334.969/0001-12      Rep: 22.619     Insc Estad:   0042039910018        Telefone:    (37)3887-1433            E-mail:
E-mail NF-e:     denilson2106@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019293  LOJA NOVO LAR RESPLENDOR LTDA                 Br mg 120 ao lado do posto Zema        S/N    Resplendor                        39790000 - AGUA BOA - MG
Fantasia:    LOJA NOVO LAR RESPLENDOR LTDA                  CNPJ/CPF:   04.275.403/0001-02      Rep: 22.751     Insc Estad:   006.116.386/0085      Telefone:    (31) 98840-8858          E-mail:
E-mail NF-e:     lojanovolar@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019291  MM ULTILIDADES E PAPELARIA LTDA              Rua Darci Alves de Oliveira             185 A  Centro                            39790000 - AGUA BOA - MG
Fantasia:   MM ULTILIDADES E PAPELARIA LTD                  CNPJ/CPF:   05.401.284/0001-41      Rep: 22.751     Insc Estad:   006.217.202/0052      Telefone:    (33) 3515-1399           E-mail:
E-mail NF-e:     mmpapelaria@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021172  RG CASA LOPES LTDA                          Rua Jose Godinho Sobrinho             94     Centro                            39790000 - AGUA BOA - MG
Fantasia:   R G CASA LOPES                                   CNPJ/CPF:   31.872.887/0001-31      Rep: 22.751     Insc Estad:   0033056010047        Telefone:    (38) 3521-1262           E-mail:
E-mail NF-e:     casalopesaguaboa@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021425  DOUGLAS DAMASCENO JACINTO                 Rua Herbron                         30     Betel                             35200000 - AIMORÉS - MG
Fantasia:   SANDRINHA CALCADOS                             CNPJ/CPF:   53.180.712/0001-04      Rep: 22.751     Insc Estad:   47785910049           Telefone:    (33) 99148-8855          E-mail:
E-mail NF-e:     sandrinha198715@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019493  LOJA E SAPATARIA RIQUINHO LTDA ME              Praça Presidente Vargas                72     Porto novo                        36660000 - ALÉM PARAÍBA - MG
Fantasia:    LOJA DO RIQUINHO                                CNPJ/CPF:   68.500.966/0001-21      Rep: 13.734     Insc Estad:   0158193860070        Telefone:    (32) 3462-7793           E-mail:
E-mail NF-e:     hpcontabilidade4315@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005431  ALFENAS CALCADOS LTDA - LJ 111             CONEGO JOSÉ CARLOS                180   CENTRO                          37130000 - ALFENAS - MG
Fantasia:    ALFENAS CALCADOS LTDA - LJ 111                   CNPJ/CPF:   09.165.949/0001-16      Rep: 21.564     Insc Estad:   0010498910040        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003450  JOSE EDUARDO PEREIRA - ME                   GETULIO VARGAS                    130   CENTRO                          37130000 - ALFENAS - MG
Fantasia:    JOSE EDUARDO PEREIRA - ME                       CNPJ/CPF:   01.205.078/0001-05      Rep: 21.564     Insc Estad:   0169697070014        Telefone:    (35)8802-3246            E-mail:
E-mail NF-e:     korppus@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022257  KALCE BEM COMERCIO LTDA                   RUA JUSCELINO BARBOSA              1613  CENTRO                          37130000 - ALFENAS - MG
Fantasia:    KALCE BEM                                       CNPJ/CPF:   35.851.440/0001-37      Rep: 21.564     Insc Estad:   0036305080070        Telefone:    (35) 98829-0541          E-mail:
E-mail NF-e:     kalcebem@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 2

Pág. 2 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

013648  RCL COMERCIO DE CALCADOS ROUPAS E ACESSORIO Rua João de Souza Sobrinho            524    Vila Betânia                       37137086 - ALFENAS - MG
Fantasia:    RCL COMERCIO DE CALCADOS, ROUP                 CNPJ/CPF:   26.075.663/0001-69      Rep: 21.564     Insc Estad:   0166459190044        Telefone:    (35)98058-8664           E-mail:
E-mail NF-e:     regiscalcados1@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011526  SIREMA VAREJISTA LTDA                       PCA GETULIO VARGAS                 152   CENTRO                          37130000 - ALFENAS - MG
Fantasia:    SIREMA VAREJISTA LTDA                           CNPJ/CPF:   01.424.176/0001-33      Rep: 21.564     Insc Estad:   0167420420074        Telefone:    (35)3292-4877            E-mail:
E-mail NF-e:     difatto_alfenas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011525  SOARES E OLIVEIRA LTDA                    RUA CONEGO JOSÉ CARLOS 167 LOJA   01    CENTRO                          37130000 - ALFENAS - MG
Fantasia:   SOARES E OLIVEIRA LTDA                          CNPJ/CPF:   08.802.729/0001-93      Rep: 21.564     Insc Estad:   0010340010070        Telefone:    (35)3292-4866            E-mail:
E-mail NF-e:     difatto.center@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021141  ALMENARA COMERCIO DE CONF E ACESSORIOS LTDA AV OLINDO DE MIRANDA               33    CENTRO                          39900000 - ALMENARA - MG
Fantasia:    almenara                                         CNPJ/CPF:   07.041.176/0001-30      Rep: 3.471      Insc Estad:   173160840040         Telefone:    (33) 98711-1911          E-mail:
E-mail NF-e:    bcboacompra@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020930  MARILENE SOUSA PORTO                       Rua hermano de sousa                301A  Centro                            39900000 - ALMENARA - MG
Fantasia:   MARY SHOES                                      CNPJ/CPF:   42.466.792/0001-34      Rep: 22.941     Insc Estad:   40789760045           Telefone:    (33) 98824-0854          E-mail:
E-mail NF-e:     marilene4429@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004038  TELLES CALCADOS LTDA                      RUA PROFESSOR TELLES               240   SÃO BENEDITO                     37940000 - ALPINÓPOLIS - MG
Fantasia:    TELLES CALCADOS LTDA                            CNPJ/CPF:   04.590.909/0001-06      Rep: 21.564     Insc Estad:   0191397530071        Telefone:    (35)3523-2083            E-mail:
E-mail NF-e:     tellescalcados2011@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003594  ANA MARIA PEREIRA TERRA FALONI OLIVEIRA - EPP  BENEDITO VALADARES                289   CENTRO                          37145000 - ALTEROSA - MG
Fantasia:   ANA MARIA PEREIRA TERRA FALONI                  CNPJ/CPF:   03.989.294/0001-14      Rep: 21.564     Insc Estad:   0200931530012        Telefone:    (35)3294-1639            E-mail:
E-mail NF-e:     anamaria_loja@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016018  CASA MARTINS LTDA                        RUA MARECHAL DEODORO DA FONSECA  91    CENTRO                          37145000 - ALTEROSA - MG
Fantasia:   CASA MARTINS                                    CNPJ/CPF:   19.698.901/0001-27      Rep: 21.564     Insc Estad:   020058250.0083       Telefone:    (35)3294-1009            E-mail:
E-mail NF-e:    CASAMARTINSALT@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     19/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

000481  ZAORI CALCADOS LTDA - ME                    BENEDITO VALADARES                138   CENTRO                          37145000 - ALTEROSA - MG
Fantasia:    ZAORI CALCADOS LTDA - ME                        CNPJ/CPF:   18.030.275/0001-33      Rep: 21.564     Insc Estad:   0021406630047        Telefone:    (35)3294-1231            E-mail:
E-mail NF-e:     zaoricalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019536  COMERCIO DE CALCADOS LILIRTES MACHADO LTDA  Avenida Padre Jose Marciano            382   Centro                            35950000 - ALVINÓPOLIS - MG
Fantasia:   OPCAO CALCADOS                                 CNPJ/CPF:   02.531.389/0001-27      Rep: 13.734     Insc Estad:   239400000061         Telefone:    (31) 3855-1174           E-mail:
E-mail NF-e:     liliamodas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009155   MIL DICAS LTDA - ME                        RUA MONSENHOR BICALHO             236   CENTRO                          35950000 - ALVINÓPOLIS - MG
Fantasia:    MIL DICAS LTDA - ME                              CNPJ/CPF:   23.178.874/0001-39      Rep: 13.734     Insc Estad:   0235223710076        Telefone:    (31)3855-1188            E-mail:
E-mail NF-e:     facota1@hotmail.com; mildicasltda@hotmai

     Obs.:                                                           Proprietário :

Data Última Compra:     04/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000512  SAMON LTDA - EPP                          MAJOR PANTALEAO                   68    CENTRO                          37795000 - ANDRADAS - MG
Fantasia:   SAMON LTDA - EPP                                 CNPJ/CPF:   23.167.885/0001-13      Rep: 21.564     Insc Estad:   0265392040086        Telefone:    (35)3731-1261            E-mail:
E-mail NF-e:     samon@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006828  LUCIANO ANDRADE ALEXANDRE ME               GABRIEL RIBEIRO SALGADO 25 - LOJA   SN   CENTRO                          37300000 - ANDRELÂNDIA - MG
Fantasia:    LUCIANO ANDRADE ALEXANDRE ME                  CNPJ/CPF:   15.745.247/0001-04      Rep: 21.564     Insc Estad:   0019818100042        Telefone:    (35)3325-1486            E-mail:
E-mail NF-e:     keilacalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     29/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 3

Pág. 3 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021210  MARIA EDIRLENE DA SILVA MOREIRA               Avenida vicente pego                  260   Centro                            39685000 - ANGELÂNDIA - MG
Fantasia:    DI LINDA'S LINGERíE                               CNPJ/CPF:   24.523.156/0001-15      Rep: 22.941     Insc Estad:   0027372220084        Telefone:    (33) 98872-9281          E-mail:
E-mail NF-e:     dilindaslingere@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022072  MARTA APARECIDA GOMES                      Rua militao                          10a    Centro                            39685000 - ANGELÂNDIA - MG
Fantasia:   MARTA                                           CNPJ/CPF:   55.775.061/0001-12      Rep: 22.941     Insc Estad:   49327920015           Telefone:    (33) 8849-6062           E-mail:
E-mail NF-e:     spmarta@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018299  KATIA BERGAMASCHINE DA FONSECA LIMA         Rua Silvio Frizzoni                    152   Centro                            36220000 - ANTÔNIO CARLOS - MG
Fantasia:   PASSO A PASSO                                   CNPJ/CPF:   16.568.970/0001-28      Rep: 13.734     Insc Estad:   0020010920048        Telefone:    (32) 98801-8902          E-mail:
E-mail NF-e:     kbergaf@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/12/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

019517  MARTINHA REIS SA                            Rua Presidente Vargas                 95     Centro                            35177000 - ANTÔNIO DIAS - MG
Fantasia:   MARTINHA VARIEDADES                            CNPJ/CPF:   04.703.504/0001-29      Rep: 22.751     Insc Estad:   301.478.250/083       Telefone:    (31) 3843-1033           E-mail:
E-mail NF-e:     martinhavariedades@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011554  ARA CALCADOS E CONFECCOES LTDA            RUA JOSÉ ANTONIO ARAUJO            190   ALTO MERCADO                    39600000 - ARAÇUAÍ - MG
Fantasia:   ARA CALCADOS E CONFECCOES LTDA                 CNPJ/CPF:   23.466.635/0001-84      Rep: 22.036     Insc Estad:   0026433650082        Telefone:    (38)91044-4997           E-mail:
E-mail NF-e:     impactomodas10@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018603  CAUSAR MODAS LTDA                          Rua frei rogato                       192    Alto do mercado                    39600000 - ARAÇUAÍ - MG
Fantasia:   CAUSAR MODAS LTDA                              CNPJ/CPF:   45.984.595/0001-03      Rep: 22.036     Insc Estad:   0043158460025        Telefone:    (33) 99956-9898          E-mail:
E-mail NF-e:     causarmodas22@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005935  ELIANE ALMEIDA SILVA MARINHO ME               FREI ROGATO                        302   CENTRO                          39600000 - ARAÇUAÍ - MG
Fantasia:    ELIANE ALMEIDA SILVA MARINHO M                  CNPJ/CPF:   08.052.660/0001-28      Rep: 22.036     Insc Estad:   0010082180091        Telefone:    (33)3731-1736            E-mail:
E-mail NF-e:     geraldommarinho@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022322  KENNEDY SILVA MURTA                      R JOSE ANTONIO ARAUJO              681   VILA MAGNOLIA                    39600000 - ARAÇUAÍ - MG
Fantasia:   KENNEDY CALÇADOS                               CNPJ/CPF:   14.287.827/0001-32      Rep: 22.036     Insc Estad:                            Telefone:    (33) 98862-7028          E-mail:
E-mail NF-e:    kennedy.cm@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

000523  MATEUS MARINHO DE SOUZA - ME              CORONEL MANOEL FULGENCIO          278   CENTRO                          39600000 - ARAÇUAÍ - MG
Fantasia:   MATEUS MARINHO DE SOUZA - ME                   CNPJ/CPF:   22.152.029/0001-21      Rep: 22.036     Insc Estad:   345.223.740/089       Telefone:    (33)3731-1123            E-mail:
E-mail NF-e:     esportesmarinho2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009248  EDNEI JOSE MONTES - ME                     AV SENADOR MELO VIANA             201   GOIAS                            38442192 - ARAGUARI - MG
Fantasia:    EDNEI JOSE MONTES - ME                          CNPJ/CPF:   03.547.134/0001-15      Rep: 21.496     Insc Estad:   0350563440044        Telefone:    (34)3241-1626            E-mail:
E-mail NF-e:     novaeraconfeccoes@terra.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011543   RITA GRACIANA ROSSI SILVA MONTES           RUA COROMANDEL                   876   AMORIM                          38446093 - ARAGUARI - MG
Fantasia:    RITA GRACIANA ROSSI SILVA MONT                  CNPJ/CPF:   07.625.853/0001-68      Rep: 21.496     Insc Estad:   0353862860080        Telefone:    (34)3246-3246            E-mail:
E-mail NF-e:     novaeraconfeccoes@terra.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021006  ROSI MODA PRAIA LTDA                        Rua Vereador Joao Veloso              1195   Industrial                         38442019 - ARAGUARI - MG
Fantasia:    ROSI MODA PRAIA                                 CNPJ/CPF:   19.208.777/0001-74      Rep: 21.496     Insc Estad:   22573190021           Telefone:    (34) 9988-9405           E-mail:
E-mail NF-e:     rosipraia.44@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015658  SAPATARIA ARAGUARI LTDA ME                RUA AFONSO PENA                   594   CENTRO                          38440118 - ARAGUARI - MG
Fantasia:    SAPATARIA ARAGUARI                              CNPJ/CPF:   10.886.665/0001-06      Rep: 21.496     Insc Estad:   0012209370060        Telefone:    (34)3242-8855            E-mail:
E-mail NF-e:    SAPATARIAARAGUARI@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 4

Pág. 4 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003758  MARIETA E JEFERSON ROUPAS E CALCADOS LTDA   RUA ULYSSES FERNANDES             119   CENTRO                          37360000 - ARANTINA - MG
Fantasia:    MARIETA E JEFERSON ROUPAS E CA                  CNPJ/CPF:   86.462.249/0001-34      Rep: 21.564     Insc Estad:   0368816240096        Telefone:    (32)3296-1359            E-mail:
E-mail NF-e:     lojadamarieta@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020972   CIA DO CONFORTO CALCADOS LTDA              Rua Presidente Olegario Maciel          176 B/CCentro                            38183186 - ARAXÁ - MG
Fantasia:    VILA CALCADOS                                   CNPJ/CPF:   34.885.790/0001-51      Rep: 21.496     Insc Estad:   0035455620088        Telefone:    (37) 3027-1498           E-mail:
E-mail NF-e:    compras2g3v@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022284  COMERCIAL DE CALCADOS VIEIRA LTDA          R PRESIDENTE OLEGARIO MACIEL       120   CENTRO                          38183186 - ARAXÁ - MG
Fantasia:    LINKS CALCADOS                                  CNPJ/CPF:   09.452.973/0001-36      Rep: 21.496     Insc Estad:   0010653860048        Telefone:    (34) 3662-4263           E-mail:
E-mail NF-e:     linkscalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

013821  DUARTE E DUARTE LTDA                      RUA PRESIDENTE OLEGARIO MACIEL     353   CENTRO                          38183186 - ARAXÁ - MG
Fantasia:   DUARTE E DUARTE LTDA                            CNPJ/CPF:   20.599.055/0001-77      Rep: 21.496     Insc Estad:   0023895780049        Telefone:    (34)3661-1680            E-mail:
E-mail NF-e:    CALCADOSDUARTE2@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     26/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005206  JOANA DARC RAFAEL DE RESENDE              WASHINGTON BARCELOS              925   URCIANO LEMOSMORADA DO SOL      38181292 - ARAXÁ - MG
Fantasia:   JOANA DARC RAFAEL DE RESENDE                   CNPJ/CPF:   10.608.650/0001-78      Rep: 21.496     Insc Estad:   0011074600070        Telefone:    (34)-992-523341          E-mail:
E-mail NF-e:     passarelaaraxa@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022285  LOOK MODA LTDA                           R DOUTOR EDMAR CUNHA              175   VILA SANTA TEREZINHA             38183296 - ARAXÁ - MG
Fantasia:   LOOK MODAS                                     CNPJ/CPF:   12.287.382/0001-65      Rep: 21.496     Insc Estad:   0016354450099        Telefone:    (34) 3662-4745           E-mail:
E-mail NF-e:     silvia.rodolfo@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005208  LUANA CONFECCOES E CALCADOS LTDA          MARIANO DE AVILA                   203   CENTRO                          38183224 - ARAXÁ - MG
Fantasia:   LUANA CONFECCOES E CALCADOS L                 CNPJ/CPF:   20.086.476/0001-02      Rep: 21.496     Insc Estad:   0404333730000        Telefone:    (34)3661-1599            E-mail:
E-mail NF-e:    LUADIOLIVEIRA1950@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021779  SINHA MODAS ACESSORIOS LTDA ME             Rua presidente olegario maciel          226   Centro                            38183186 - ARAXÁ - MG
Fantasia:    SINHA MODAS                                     CNPJ/CPF:   05.552.719/0001-59      Rep: 21.496     Insc Estad:   0402235500075        Telefone:    (34) 3662-2445           E-mail:
E-mail NF-e:     lidiane_dutra@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011964  CAIO SAVIO RESENDE                       RUA CORONEL CANDIDO DE SOUZA DIAS 1140  CENTRO                          37820000 - ARCEBURGO - MG
Fantasia:    PAPELARIA CALCADOS OPCAO                       CNPJ/CPF:   18.852.826/0001-44      Rep: 21.564     Insc Estad:   0022207750094        Telefone:    (359)9821--3558          E-mail:
E-mail NF-e:    PAPELARIAOPCAO@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     29/12/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009333  COMERCIAL COSTA LEME LTDA - EPP             RUA JARBAS FERREIRA PIRES           133   CENTRO                          35588000 - ARCOS - MG
Fantasia:   COMERCIAL COSTA LEME LTDA - EP                  CNPJ/CPF:   65.309.379/0001-61      Rep: 21.564     Insc Estad:   0424334820070        Telefone:    (37)3351-1233            E-mail:
E-mail NF-e:    COSTALEMEPEDIDOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021162  JOSE ODIVAR CALHEIROS                       Rua Jose Jacinto Pereira                191   Centro                            37140000 - AREADO - MG
Fantasia:    ELITE MODAS                                     CNPJ/CPF:   17.234.790/0001-72      Rep: 21.564     Insc Estad:   433517540067         Telefone:    (35) 3293-1599           E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017840  JOSE RAIMUNDO DOS SANTOS                 RUA TARCISIO GERALDO ANDRADE      110   CENTRO                          39678000 - ARICANDUVA - MG
Fantasia:    LOJA DO ZEZÉ                                     CNPJ/CPF:   21.082.607/0001-38      Rep: 22.941     Insc Estad:   7712545120047        Telefone:    (33)88525-5481           E-mail:
E-mail NF-e:    ZEZEMONTEIRO58@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019624  PEDRO CAMPOS NETO                          Rua Gutemberg Hernriques             233   Centro                            36780000 - ASTOLFO DUTRA - MG
Fantasia:   A IMPERIAL CALCADOS                             CNPJ/CPF:   21.789.987/0001-45      Rep: 13.734     Insc Estad:   462497310079         Telefone:    (32) 99984-4395          E-mail:
E-mail NF-e:     pedrocamposneto22@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 5

Pág. 5 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021613  DAYANA SIQUEIRA SILVA                        JAIME TEIXEIRA DE ANDRADE           280   Centro                            37443000 - BAEPENDI - MG
Fantasia:    LAVELYS SAPATILHAS                              CNPJ/CPF:   33.144.531/0001-07      Rep: 21.564     Insc Estad:   003.408.285/0023      Telefone:    (35) 98878-5452          E-mail:
E-mail NF-e:     dayanebae@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010503  EDMUNDO DE SIQUEIRA E CIA LTDA             RUA JOSÉ ALBERTO PELUCIO 118 LETRA ASN   CENTRO                          37443000 - BAEPENDI - MG
Fantasia:   EDMUNDO DE SIQUEIRA E CIA LTDA                  CNPJ/CPF:   04.610.985/0001-28      Rep: 21.564     Insc Estad:   491394180015         Telefone:    3.533.431.122            E-mail:
E-mail NF-e:     lojaroseno@sulminas.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022163  HELENA DE FATIMA MARTINS                    PC CORONEL CAETANO MASCARENHAS   79    SAO VICENTE                      35733000 - BALDIM - MG
Fantasia:   HELENA DE FATIMA MARTINS                        CNPJ/CPF:   51.114.093/0001-16      Rep: 22.500     Insc Estad:   004.644.573/0043      Telefone:    (31) 996-81-4822         E-mail:
E-mail NF-e:     leninhasv2018@gmail.com

     Obs.:                                                           Proprietário :

Condição de Pagamento:     1 A VISTA
Data Última Compra:     20/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006877  COMERCIAL LULUJO LTDA - ME                 SANTOS DUMONT                    1336  NOSSA SENHORA DE FATIMA         38900000 - BAMBUÍ - MG
Fantasia:   COMERCIAL LULUJO LTDA - ME                      CNPJ/CPF:   02.642.800/0001-31      Rep: 21.564     Insc Estad:   0518198420046        Telefone:    (37)3431-5154            E-mail:
E-mail NF-e:     comerciallulujo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

020088  DORNELAS E NAVARRO CALCADOS LTDA          RUA LUIZ PINTO                      54     Centro                            35970000 - BARÃO DE COCAIS - MG
Fantasia:    ESSENCIAL CALCADOS                             CNPJ/CPF:   07.488.016/0001-34      Rep: 21.495     Insc Estad:   0543496750040        Telefone:    (31) 3837-3171           E-mail:
E-mail NF-e:     essencial.calcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     05/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003400  MAGNO JOSE DE JESUS MAIA - EPP              WILSON ALVARENGA DE OLIVEIRA       137   CENTRO                          35970000 - BARÃO DE COCAIS - MG
Fantasia:   MAGNO JOSE DE JESUS MAIA - EPP                   CNPJ/CPF:   09.538.940/0002-94      Rep: 21.495     Insc Estad:   0010697020169        Telefone:    (31)3832-1130            E-mail:
E-mail NF-e:     d2calcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019544   SILVA E CIA LTDA                                 Avenida Getulio Vargas                922    Vila Regina                        35970000 - BARÃO DE COCAIS - MG
Fantasia:   CASA E SILVA                                     CNPJ/CPF:   17.659.111/0001-07      Rep: 21.495     Insc Estad:   543885670055         Telefone:    (31) 3837-1542           E-mail:
E-mail NF-e:     eder.silva44@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021857  BQMED PRODUTOS MEDICOS LTDA               Rua tiradentes                       70     Centro                            36200062 - BARBACENA - MG
Fantasia:   BQMED                                           CNPJ/CPF:   01.569.403/0001-19      Rep: 22.619     Insc Estad:   0563201020002        Telefone:    (32) 3331-8971           E-mail:
E-mail NF-e:     cristianocalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021005  CALCADAO COMERCIO DE CALCADOS EIRELI ME     Rua Quinze de Novembro               72     Centro                            36200074 - BARBACENA - MG
Fantasia:   COMPLEMENTO CALCADOS                          CNPJ/CPF:   05.386.345/0001-49      Rep: 22.619     Insc Estad:   0562097250042        Telefone:    (32) 3426-8309           E-mail:
E-mail NF-e:     pedidos@grupocomplemento.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003618  COMERCIAL HARMOND LTDA - ME                TIRADENTES                        20    CENTRO                          36200062 - BARBACENA - MG
Fantasia:   COMERCIAL HARMOND LTDA - ME                    CNPJ/CPF:   66.194.325/0001-60      Rep: 22.619     Insc Estad:   0567626430086        Telefone:    (32)3331-1810            E-mail:
E-mail NF-e:     sapatariacinderela20@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018309  DANIELA CATON DE SOUZA 03499640686         RUA CARLOS BETONE FILHO            7     SANTA CECILIA                    36201500 - BARBACENA - MG
Fantasia:    DANIELA CATON                                   CNPJ/CPF:   16.726.396/0001-99      Rep: 22.619     Insc Estad:   0020149110006        Telefone:    (32) 3361-1004           E-mail:
E-mail NF-e:     danielacaton@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/12/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

022155  LASARA COMERCIAL LTDA                    RUA TIRADENTES                     120   CENTRO                          36200062 - BARBACENA - MG
Fantasia:   ROSE MODAS                                     CNPJ/CPF:   17.081.993/0001-76      Rep: 22.619     Insc Estad:   056.019.960/0075      Telefone:    (32) 99902-6930          E-mail:
E-mail NF-e:     rose-modas120@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022273  JOSE HENRIQUE MACHADO CARNEIRO            10AV PEDRO JOSE PIMENTA            59    CENTRO                          35447000 - BARRA LONGA - MG
Fantasia:    JOSE HENRIQUE MACHADO CARNEIRO                CNPJ/CPF:   49.764.359/0001-24      Rep: 22.619     Insc Estad:   004.559.1910084       Telefone:    (31) 98324-3108          E-mail:
E-mail NF-e:     lojadagraca@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 6

Pág. 6 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

006998  MAURA MAIA DE SOUZA - ME                   PRACA SANTANA                     162   CENTRO                          36212000 - BARROSO - MG
Fantasia:   MAURA MAIA DE SOUZA - ME                        CNPJ/CPF:   02.119.133/0001-07      Rep: 22.619     Insc Estad:   0597151230061        Telefone:    (32)3351-1338            E-mail:
E-mail NF-e:     milleniumsapataria@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

014598  GERALDO DE SOUZA FILHO EIRELI               AV JOSE MODESTO AVILAR             472   CENTRO                          35938000 - BELA VISTA DE MINAS - MG
Fantasia:   SOUARTE MODAS                                  CNPJ/CPF:   25.810.540/0001-61      Rep: 22.751     Insc Estad:   0604938050039        Telefone:    (31)3853-1410            E-mail:
E-mail NF-e:    SOUARTEMODAS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015059  AGIT CALÇADOS E ACESSÓRIOS LTDA            RUA PLATINA                        1491  CALAFATE                         30411325 - BELO HORIZONTE - MG
Fantasia:    AGIT CALÇADOS                                   CNPJ/CPF:   10.621.361/0001-09      Rep: 22.500     Insc Estad:   0011082040088        Telefone:    (31)98251-8273           E-mail:
E-mail NF-e:    AGITCALCADOSEACESSORIOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021511   ALINE NASCIMENTO MOTA DE SOUZA             Rua estância                         239   Nova vista                         31070240 - BELO HORIZONTE - MG
Fantasia:    ALINE STILO                                      CNPJ/CPF:   47.694.033/0001-42      Rep: 22.500     Insc Estad:   0044240310091        Telefone:    (31) 98719-4787          E-mail:
E-mail NF-e:     alinestilomp@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006499  B COBRA CALCADOS E ESPORTES LTDA           PADRE EUSTAQUIO 2728 - LOJA        4     PADRE EUSTAQUIO                 30720100 - BELO HORIZONTE - MG
Fantasia:   B COBRA CALCADOS E ESPORTES LT                 CNPJ/CPF:   15.700.848/0001-09      Rep: 22.500     Insc Estad:   0019773270050        Telefone:    (31)3464-4479            E-mail:
E-mail NF-e:     comercial@malibuesportes.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003305  BABI COMERCIO DE CALCADOS LTDA - ME         SINFRONIO BROCHADO                266   BARREIRO                         30640000 - BELO HORIZONTE - MG
Fantasia:    BABI COMERCIO DE CALCADOS LTDA                 CNPJ/CPF:   04.885.910/0001-50      Rep: 22.500     Insc Estad:   0621625790022        Telefone:    (31)3384-3655            E-mail:
E-mail NF-e:     babicalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007130  BEBEL CALCADOS LTDA                      BARAO DE COROMANDEL 202 - LOJA    SN    BARREIRO                         30640060 - BELO HORIZONTE - MG
Fantasia:    BEBEL CALCADOS LTDA                             CNPJ/CPF:   12.216.006/0001-80      Rep: 22.500     Insc Estad:   0016274310096        Telefone:    (31)2510-7680            E-mail:
E-mail NF-e:     bebel.calcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015814   BIT CALCADOS LTDA ME                      RUA CURITIBA                       321   CENTRO                          30170120 - BELO HORIZONTE - MG
Fantasia:    LICE CALÇADOS                                   CNPJ/CPF:   45.883.630/0001-90      Rep: 22.500     Insc Estad:   0043091240029        Telefone:    (31)3564-9316            E-mail:
E-mail NF-e:    EXITUSCONTABILIDADESERVICOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     15/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020472  CALCADOS ITAPUA F198                      AV AFONSO PENA                     504   CENTRO                          30130901 - BELO HORIZONTE - MG
Fantasia:   CALCADOS ITAPUA F198                            CNPJ/CPF:   27.177.096/0108-53      Rep: 19.275     Insc Estad:   2770415012939        Telefone:    (27) 2124-7700           E-mail:
E-mail NF-e:    F198@ITAPUA.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020464  CALCADOS ITAPUA F54                       RUA TUPIS                           317/37 CENTRO                          30190060 - BELO HORIZONTE - MG
Fantasia:   CALCADOS ITAPUA F54                             CNPJ/CPF:   27.177.096/0021-68      Rep: 19.275     Insc Estad:   1659420048            Telefone:    (27) 2124-7700           E-mail:
E-mail NF-e:    F54@ITAPUA.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004700  CENOURINHA CALCADOS LTDA                 RUA SCO LEOPOLDO 10 - A           SN    CACHOEIRINHA                    31130710 - BELO HORIZONTE - MG
Fantasia:   CENOURINHA CALCADOS LTDA                      CNPJ/CPF:   03.531.291/0001-32      Rep: 22.500     Insc Estad:   0620563830084        Telefone:    (31)3424-4024            E-mail:
E-mail NF-e:     cenourinha2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003383  COLOMBO CALCADOS LTDA - ME                RUA GRAUNAS                       318   FLAVIO MARQUES LISBOA            30624220 - BELO HORIZONTE - MG
Fantasia:   COLOMBO CALCADOS LTDA - ME                     CNPJ/CPF:   11.301.601/0001-50      Rep: 22.500     Insc Estad:   001.487.536/0045      Telefone:    (31)3385-5501            E-mail:
E-mail NF-e:     binacolombo@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003742  COMERCIAL MARLENE FANTINI CALC LTDA - ME     RIO DE JANEIRO                     838   CENTROLOURDES                   30160041 - BELO HORIZONTE - MG
Fantasia:   MARLENE FANTINI                                 CNPJ/CPF:   07.447.078/0001-06      Rep: 22.500     Insc Estad:   0623481530039        Telefone:    (31)2515-3391            E-mail:
E-mail NF-e:    CONTATO@MARLENEFANTINI.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 7

Pág. 7 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

010429  COMERCIAL PATRICIA CHAVES EIRELI            AV DOM PEDRO I 402 - LOJA           416   ITAPOA                           31710000 - BELO HORIZONTE - MG
Fantasia:   COMERCIAL PATRICIA CHAVES EIRE                  CNPJ/CPF:   08.822.253/0003-14      Rep: 22.500     Insc Estad:   0010372850294        Telefone:    (31)3492-6875            E-mail:
E-mail NF-e:     nfe@frankcalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003681  COMERCIAL RUBENS FANTINI LTDA - ME          RUA SCO PAULO                      672   CENTRO                          30170120 - BELO HORIZONTE - MG
Fantasia:   COMERCIAL RUBENS FANTINI LTDA                  CNPJ/CPF:   09.638.630/0001-60      Rep: 22.500     Insc Estad:   0010750060069        Telefone:    (31)2515-3391            E-mail:
E-mail NF-e:     contato@marlenefantini.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017393  CREUZA ERONDINA DE MELO                  RUA GUARARAPES                    1246  NOSSA SENHORA DA GLÓRIA         30865000 - BELO HORIZONTE - MG
Fantasia:    VIVI CALÇADOS                                   CNPJ/CPF:   12.613.895/0001-19      Rep: 22.500     Insc Estad:   001.670.366/0034      Telefone:    (31)9920-47030           E-mail:
E-mail NF-e:     vivianepaulina34@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006540  DALINNE COMERCIO DE CALCADOS LTDA         DOS CARIJOS                        755   CENTRO                          30120060 - BELO HORIZONTE - MG
Fantasia:    DALINNE COMERCIO DE CALCADOS L                 CNPJ/CPF:   01.030.943/0001-20      Rep: 22.500     Insc Estad:   0623367570051        Telefone:    (31)3271-7675            E-mail:
E-mail NF-e:     dalinnecalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015332  DANTE CALCADOS LTDA                      RUA TUPINAMBAS                    314   CENTRO                          30120070 - BELO HORIZONTE - MG
Fantasia:   DANTE CALCADOS , AMIGÃO                        CNPJ/CPF:   36.599.580/0001-22      Rep: 22.500     Insc Estad:   0036880960049        Telefone:    (31)3272-9694            E-mail:
E-mail NF-e:    AMIGAO@AMIGAOCALCADOS.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016273  DEBORA LUIZA PAIVA                        RUA RIO JANEIRO                    941   CENTRO                          30160041 - BELO HORIZONTE - MG
Fantasia:    GRANVILLE                                       CNPJ/CPF:   45.788.174/0001-07      Rep: 22.500     Insc Estad:   0043025770082        Telefone:    (31)3213-2943            E-mail:
E-mail NF-e:    GERALDOSAVIOP@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010685  DESFILE COMERCIAL EIRELI                    AV AFONSO PENA                    514   CENTRO                          30130000 - BELO HORIZONTE - MG
Fantasia:    DESFILE COMERCIAL EIRELI                         CNPJ/CPF:   22.514.871/0001-66      Rep: 22.500     Insc Estad:   0625078790003        Telefone:    (31)3201-1994            E-mail:
E-mail NF-e:     desfilecomercial@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009275  DMULHER COMERCIO DE CALCADOS LTDA - EPP     AVENIDA AUGUSTO DE LIMA            1432  BARRO PRETO                     31160380 - BELO HORIZONTE - MG
Fantasia:   DMULHER COMERCIO DE CALÇADOS -                CNPJ/CPF:   06.149.475/0001-20      Rep: 22.500     Insc Estad:   0622789810019        Telefone:    (31)3274-9990            E-mail:
E-mail NF-e:    NFE@PEDEMULHER.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     28/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006574  E E F CALCADOS E ESPORTES LTDA - ME           Rua Eudes Garcia                     08     Jardim Guanabara                  31742132 - BELO HORIZONTE - MG
Fantasia:    E E F CALCADOS E ESPORTES LTDA                  CNPJ/CPF:   25.135.722/0001-84      Rep: 22.500     Insc Estad:   0027896490099        Telefone:    (31)-343-6-9138          E-mail:
E-mail NF-e:     betacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021500  EBP REPRESENTACOES EIRELLI                 RUA BOLIVAR                        571   UNIÃO                            31170670 - BELO HORIZONTE - MG
Fantasia:    EBP REPRESENTACOES EIRELLI                      CNPJ/CPF:   30.128.679/0001-60      Rep: 22.036     Insc Estad:                            Telefone:    (55)5555-555             E-mail:
E-mail NF-e:     emilianobritop@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018621  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  RUA RODRIGUES CALDAS              200   SANTO AGOSTINHO                 30190120 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0018-07      Rep: 22.500     Insc Estad:   620.135.541/475       Telefone:    (31)2105-2000            E-mail:
E-mail NF-e:     loja13@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018622  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  RUA DOS CARIJÓS                    551   CENTRO                          30120060 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0019-80      Rep: 22.500     Insc Estad:   620.135.541/548       Telefone:    (32)2105-2000            E-mail:
E-mail NF-e:     loja14@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018624  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  AVENIDA PARANÁ                    334   CENTRO                          30120020 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0037-61      Rep: 22.500     Insc Estad:   620.135.542/790       Telefone:    (31)9843-03697           E-mail:
E-mail NF-e:     loja08@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 8

Pág. 8 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018625  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  AVENIDA SINFRÔNIO BROCHADO        306   BARREIRO                         30640000 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0039-23      Rep: 22.500     Insc Estad:   620.135.542/951       Telefone:    (31)9923-42446           E-mail:
E-mail NF-e:     loja34@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018626  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  AVENIDA AFONSO PENA               464   CENTRO                          30130001 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0113-57      Rep: 22.500     Insc Estad:   620.135.548/577       Telefone:    (31)9840-73583           E-mail:
E-mail NF-e:     loja106@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018629  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  R WALDOMIRO LOBO                  133   AARAO REIS                       31814620 - BELO HORIZONTE - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0117-80      Rep: 22.500     Insc Estad:   620.135.548/810       Telefone:    (31)9843-87181           E-mail:
E-mail NF-e:     loja110@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021532  ERIC CAVALCANTE DE ALMEIDA                  Rua descalvado                      658   Renascenca                        31130610 - BELO HORIZONTE - MG
Fantasia:   PASSO FIRME                                     CNPJ/CPF:   12.954.526/0001-90      Rep: 22.500     Insc Estad:   001.705.087/0048      Telefone:    (31) 99981-8010          E-mail:
E-mail NF-e:     passofcalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005754  ESTILO DOS PES LTDA                           ITAJUBA                            401   FLORESTASAGRADA FAMILIA          31015280 - BELO HORIZONTE - MG
Fantasia:    ESTILO DOS PES LTDA                              CNPJ/CPF:   11.813.685/0001-01      Rep: 22.500     Insc Estad:   0015837270027        Telefone:    (31)3446-1533            E-mail:
E-mail NF-e:     leandro@estilodospes.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2025                                                                                                          Marca da Última compra :222-PEZINE

020998  EVA VICENTE CARDOSO                        Rua armando ribeiro dos santos         190   Sao bernardo                      31741380 - BELO HORIZONTE - MG
Fantasia:   EVA MODAS                                       CNPJ/CPF:   49.372.462/0001-29      Rep: 22.500     Insc Estad:   45348740098           Telefone:    (31) 98803-6017          E-mail:
E-mail NF-e:     fabianafreewayshoes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015148  EZIO LEONEL DE OLIVEIRA EIRELI               RUA CURITIBA                       648   CENTRO                          30170121 - BELO HORIZONTE - MG
Fantasia:    EZIO LEONEL                                      CNPJ/CPF:   30.022.190/0001-09      Rep: 22.500     Insc Estad:   0031580190073        Telefone:    (31)3504-8840            E-mail:
E-mail NF-e:    EZIO.LEONEL@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     08/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006902  FERNANDES CALCADOS LTDA                   AV SINFRONIO BROCHADO 398 - LJ     01    BARREIRO                         30640000 - BELO HORIZONTE - MG
Fantasia:   FERNANDES CALCADOS LTDA                        CNPJ/CPF:   03.549.324/0001-71      Rep: 22.500     Insc Estad:   1862794570024        Telefone:    (31)3362-2868            E-mail:
E-mail NF-e:     novidadecalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     26/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003854   FILIPE MEDEIROS DE ALCANTARA                PRACA CARDEAL ARCO VERDE          96    NOVA CINTRA                      30516290 - BELO HORIZONTE - MG
Fantasia:    FILIPE MEDEIROS DE ALCANTARA                    CNPJ/CPF:   17.996.243/0001-24      Rep: 22.500     Insc Estad:   0021375920006        Telefone:    (31)3322-4950            E-mail:
E-mail NF-e:     lupecalcados2@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011129  FOX CALCADOS EIRELI                        AV AFONSO VAZ DE MELO             640   BARREIRO                         30640070 - BELO HORIZONTE - MG
Fantasia:   FOX CALCADOS EIRELI                             CNPJ/CPF:   31.534.798/0001-85      Rep: 22.500     Insc Estad:   0032780070072        Telefone:    (31)3272-9582            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002955  GANA CALCADOS EIRELI - EPP                    CURITIBA                           612   CENTRO                          30170120 - BELO HORIZONTE - MG
Fantasia:   GANA CALCADOS EIRELI - EPP                       CNPJ/CPF:   20.973.668/0001-22      Rep: 22.500     Insc Estad:   0024244820060        Telefone:    (31)3278-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002966  GEFERSON CALCADOS LTDA                   ANTONIO JOSÉ DOS SANTOS           655   CEU AZUL                         31580000 - BELO HORIZONTE - MG
Fantasia:   GEFERSON CALCADOS LTDA                         CNPJ/CPF:   68.528.033/0001-42      Rep: 22.500     Insc Estad:   0628199450028        Telefone:    (31)3496-1508            E-mail:
E-mail NF-e:     gefersoncalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

013689  GERALDO SUDÁRIO DUARTE FILHO              RUA ARARAS                        120   CONCORDIA                       31110800 - BELO HORIZONTE - MG
Fantasia:   WS CALCADOS                                    CNPJ/CPF:   36.891.032/0001-71      Rep: 22.500     Insc Estad:   0037096270019        Telefone:    (31)3055-3087            E-mail:
E-mail NF-e:    WESLEYDUARTE77@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     02/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 9

Pág. 9 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016628   GRIFF CALÇADOS E ACESSÓRIOS LTDA           RUA JOSÉ FÉLIX MARTINS              2464  MANTIQUEIRA                     31655700 - BELO HORIZONTE - MG
Fantasia:    GRIFF CALÇADOS                                  CNPJ/CPF:   14.169.801/0001-90      Rep: 22.500     Insc Estad:   0018271050079        Telefone:    (31)3453-2530            E-mail:
E-mail NF-e:    CHARLIM1951@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017083  HÉLIO PEREIRA DA SILVA                     RUA SAN MARINO                    99    EUROPA                          31620440 - BELO HORIZONTE - MG
Fantasia:   EUROPA CALÇADOS                                CNPJ/CPF:   21.817.163/0001-31      Rep: 22.500     Insc Estad:   0025048230043        Telefone:    (31)3458-5678            E-mail:
E-mail NF-e:    HELIOPEDASI@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006576  HELO CALCADOS E ESPORTES LTDA - ME          RUA PORTO SEGURO                  427   BOA VISTA                        31070130 - BELO HORIZONTE - MG
Fantasia:   HELO CALCADOS E ESPORTES LTDA                  CNPJ/CPF:   25.154.303/0001-90      Rep: 22.500     Insc Estad:   0625915560015        Telefone:    (31)3488-1255            E-mail:
E-mail NF-e:     helocalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003016  HUGO CALCADOS LTDA - EPP                  BERNARDA SILVESTRE                 363   RIO BRANCO                       31535200 - BELO HORIZONTE - MG
Fantasia:   HUGO CALCADOS LTDA - EPP                        CNPJ/CPF:   25.385.626/0001-94      Rep: 22.500     Insc Estad:   0625924470023        Telefone:    (31)3496-1508            E-mail:
E-mail NF-e:     hugocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010445  INTACTA CALCADOS EIRELI                   RUA WALDOMIRO LOBO 570 LOJA      1     GUARANI                         31814620 - BELO HORIZONTE - MG
Fantasia:    INTACTA CALCADOS EIRELI                         CNPJ/CPF:   33.287.606/0001-09      Rep: 22.500     Insc Estad:   0034192070030        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019029  JD REPRESENTACOES E COMERCIO LTDA          R amilcar cabral                      222    Milionarios                        30620250 - BELO HORIZONTE - MG
Fantasia:   SALVADOS MILIONARIOS                           CNPJ/CPF:   05.914.420/0001-05      Rep: 22.500     Insc Estad:   0044365160052        Telefone:    (31) 3543-1379           E-mail:
E-mail NF-e:     salvadosmilionarios@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011759  JM COMERCIO DE CALCADOS LTDA              RUA DOS TUPIS                      262   CENTRO                          30190060 - BELO HORIZONTE - MG
Fantasia:    PE DE MULHER LOJA 10                             CNPJ/CPF:   19.318.036/0001-46      Rep: 22.500     Insc Estad:   002.268.539/0022      Telefone:    (31)3222-3254            E-mail:
E-mail NF-e:    NFE@PEDEMULHER.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     28/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007105  JORGE NONAKA - ME                         AV SINFRONIO BROCHADO 376 - LOJA   1     BARREIRO                         30640000 - BELO HORIZONTE - MG
Fantasia:   JORGE NONAKA - ME                               CNPJ/CPF:   09.281.633/0001-90      Rep: 22.500     Insc Estad:   0010570290007        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     japacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013734  JOSE CARLOS RESENDE REPRESENTACOES LTDA    RUA SÃO PAULO, 1071                1071  CENTRO                          30170907 - BELO HORIZONTE - MG
Fantasia:    JOSE CARLOS RESENDE REPRESENTA                 CNPJ/CPF:   39.962.745/0001-77      Rep: 13.734     Insc Estad:                            Telefone:    (31)3274-9360            E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014074  JOSEFINA DIAS COIMBRA                            R. PORTO SEGURO                    388   NOVA VISTA                       31070130 - BELO HORIZONTE - MG
Fantasia:    JO ARMARINHO                                    CNPJ/CPF:   23.400.427/0001-82      Rep: 22.500     Insc Estad:   0625664750056        Telefone:    (31)88772-2151           E-mail:
E-mail NF-e:    JOO.COIMBRA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013217  JOSIMAR SALVADOR DO CARMO                RUA DOS TUPINAMBAS                843   CENTRO                          30120070 - BELO HORIZONTE - MG
Fantasia:    JOSIMAR SALVADOR DO CARMO                     CNPJ/CPF:   20.514.947/0001-28      Rep: 22.500     Insc Estad:   0023840380049        Telefone:    (31)3272-8209            E-mail:
E-mail NF-e:     lobatomariana164@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022301   LIVIA LEMES DO CARMO                      R CONSELHEIRO ROCHA               3875  HORTO FLORESTAL                 31035007 - BELO HORIZONTE - MG
Fantasia:    LILU CALCADOS                                   CNPJ/CPF:   58.638.675/0001-40      Rep: 22.500     Insc Estad:   005.072.655/0094      Telefone:    (31) 99686-2816          E-mail:
E-mail NF-e:     lilucalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009819  LOJA FRANCA CALCADOS LTDA                   Rua Contagem                       1237  Santa Inês                        31080255 - BELO HORIZONTE - MG
Fantasia:   FRANCA CALCADOS                                CNPJ/CPF:   34.816.794/0001-88      Rep: 22.500     Insc Estad:   0035400270077        Telefone:    (31)85690-0496           E-mail:
E-mail NF-e:     josesafranca@otlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 10

Pág. 10 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016169  LOJAS ROSE ARMARINHO LTDA                 RUA ANTÔNIO BANDEIRA              947   TUPI                             31844130 - BELO HORIZONTE - MG
Fantasia:   ROSE ARMARINHOS                                CNPJ/CPF:   08.415.095/0001-16      Rep: 22.500     Insc Estad:   0010234190043        Telefone:    (31)86561-1965           E-mail:
E-mail NF-e:    ROSELIPIRES1965@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     14/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019702  LORENA FERNANDA MARQUES DE MATOSINHOS     Rua Ministro de Oliveira Salazar         891   Santa Monica                      31525000 - BELO HORIZONTE - MG
Fantasia:   PONTO & VíRGULA CALCADOS                       CNPJ/CPF:   43.506.730/0001-71      Rep: 22.500     Insc Estad:   0041469760029        Telefone:    (31) 99278-1789          E-mail:
E-mail NF-e:     jarleyrepres@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005756   LPL CALCADOS ROUPAS E ACESSORIOS LTDA      DOUTOR CRISTIANO GUIMARAES        1981  PLANALTO                         31720300 - BELO HORIZONTE - MG
Fantasia:    LPL CALCADOS ROUPAS E ACESSORI                 CNPJ/CPF:   22.469.491/0001-57      Rep: 22.500     Insc Estad:   0025597950088        Telefone:    (31)3646-9918            E-mail:
E-mail NF-e:     estilodospes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2025                                                                                                          Marca da Última compra :222-PEZINE

019335   LUCI LANA ME                             RUA LEONIL PRATA                   339   ALIPIO DE MELO                    30830610 - BELO HORIZONTE - MG
Fantasia:    LUCI CALCADOS                                   CNPJ/CPF:   21.141.747/0001-30      Rep: 22.500     Insc Estad:   0024404000081        Telefone:    (31)-988-18-5021         E-mail:
E-mail NF-e:     luci-lana@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006569  LUKITA COMERCIO DE CALCADOS EIRELI-EPP       AV AFONSO PENA                    570   CENTRO                          30130001 - BELO HORIZONTE - MG
Fantasia:    LUKITA COMERCIO DE CALCADOS EI                 CNPJ/CPF:   06.966.367/0001-40      Rep: 22.500     Insc Estad:   006.231.308/50081     Telefone:    (31)3222-4700            E-mail:
E-mail NF-e:     nfe@pedemulher.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008142  LUNE ESPORTES EIRELI - EPP                   AV CRISTIANO MACHADO 11833 L      1080  VILA CLORIS                       31744007 - BELO HORIZONTE - MG
Fantasia:   LUNE ESPORTES EIRELI - EPP                        CNPJ/CPF:   19.062.503/0001-10      Rep: 22.500     Insc Estad:   0022424750009        Telefone:    (31)3392-1446            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009702  MAIS MODAS E CALCADOS LTDA                AV ABILIO MACHADO                 1955  GLORIA                           30830373 - BELO HORIZONTE - MG
Fantasia:    MAIS MODAS E CALCADOS LTDA                     CNPJ/CPF:   29.750.212/0001-78      Rep: 22.500     Insc Estad:   0031357810008        Telefone:   315981555                E-mail:
E-mail NF-e:    jmcomercioadm@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006628  MALIBU ESPORTES LTDA ME                    PARA DE MINAS 1073 - LETRA B       SN    PADRE EUSTAQUIO                 30730440 - BELO HORIZONTE - MG
Fantasia:    MALIBU ESPORTES LTDA ME                         CNPJ/CPF:   22.744.700/0001-23      Rep: 22.500     Insc Estad:   0625407690020        Telefone:    (31)3464-4479            E-mail:
E-mail NF-e:     comercial@malibuesportes.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003510  MANIA DE CALCADOS GUARANI LTDA - ME        WALDOMIRO LOBO                   940   GUARANI                         31814620 - BELO HORIZONTE - MG
Fantasia:   MANIA DE CALCADOS GUARANI LTDA                 CNPJ/CPF:   22.355.410/0001-98      Rep: 22.500     Insc Estad:   0025502920054        Telefone:    (31)3434-9994            E-mail:
E-mail NF-e:     maniadospes@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003463  MANIA DOS PES CALCADOS LTDA - ME           RUA CONTAGEM                      1889  SANTA INES                       31080365 - BELO HORIZONTE - MG
Fantasia:   MANIA DOS PES CALCADOS LTDA -                   CNPJ/CPF:   08.829.476/0001-41      Rep: 22.500     Insc Estad:   0010473610000        Telefone:    (31)3637-3274            E-mail:
E-mail NF-e:    MANIADOSPES@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022070  MARCELO LUIZ DE SOUZA                      Rua Antônio José dos santos            715   Ceu azul                          31580000 - BELO HORIZONTE - MG
Fantasia:   SOUZA                                           CNPJ/CPF:   18.795.525/0001-26      Rep: 22.500     Insc Estad:   22148520040           Telefone:    (31) 98823-3071          E-mail:
E-mail NF-e:     souttomayor@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008457  MARCILENE SANTOS CUNHA 96157097604        RUA EXPEDICIONARIO JOSÉ SILVA       47    MARIA GORETTI                    31930700 - BELO HORIZONTE - MG
Fantasia:    MARCILENE SANTOS CUNHA 9615709                CNPJ/CPF:   17.514.891/0001-05      Rep: 22.500     Insc Estad:   0020929960068        Telefone:    (31)3432-3115            E-mail:
E-mail NF-e:     babylook1@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006086  MARIA DAS GRAÇAS RESENDE OLIVEIRA          RUA FLOR DE PITANGUEIRA            161   INDEPENDENCIA                   30672250 - BELO HORIZONTE - MG
Fantasia:   GRACIONE CONFECCOES LTDA                      CNPJ/CPF:   22.104.418/0001-81      Rep: 22.500     Insc Estad:   0624953500066        Telefone:    (31)3385-6250            E-mail:
E-mail NF-e:    ANGELICA@CONSULT.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 11

Pág. 11 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017141  MARIA MARGARIDA ALVES VIEIRA FELIPE         RUA ÁLVARO MARTINS RABELO          119   CONJUNTO CONFISCO               31360410 - BELO HORIZONTE - MG
Fantasia:   MARIA MARGARIDA                                CNPJ/CPF:   13.485.952/0001-94      Rep: 22.500     Insc Estad:   0017571630002        Telefone:    (31)93511-1896           E-mail:
E-mail NF-e:    MARIAMVFELIPE@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021113  MOEMA ALEXANDRE DA SILVA                      Avenida Olinto Meireles                2745   Milionarios Barreiro                  30620330 - BELO HORIZONTE - MG
Fantasia:   MOEMA CALCADOS                                 CNPJ/CPF:   12.091.100/0001-50      Rep: 22.500     Insc Estad:   16147490095           Telefone:    (31) 98559-4782          E-mail:
E-mail NF-e:     moemacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

012275  MONACO CALCADOS LTDA                    RUA CURITIBA                       737   CENTRO                          30170124 - BELO HORIZONTE - MG
Fantasia:   MONACO CALCADOS                               CNPJ/CPF:   36.543.600/0001-43      Rep: 22.500     Insc Estad:   0036837480057        Telefone:    (31)3272-8080            E-mail:
E-mail NF-e:    AMIGAO@AMIGAOCALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003454  N E F CALCADOS E BOLSAS LTDA - ME            RUA JOSUE MARTINS DE SOUZA         678   LAGOA                           31578000 - BELO HORIZONTE - MG
Fantasia:   N E F CALCADOS E BOLSAS LTDA -                   CNPJ/CPF:   06.187.220/0001-52      Rep: 22.500     Insc Estad:   5462800430027        Telefone:    (31)3453-3955            E-mail:
E-mail NF-e:    LIPECALCADOS@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014061  N E F CALCADOS E BOLSAS LTDA FILIAL              R. PADRE PEDRO PINTO                6670  VENDA NOVA                      31660000 - BELO HORIZONTE - MG
Fantasia:    LIPE CALCADOS                                   CNPJ/CPF:   06.187.220/0002-33      Rep: 22.500     Insc Estad:   5462800430108        Telefone:    (31)3318-6856            E-mail:
E-mail NF-e:    LIPECALCADOS@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006846  NALVA COMERCIO DE CALCADOS LTDA          DOS TUPINAMBAS                    679   CENTRO                          30120074 - BELO HORIZONTE - MG
Fantasia:   NALVA COMERCIO DE CALCADOS LTD                CNPJ/CPF:   20.195.191/0001-00      Rep: 22.500     Insc Estad:   0023537580045        Telefone:    (31)9777-5285            E-mail:
E-mail NF-e:    CLEBERSALVADOR13@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003522  NARDY COMERCIO DE CALCADOS LTDA - ME       URSULA PAULINO                     1574  BETANIA                          30580000 - BELO HORIZONTE - MG
Fantasia:   NARDY COMERCIO DE CALCADOS LTD                CNPJ/CPF:   07.405.302/0001-99      Rep: 22.500     Insc Estad:   0623411990030        Telefone:    (31)2511-1011            E-mail:
E-mail NF-e:     babicalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002895  NATALIO CALCADOS EIRELI - EPP                PADRE BELCHIOR                     112   CENTRO                          30190070 - BELO HORIZONTE - MG
Fantasia:    NATALIO CALCADOS EIRELI - EPP                    CNPJ/CPF:   18.864.943/0001-28      Rep: 22.500     Insc Estad:   0022219870090        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015134  NEW CALCADOS LTDA                        AV ABILIO MACHADO                  1880  ALIPIO DE MELO                    30820622 - BELO HORIZONTE - MG
Fantasia:   NEW CALCADOS                                   CNPJ/CPF:   37.537.303/0001-58      Rep: 22.500     Insc Estad:   0037646210064        Telefone:    (31)3272-7008            E-mail:
E-mail NF-e:    CAL@CAUGUSTO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     31/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006148  NICAELA RAISSA DIAS RODRIGUES 13024301658   RUA SOCRATES                      1006  NAZARE                          31990010 - BELO HORIZONTE - MG
Fantasia:    NICAELA RAISSA DIAS RODRIGUES                  CNPJ/CPF:   22.317.637/0001-49      Rep: 22.500     Insc Estad:   0025472100038        Telefone:    (31)9864-4048            E-mail:
E-mail NF-e:     adrianacalcadosbh@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022298  NOBRELLI CALCADOS LTDA                    R MARIA AMELIA MAIA                 701   SAO BERNARDO                    31741308 - BELO HORIZONTE - MG
Fantasia:    NOBRELLI                                         CNPJ/CPF:   55.412.939/0001-55      Rep: 22.500     Insc Estad:   49099240090           Telefone:    (31) 98726-4393          E-mail:
E-mail NF-e:     nobrellicalcafos@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021050  OFELIA CONFECCOES E COMERCIO LTDA           Rua Lirio Montanhes                   260   Havai                            30555180 - BELO HORIZONTE - MG
Fantasia:   FRANGO BOTAS                                   CNPJ/CPF:   51.306.748/0001-58      Rep: 22.500     Insc Estad:   46573440048           Telefone:    (31) 98891-5375          E-mail:
E-mail NF-e:     frangobotas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012248  ORFEU CALCADOS EIRELI                     RUA DOS CAETÉS                     518   CENTRO                          30120082 - BELO HORIZONTE - MG
Fantasia:   ORFEU CALCADOS EIRELI                           CNPJ/CPF:   34.882.239/0002-35      Rep: 22.500     Insc Estad:   0035452690182        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com;soterrepresentacao3@outlook.com;fl

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 12

Pág. 12 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019786  PEGADA CORAL CALCADOS LTDA                 Rua coronel pedro paulo penido          140   Cidade nova                       31170330 - BELO HORIZONTE - MG
Fantasia:   PEGADA CORAL                                    CNPJ/CPF:   39.273.159/0001-15      Rep: 22.500     Insc Estad:   0038563760068        Telefone:    (31) 97175-0303          E-mail:
E-mail NF-e:     moises@pegadacoral.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007033   PILAR CALCADOS E ACESSORIOS LTDA           R ERICO VERISSIMO                  1916  STA MONICA                       31530400 - BELO HORIZONTE - MG
Fantasia:    PILAR CALCADOS E ACESSORIOS LT                  CNPJ/CPF:   10.197.038/0001-50      Rep: 22.500     Insc Estad:   0010804880093        Telefone:    (31)3452-1579            E-mail:
E-mail NF-e:     pilarcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

012517  PIZZATO COMERCIO DE CALCADOS E ESPORTIVOS LT AVENIDA DOUTOR CRISTIANO GUIMARAES 1833  PLANALTO                         31720300 - BELO HORIZONTE - MG
Fantasia:    PIZZATO COMERCIO                                CNPJ/CPF:   36.620.259/0001-82      Rep: 22.500     Insc Estad:   0036897370029        Telefone:    (31)3455-0089            E-mail:
E-mail NF-e:    WANDERLEIACOUTOLUCIO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     14/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007271  PRESENTE LTDA                             AV BRASIL 800 - LJAS A E B          SN   SÃO LUCAS                        30140000 - BELO HORIZONTE - MG
Fantasia:    PRESENTE LTDA                                   CNPJ/CPF:   00.332.405/0001-27      Rep: 22.500     Insc Estad:   0629089700020        Telefone:    (31)3267-7318            E-mail:
E-mail NF-e:     presentecalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018324  REFERENCIAL DISTRIBUIDORA DE CALCADOS E ROUP RUA ESPIRITO SANTO                 1037  CENTRO                          30160011 - BELO HORIZONTE - MG
Fantasia:   COMPASSO                                       CNPJ/CPF:   42.910.042/0001-00      Rep: 22.500     Insc Estad:   062.816.029/0089      Telefone:    (31) 9224-6651           E-mail:
E-mail NF-e:     compasso.sapatos@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/12/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

021495  REPRESENTACOES JAMIR MACIEL ASSIS LTDA      RUA ITAMBACURI                     139   CARLOS PRATES                    30710480 - BELO HORIZONTE - MG
Fantasia:    JAMIR                                            CNPJ/CPF:   45.601.652/0001-10      Rep: 22.500     Insc Estad:                            Telefone:    (31)9960-22159           E-mail:
E-mail NF-e:    REPRESENTACOESJMA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022126  ROBERTA SARAIVA VILLAR TEODORO              Rua Padre Eustáquio                  1179   Carlos prates                      30710580 - BELO HORIZONTE - MG
Fantasia:   ROBERTA FASHION                                 CNPJ/CPF:   50.945.133/0001-09      Rep: 22.500     Insc Estad:   46335190001           Telefone:    (31) 99155-1593          E-mail:
E-mail NF-e:     robertavillar@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

017400  ROYAL CALCADOS LTDA                      RUA URSULA PAULINO                 1712  BETANIA                          30580002 - BELO HORIZONTE - MG
Fantasia:   AMIGÃO CALCADOS (ROYAL)                        CNPJ/CPF:   47.549.879/0001-99      Rep: 22.500     Insc Estad:   004.415.264/0073      Telefone:   3132728088              E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021118  SANDRO PIRES BERTO LOTTI                    Rua Maria Amelia Maia                 821   Sao Tomaz                        31741171 - BELO HORIZONTE - MG
Fantasia:   SANDRO CALCADOS                                CNPJ/CPF:   36.122.155/0001-48      Rep: 22.500     Insc Estad:   36518220066           Telefone:    (31) 99639-9617          E-mail:
E-mail NF-e:     barataocalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021484  SAPATARIA BH FLORESTA                       Rua pouso alegre                     1088   Floresta                           31015184 - BELO HORIZONTE - MG
Fantasia:    SAPATARIA BH                                    CNPJ/CPF:   39.497.222/0001-05      Rep: 22.500     Insc Estad:   0038731690041        Telefone:    (31) 99319-8825          E-mail:
E-mail NF-e:     diogo.ferreira2013@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003204  SAPATARIA E CAMISARIA RIVIERA LTDA           VISCONDE DE IBITURUNA              240   BARREIRO DE BAIXO                30640080 - BELO HORIZONTE - MG
Fantasia:    SAPATARIA E CAMISARIA RIVIERA                   CNPJ/CPF:   17.487.745/0001-20      Rep: 22.500     Insc Estad:   0620234740050        Telefone:    (31)3384-1860            E-mail:
E-mail NF-e:     gleissonfonseca@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018105  SD COMÉRCIO ONLINE LTDA                   R JORGE CARONE                     36    NOVA CINTRA                      30516030 - BELO HORIZONTE - MG
Fantasia:   SD COMÉRCIO                                     CNPJ/CPF:   32.628.908/0001-30      Rep: 22.500     Insc Estad:   336.843.600/90        Telefone:    (31)85402-2451           E-mail:
E-mail NF-e:    DOUGLAS.RIBEIRO@DALICALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     16/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011773  SEVEN CALCADOS & SPORTS LTDA              RUA ELISIO DE BRITO                 390   BOA VISTA                        31060470 - BELO HORIZONTE - MG
Fantasia:   SEVEN CALCADOS                                 CNPJ/CPF:   34.210.275/0001-71      Rep: 22.500     Insc Estad:   0034924840084        Telefone:    (31)3245-7800            E-mail:
E-mail NF-e:    CALCADOSESPORTSSEVEN@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     31/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 13

Pág. 13 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

004036  SILVANA DE MEDEIROS LUZ SILVA              RUA HERCULANO MOURAO SALAZAR     40    VISTA ALEGRE                     30514430 - BELO HORIZONTE - MG
Fantasia:    SILVANA DE MEDEIROS LUZ SILVA                   CNPJ/CPF:   08.268.786/0001-34      Rep: 22.500     Insc Estad:   0010198700040        Telefone:    (31)3374-7490            E-mail:
E-mail NF-e:     lupecalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018844  STREET STYLE COMERCIO DE CALCADOS,ROUPAS E A Papa leao                              1-5   Ouro minas                        31870160 - BELO HORIZONTE - MG
Fantasia:    STREET                                           CNPJ/CPF:   48.749.549/0001-00      Rep: 22.500     Insc Estad:   004.493.743/0050      Telefone:    (31) 98880-7179          E-mail:
E-mail NF-e:     comprasuniverso1@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021507  TALLYSON RODRIGUES DOS SANTOS              Rua Apio cardoso                     10    Nova contagem                    31050360 - BELO HORIZONTE - MG
Fantasia:   PASSO NOBRE                                     CNPJ/CPF:   37.913.629/0001-32      Rep: 22.500     Insc Estad:   0037959410011        Telefone:    (31) 98858-1699          E-mail:
E-mail NF-e:     mtcomercio01@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003335  TATY CALCADOS LTDA - ME                    TUPINAMBAS                        461   CENTRO                          30120905 - BELO HORIZONTE - MG
Fantasia:    TATY CALCADOS LTDA - ME                         CNPJ/CPF:   00.506.930/0001-11      Rep: 22.500     Insc Estad:   0629244580089        Telefone:    (31)271-6-6224           E-mail:
E-mail NF-e:     michellecalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022275  TIAGO ROGANA FERNANDES                   R POLONIA                          524   JARDIM LEBLON                    31540190 - BELO HORIZONTE - MG
Fantasia:   COPACABANA CALÇADOS                           CNPJ/CPF:   21.764.215/0001-59      Rep: 22.500     Insc Estad:   44480430067           Telefone:    (31) 98877-4844          E-mail:
E-mail NF-e:     helenaafernandess@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011378  TONI CALCADOS EIRELI- EPP LJ F29              AV CRISTIANO MACHADO              4000  UNIAO                            31160900 - BELO HORIZONTE - MG
Fantasia:    TONI CALCADOS EIRELI - LJ F29                     CNPJ/CPF:   28.821.409/0001-98      Rep: 22.500     Insc Estad:   0030575990007        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:    JUNIO@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010644  UNIVERSO CALCADOS E CONFECCOES LTDA       RUA MARCO AURELIO                 30    NAZARE                          31990240 - BELO HORIZONTE - MG
Fantasia:   UNIVERSO CALCADOS E CONFECCOES                CNPJ/CPF:   24.441.847/0001-70      Rep: 22.500     Insc Estad:   0032974170056        Telefone:    (31)88807-7179           E-mail:
E-mail NF-e:     fabianafreewayshoes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003455  VASCONCELOS VAREJISTA DE CALCADOS LTDA - ME RUA ANTONIO JOSÉ DOS SANTOS 665 LO 1     CEU AZUL                         31580000 - BELO HORIZONTE - MG
Fantasia:   VASCONCELOS VAREJISTA DE CALCA                 CNPJ/CPF:   08.272.637/0001-49      Rep: 22.500     Insc Estad:   0010162940009        Telefone:    (31)3447-7062            E-mail:
E-mail NF-e:     lipecalcados@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004291  VENDA NOVA SPORT S EIRELI                  RUA PADRE PEDRO PINTO              3238  MANTIQUEIRA                     31515000 - BELO HORIZONTE - MG
Fantasia:   VENDA NOVA SPORT S EIRELI                       CNPJ/CPF:   71.479.687/0001-38      Rep: 22.500     Insc Estad:   0628756250010        Telefone:    (31)453-3-3391           E-mail:
E-mail NF-e:     vendanovasportes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021122  VERONA ACESSORIOS DA MODA LTDA            AVENIDA SEBASTIAO DE BRITO         646   DONA CLARA                      31260000 - BELO HORIZONTE - MG
Fantasia:    VIA CAT                                          CNPJ/CPF:   52.744.509/0001-42      Rep: 22.500     Insc Estad:   0047507760030        Telefone:    (31) 9984-7475           E-mail:
E-mail NF-e:     tpz@trapeziobolsas.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021121   VIA CAT MAGAZINE EIRELI                    RUA IZABEL BUENO                   784   SANTA ROSA                      31255754 - BELO HORIZONTE - MG
Fantasia:    VIA CAT                                          CNPJ/CPF:   18.730.779/0001-66      Rep: 22.500     Insc Estad:   0022084550041        Telefone:    (31) 9984-7475           E-mail:
E-mail NF-e:     tpz@trapeziobolsas.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014134  VILMAR APARECIDO DIAS DE CARVALHO          RUA TUPINAMBAS                    855   CENTRO                          30120070 - BELO HORIZONTE - MG
Fantasia:   BH CALÇADOS                                     CNPJ/CPF:   40.340.600/0001-13      Rep: 22.500     Insc Estad:   0039366670024        Telefone:    (31)91798-8786           E-mail:
E-mail NF-e:    BH.CALCADOSADM@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021038   VITAL ESPORTES E CALCADOS                   Rua dos rupinambas                   687   Centro                            30120074 - BELO HORIZONTE - MG
Fantasia:    VITAL CALCADOS                                  CNPJ/CPF:   37.551.646/0001-77      Rep: 22.500     Insc Estad:   0037656820078        Telefone:    (31) 99983-1841          E-mail:
E-mail NF-e:     vitalcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 14

Pág. 14 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

000507  VITORIA COMERCIO DE CALCADOS E CONFECCOES LT TUPINAMBAS                        772   CENTRO                          30120070 - BELO HORIZONTE - MG
Fantasia:    VITORIA COMERCIO DE CALCADOS E                 CNPJ/CPF:   06.944.533/0001-08      Rep: 22.500     Insc Estad:   0622080530045        Telefone:    (31)3271-3606            E-mail:
E-mail NF-e:     vitoria.comercio@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     23/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014849  W B CALÇADOS E ACESSÓRIOS LTDA             AV CRISTIANO MACHADO              4000  UNIÃO                            31160900 - BELO HORIZONTE - MG
Fantasia:   SUPER CONFORT                                   CNPJ/CPF:   26.104.131/0001-02      Rep: 22.500     Insc Estad:   0028254850046        Telefone:    (31)3654-3454            E-mail:
E-mail NF-e:    SUPERCOMFORT.FINANCEIRO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018665  WFA MULTIMARCAS OUTLET                     Rua lagoa da prata 1084               1084  Sagrada familia                    30550000 - BELO HORIZONTE - MG
Fantasia:   SALVADOS WFA MULTIMARCAS                      CNPJ/CPF:   42.649.307/0002-49      Rep: 22.500     Insc Estad:   0040906200105        Telefone:    (31) 97341-1380          E-mail:
E-mail NF-e:     kerchsalvados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006498  WMA COMERCIO VAREJISTA DE CALCADOS E ARTIGO AV ABILIO MACHADO 1928 - LOJA A    SN    ALIPIO DE MELO                    30820622 - BELO HORIZONTE - MG
Fantasia:   WMA COMERCIO VAREJISTA DE CALC                 CNPJ/CPF:   06.307.810/0001-71      Rep: 22.500     Insc Estad:   0622949940047        Telefone:    (31)3464-4479            E-mail:
E-mail NF-e:     comercial@malibuesportes.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010369   ZILA APARECIDA ALVES                      RUA CIBIPURUNA                     165   MONTE AZUL                      31872780 - BELO HORIZONTE - MG
Fantasia:    ZILA APARECIDA ALVES                             CNPJ/CPF:   64.323.199/0001-71      Rep: 22.500     Insc Estad:   0627165020054        Telefone:    (31)3434-1964            E-mail:
E-mail NF-e:     armarinhozila@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011266   LUIZ LUCIO DA PAIXAO                      RUA MILTON CAMPOS                 288   PERPETUO SOCORRO                35196000 - BELO ORIENTE - MG
Fantasia:    LUIZ LUCIO DA PAIXAO                             CNPJ/CPF:   03.862.855/0001-10      Rep: 22.751     Insc Estad:   0630884360058        Telefone:    (31)3240-1365            E-mail:
E-mail NF-e:     rosa-variedades@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019119   SILVA E DUTRA COMERCIAL LTDA               RUA PRIMEIRO DE MARÇO              519   CENTRO                          35195000 - BELO ORIENTE - MG
Fantasia:    LOJA POPULAR                                    CNPJ/CPF:   02.005.991/0001-20      Rep: 22.751     Insc Estad:   0637570540068        Telefone:    (31)9971-66390           E-mail:
E-mail NF-e:     lojapopular519@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021155  CESAR CORDEIRO BARROSO                        Coronel Amaral                      36    Centrom                          39640000 - BERILO - MG
Fantasia:   OPCOES                                          CNPJ/CPF:   44.318.366/0001-89      Rep: 22.941     Insc Estad:   004.203.309/0060      Telefone:    (33) 98818-1696          E-mail:
E-mail NF-e:     detinhaberilo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003755  MARIA NEUZA DE SALES MURTA - ME             ANTONIO C AMARAL                  32    CENTRO                          39640000 - BERILO - MG
Fantasia:   MARIA NEUZA DE SALES MURTA - M                  CNPJ/CPF:   12.434.531/0001-71      Rep: 22.941     Insc Estad:   0016511390071        Telefone:    (33)3737-1130            E-mail:
E-mail NF-e:     amaralemurta@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017394  MARIA SUELI FRANCISCO SOUZA               RUA JOAO CIRCUNCISAO AMARAL       91    CENTRO                          39640000 - BERILO - MG
Fantasia:   MARIA SUELI FRANCISCO SOUZA                    CNPJ/CPF:   02.295.116/0001-20      Rep: 22.941     Insc Estad:   065.260.599/0086      Telefone:   33988589130             E-mail:
E-mail NF-e:     suelilojaberilo79@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016297  ARLETE GOMES PEREIRA                      RUA LUIZ TEIXEIRA                   184   CENTRO                          39875000 - BERTÓPOLIS - MG
Fantasia:    ARLETE GOMES PEREIRA                            CNPJ/CPF:   21.479.254/0001-04      Rep: 22.941     Insc Estad:   0024727510057        Telefone:    (33)3636-1464            E-mail:
E-mail NF-e:    ARLETEGP123@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007696  AMARILDO SOUZA CALCADOS LTDA ME           AV AMAZONAS                      585   CENTRO                          32600055 - BETIM - MG
Fantasia:   MANIA DO SAPATO                                 CNPJ/CPF:   26.117.350/0001-26      Rep: 22.500     Insc Estad:   0028266220018        Telefone:    (31)99721-1213           E-mail:
E-mail NF-e:    AMARILDOITAPORE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020912  ANA CAROLINA MEDEIROS FLOREZ SLU LTDA       RUA RIO DE JANEIRO                  579   Centro                            32600224 - BETIM - MG
Fantasia:    IMPORIUM.FEMME                                  CNPJ/CPF:   49.942.423/0001-10      Rep: 22.500     Insc Estad:   0045702250095        Telefone:    (31) 9859-7538           E-mail:
E-mail NF-e:     anacarolinaflorez48@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 15

Pág. 15 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

010300  ATENAS ESPORTES EIRELI                     AV GOVERNADOR VALADARES 2 - LOJA  SN   CENTRO                          32600216 - BETIM - MG
Fantasia:   ATENAS ESPORTES EIRELI                          CNPJ/CPF:   21.559.103/0003-28      Rep: 22.500     Insc Estad:   0024804660267        Telefone:    (31)3272-9582            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007068  BETIM CALCADOS LTDA ME                    AV AMAZONAS 539 C               SN   CENTRO                          32600055 - BETIM - MG
Fantasia:    BETIM CALCADOS LTDA ME                          CNPJ/CPF:   13.617.545/0001-93      Rep: 22.500     Insc Estad:   0017702650060        Telefone:    (31)3392-4990            E-mail:
E-mail NF-e:     marilenecotrim@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005809  CALCADOS SOARES E RAMALHO LTDA ME          AV CAMPOS DE OURIQUE              1584  JARDIM DAS ALTEROSAS 1 SECAO     32670708 - BETIM - MG
Fantasia:   CALCADOS SOARES E RAMALHO LTDA                CNPJ/CPF:   05.968.452/0001-85      Rep: 22.500     Insc Estad:   0672649330030        Telefone:    (31)3592-8809            E-mail:
E-mail NF-e:     calcadosramalho@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007579  DOMINGOS MARTINS SALES                   AV BELO HORIZONTE                 867   JD TERESOPOLIS                   32681505 - BETIM - MG
Fantasia:   DOMINGOS MARTINS SALES                         CNPJ/CPF:   01.635.286/0001-44      Rep: 22.500     Insc Estad:   0676931190007        Telefone:    (31)3591-4022            E-mail:
E-mail NF-e:     lojas-martins@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018630  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  AV GOVERNADOR VALADARES          296   CENTRO                          32600222 - BETIM - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0118-61      Rep: 22.500     Insc Estad:   620.135.548/992       Telefone:    (31)9846-84608           E-mail:
E-mail NF-e:     loja112@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020405  ERICA RANIARA ROCHA DA SILVA MUNIZ 0475811658 Av das acacias                       700   Jardim das alterosas                 32673178 - BETIM - MG
Fantasia:   ENOK CALCADOS                                  CNPJ/CPF:   41.862.969/0001-59      Rep: 22.500     Insc Estad:   404.191.500/64        Telefone:    (31) 3595-4285           E-mail:
E-mail NF-e:     enokfreitas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016629  IZALENE COSTA SALES                       AV CAMPOS DE OURIQUE              1635  JARDIM DAS ALTEROSAS             32670705 - BETIM - MG
Fantasia:    LOJAS MARTINS                                   CNPJ/CPF:   34.178.054/0001-63      Rep: 22.500     Insc Estad:   0034901120077        Telefone:    (31)9870-3502            E-mail:
E-mail NF-e:    LOJAS-MARTINS@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     02/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019485  LESSA CALCADOS E ESPORTES LTDA              Av rio madeira                       217   Santa cruz                        32667365 - BETIM - MG
Fantasia:    LESSA CALCADOS                                  CNPJ/CPF:   43.508.317/0001-46      Rep: 22.500     Insc Estad:   0041469600064        Telefone:    (31) 99218-3705          E-mail:
E-mail NF-e:     lessacalcadoseesportes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010954  MARAVILHA CALCADOS EIRELI - F32            ROD BR 381 FERNAO DIAS,           SN   SAO JOAO                         32655505 - BETIM - MG
Fantasia:   MARAVILHA CALCADOS - F32                        CNPJ/CPF:   31.949.031/0001-17      Rep: 22.500     Insc Estad:   003.311.725/0034      Telefone:    (37)3213-0306            E-mail:
E-mail NF-e:    JUNIO@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011711  MERCADO DOS PÉS                          AV DAS ACÁCIAS                     630   JARDIM DAS ALTEROSAS             32673178 - BETIM - MG
Fantasia:   MERCADO DOS PÉS LTDA                           CNPJ/CPF:   37.083.384/0001-63      Rep: 22.500     Insc Estad:   0037256780044        Telefone:    (31)89025-5139           E-mail:
E-mail NF-e:     mercadodospes@outlook.com.br;mercadodospes@outlook.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021444  ROSAMELIA DOS SANTOS ALVES MARTINS         Rua lucio duarte                      39    Embirucu                         32677140 - BETIM - MG
Fantasia:   ROSAMELIA CALCADOS                             CNPJ/CPF:   31.973.208/0001-10      Rep: 22.500     Insc Estad:   0033137810043        Telefone:    (31) 98779-0106          E-mail:
E-mail NF-e:     romiclaisson@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002874  CASA SAO JUDAS TADEU LTDA - ME             RUA DOS OPERARIOS                 4     CENTRO                          36600000 - BICAS - MG
Fantasia:   CASA SAO JUDAS TADEU                            CNPJ/CPF:   17.721.887/0001-00      Rep: 13.734     Insc Estad:   0690712730051        Telefone:    (32)3271-1288            E-mail:
E-mail NF-e:    CASASJTADEU@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     31/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010862  GUEDES E MATOS LTDA                      RUA SANTA TEREZA 156 LOJA B       SN   CENTRO                          36600000 - BICAS - MG
Fantasia:   GUEDES E MATOS LTDA                             CNPJ/CPF:   65.090.227/0001-10      Rep: 13.734     Insc Estad:   0697447020000        Telefone:    (32)3271-2251            E-mail:
E-mail NF-e:     sapekaloja@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 16

Pág. 16 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

002960  MACIEL PAULA PEREIRA - ME                   JOÃO JULIO DE FARIA                 475   NOVA ERA                         37170000 - BOA ESPERANÇA - MG
Fantasia:    MACIEL PAULA PEREIRA - ME                        CNPJ/CPF:   21.705.756/0001-06      Rep: 21.564     Insc Estad:   0024946740031        Telefone:    (35)851-1-1772           E-mail:
E-mail NF-e:     camilasilvamonte@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003024   SILVA ANTUNES CALCADOS LTDA                PRACA SANTA CRUZ                   113   CENTRO                          37170000 - BOA ESPERANÇA - MG
Fantasia:    SILVA ANTUNES CALCADOS LTDA                    CNPJ/CPF:   07.895.127/0001-65      Rep: 21.564     Insc Estad:   0010049580043        Telefone:    (35)3851-2151            E-mail:
E-mail NF-e:     viaexpressa1@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018938  THIAGO VINICIOS SANTOS                      Rua jarbas pimenta                   482   Nova era                          37170000 - BOA ESPERANÇA - MG
Fantasia:   CALCADOS AUDACIA                               CNPJ/CPF:   31.374.905/0001-55      Rep: 21.564     Insc Estad:   003.265.273/0002      Telefone:    (35) 99971-0673          E-mail:
E-mail NF-e:     contato@audaciacalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004295  WBJ CALCADOS E VESTUARIO LTDA ME           AV JOAO JULIO DE FARIA              155   CENTRO                          37170000 - BOA ESPERANÇA - MG
Fantasia:   WBJ CALCADOS E VESTUARIO LTDA                  CNPJ/CPF:   14.559.143/0001-42      Rep: 21.564     Insc Estad:   0018660510054        Telefone:    (35)3851-3574            E-mail:
E-mail NF-e:     diovanifigueiredo@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009344  CALCADOS BOCAIUVA LTDA - ME               RUA JOAO BENTO CALDEIRA            12    CENTRO                          39390000 - BOCAIÚVA - MG
Fantasia:   SUPER LOJA 123 CALCADOS                         CNPJ/CPF:   00.912.890/0001-08      Rep: 22.941     Insc Estad:   0739509070081        Telefone:    (38)98049-9855           E-mail:
E-mail NF-e:    MAULEOMLC@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019439  FARIA CALCADOS LTDA                         Rua Joao Bento Caldeira               15     Centro                            39390000 - BOCAIÚVA - MG
Fantasia:    FARIA STORE                                      CNPJ/CPF:   21.489.331/0001-07      Rep: 22.941     Insc Estad:   0733106900056        Telefone:    (38) 3251-1040           E-mail:
E-mail NF-e:     comprasfariasboc@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

000028  GDLA COMERCIO DE CALCADOS E CONFECCOES LTDA AV FRANCISCO DUMONT              66    CENTRO                          39390000 - BOCAIÚVA - MG
Fantasia:   GDLA COMERCIO DE CALCADOS E CO                 CNPJ/CPF:   05.590.909/0001-60      Rep: 22.941     Insc Estad:   0732272310009        Telefone:    (38)3251-3040            E-mail:
E-mail NF-e:     comprasboc@fariastore.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016645  MARIA JOSÉ DE FARIA                        PRACA WANDICK DUMONT             70    CENTRO                          39390000 - BOCAIÚVA - MG
Fantasia:    TOTAL CALCADOS                                  CNPJ/CPF:   07.966.071/0001-92      Rep: 22.941     Insc Estad:   0010059790091        Telefone:    (38)3251-4696            E-mail:
E-mail NF-e:    TOTAL.CALCADOS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021497   F & R REPRESENTACOES                      R do Rosario                         68     Centro                            35630005 - BOM DESPACHO - MG
Fantasia:    F & R REPRESENTACOES                            CNPJ/CPF:   50.743.513/0001-60      Rep: 21.564     Insc Estad:                            Telefone:    (55)5555-5                E-mail:
E-mail NF-e:    menezesfrank2@gmail.comm

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008721  MENEZES CALCADOS LTDA - EPP                RUA DOUTOR MIGUEL GONTIJO         109   CENTRO                          35600000 - BOM DESPACHO - MG
Fantasia:   MENEZES CALCADOS LTDA - EPP                     CNPJ/CPF:   06.978.455/0001-62      Rep: 21.564     Insc Estad:   0743095420002        Telefone:    (37)3522-3939            E-mail:
E-mail NF-e:     lojasfonte@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013829  REGIANE LUZIA APARECIDA PAULA              AV DOM SILVERIO                    85    CENTRO                          37310000 - BOM JARDIM DE MINAS - MG
Fantasia:    DI PAULA CALCADOS                               CNPJ/CPF:   20.503.024/0001-70      Rep: 22.619     Insc Estad:   0023827800030        Telefone:    (32)98454-4331           E-mail:
E-mail NF-e:    PRIMOS@PRIMOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     06/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020921  IVANA MARIA SILVA LIMA                           Praca Joao Ourives Torres              200   Centro                            37948000 - BOM JESUS DA PENHA - MG
Fantasia:    LOJA DO VANDERLEI                               CNPJ/CPF:   51.275.609/0001-04      Rep: 21.564     Insc Estad:   0046552040024        Telefone:    (35) 99965-3103          E-mail:
E-mail NF-e:     loja_vanderlei@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007121  ANA LUCIA MAGALHAES MOTTA - ME             VEREADOR ANTONIO JOSÉ DIAS         55    CENTRO                          35908000 - BOM JESUS DO AMPARO - MG
Fantasia:   ANA LUCIA MAGALHAES MOTTA - ME                 CNPJ/CPF:   00.244.742/0001-62      Rep: 22.751     Insc Estad:   0779104910084        Telefone:    3.138.331.343            E-mail:
E-mail NF-e:     adbrinquedosmm@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 17

Pág. 17 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021487  GRAZIELE DE OLIVEIRA MIRANDA VIANA           Rua vereador jose da silva jacob         110   Centro                            35340000 - BOM JESUS DO GALHO - MG
Fantasia:    ESSENCIAL                                       CNPJ/CPF:   40.425.129/0001-66      Rep: 22.751     Insc Estad:   0039425890005        Telefone:    (33) 99903-0079          E-mail:
E-mail NF-e:     grazielemiranda@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016561  DIRLENE PEREIRA DA SILVA                    AV GOVERNADOR BENEDITO VALADARES  45    CENTRO                          35480000 - BONFIM - MG
Fantasia:    DIRLENE MODAS                                   CNPJ/CPF:   07.852.123/0001-08      Rep: 21.495     Insc Estad:   0010014250071        Telefone:    (31)98130-0424           E-mail:
E-mail NF-e:    DIRLENEMODAS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002852  LOJA DA AIDA LTDA - ME                     GOVERNADOR BENEDITO VALADARES    240   CENTRO                          35521000 - BONFIM - MG
Fantasia:    LOJA DA AIDA LTDA - ME                           CNPJ/CPF:   11.867.425/0001-19      Rep: 21.495     Insc Estad:   0015874800042        Telefone:    (31)3576-1210            E-mail:
E-mail NF-e:     lojadaaida@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018856  SAMANNTHA BRAGA E SOUZA 12215455667        Rua Dom Elizeu                      459   Centro                            38650000 - BONFINÓPOLIS DE MINAS - MG
Fantasia:   PASSO FIRME CALCADOS                           CNPJ/CPF:   44.439.071/0001-60      Rep: 13.734     Insc Estad:   0042633120075        Telefone:    (38) 9923-9944           E-mail:
E-mail NF-e:     passofirme.bonfim@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021638  ADINA ADAIANE FERREIRA                     AV MAJOR ANTONIO ALBERTO FERNANDES 318   Centro                            37720000 - BOTELHOS - MG
Fantasia:    PEZINHO                                         CNPJ/CPF:   25.226.844/0001-86      Rep: 21.564     Insc Estad:   002.797.259/0079      Telefone:    (35) 99992-3131          E-mail:
E-mail NF-e:    xande_mmg@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018102  CALCADOS BOM JESUS LTDA                  RUA JOSEFINAPALMA                  60    CENTRO                          39330000 - BRASÍLIA DE MINAS - MG
Fantasia:   CALCADOS BOM JESUS                             CNPJ/CPF:   09.355.289/0001-36      Rep: 22.941     Insc Estad:   001.060.866/0000      Telefone:    (38)98036-6668           E-mail:
E-mail NF-e:     charlesnpmatos@yahoo.com.br

     Obs.:                                                           Proprietário :

Condição de Pagamento:     1 A VISTA
Data Última Compra:     03/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019362   L P SIMOES                                  Rua Coronel Sansao                   281   Centro                            39330000 - BRASÍLIA DE MINAS - MG
Fantasia:    L P SIMOES                                       CNPJ/CPF:   01.534.658/0001-46      Rep: 22.941     Insc Estad:   862290480016         Telefone:    (38) 98826-1124          E-mail:
E-mail NF-e:     darelyconfeccoesbm@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018592  NOE ANTUNES DE SOUZA CONFECCOES LTDA EPP    Rua Coronel Sansao                   372   Centro                            39330000 - BRASÍLIA DE MINAS - MG
Fantasia:                                                     CNPJ/CPF:   86.487.956/0001-85      Rep: 22.941     Insc Estad:   0868881160086        Telefone:    (38) 3231-1771           E-mail:
E-mail NF-e:     comercial@superene.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018586  SILVANA MENDES DA SILVA CONFECCOES LTDA EPP  Rua Coronel Sansao                   434   Centro                            39330000 - BRASÍLIA DE MINAS - MG
Fantasia:    LOJA QUATRO ESTACOES                           CNPJ/CPF:   05.502.069/0001-37      Rep: 22.941     Insc Estad:   862.181.180/054       Telefone:    (38) 3231-2467           E-mail:
E-mail NF-e:     comercial@superene.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008322  SOUZA E SILVA CONFECCOES LTDA - ME          RUA CORONEL SANSCO                331   CENTRO                          39330000 - BRASÍLIA DE MINAS - MG
Fantasia:   SOUZA E SILVA CONFECCOES LTDA                  CNPJ/CPF:   20.944.624/0001-74      Rep: 22.941     Insc Estad:   002.421.719/0042      Telefone:    (38)3231-2467            E-mail:
E-mail NF-e:     noeantunes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018568  SUPER MEGA CALCADOS LTDA                   Rua Coronel Sansao                   457   Centro                            34330000 - BRASÍLIA DE MINAS - MG
Fantasia:   SUPER MEGA CALCADOS                            CNPJ/CPF:   43.910.584/0001-45      Rep: 22.941     Insc Estad:   0041753210054        Telefone:    (38) 3231-1109           E-mail:
E-mail NF-e:     supermegacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018352  COMERCIAL MANOELA BARCELOS                 Rua Governador Valadares              27     Centro                            35460000 - BRUMADINHO - MG
Fantasia:    COKITEL                                          CNPJ/CPF:   05.444.956/0001-04      Rep: 22.500     Insc Estad:   0902197120089        Telefone:    (31) 3571-1115           E-mail:
E-mail NF-e:     manuellacasuals@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018001  ESTRELA CALCADOS E CONFECCOES LTDA         RUA BARAO DE CAMPO MISTICO         226   CENTRO                          37578000 - BUENO BRANDÃO - MG
Fantasia:   MATTOS CALCADOS                                CNPJ/CPF:   37.649.600/0001-95      Rep: 21.564     Insc Estad:   0037742520087        Telefone:    (35)3471-7980            E-mail:
E-mail NF-e:    ESTRELA@MATTOSCALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     21/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 18

Pág. 18 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018000   LILIAN DO PARAÍSO & CIA LTDA                RUA BARAO DE CAMPO MISTICO         190   CENTRO                          37578000 - BUENO BRANDÃO - MG
Fantasia:    LILIAN DO PARAÍSO                                CNPJ/CPF:   07.811.323/0001-04      Rep: 21.564     Insc Estad:   0919970460084        Telefone:    (35)92052-2233           E-mail:
E-mail NF-e:    LILIANPARAISO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016848  ANDERSON DINIZ DE SA ME                    AVENIDA JUSCELINO KUBITSCHEK       506   CENTRO                          39230000 - BUENÓPOLIS - MG
Fantasia:   A PREFERIDA                                      CNPJ/CPF:   11.545.586/0001-96      Rep: 22.941     Insc Estad:   0015494740048        Telefone:    (38)3756-1654            E-mail:
E-mail NF-e:    DINIZ.SA@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     02/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002905  LOJAO MINAS MODA LTDA - ME                 MANOEL JOAQUIM DE MELO            1010  CENTRO                          39280000 - BURITIZEIRO - MG
Fantasia:    LOJAO MINAS MODA LTDA - ME                      CNPJ/CPF:   06.240.702/0001-29      Rep: 22.941     Insc Estad:   0942928600012        Telefone:    (38)3742-1256            E-mail:
E-mail NF-e:     lojaoservetudo2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003491  C E C MAGAZINE LTDA - ME                   OSCAR ORNELAS                     339   CENTRO                          37880000 - CABO VERDE - MG
Fantasia:   C E C MAGAZINE LTDA - ME                         CNPJ/CPF:   12.600.965/0001-02      Rep: 21.564     Insc Estad:   0016689820017        Telefone:    (35)3736-1417            E-mail:
E-mail NF-e:     jonatascont@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008811  ANGILENE DE CASSIA DIONISIO SILVEIRA - ME     RUA BUENO E PAIVA                  210   CENTRO                          37545000 - CACHOEIRA DE MINAS - MG
Fantasia:    ANGILENE DE CASSIA DIONISIO SI                   CNPJ/CPF:   06.248.840/0001-54      Rep: 21.564     Insc Estad:   972856230095         Telefone:    (35)3472-7607            E-mail:
E-mail NF-e:     lojadalela@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005606  MARIA BERNADETE OLIVEIRA                   ANTONIO PIRES DO PRADO             290   SANTO ANTONIO                   37545000 - CACHOEIRA DE MINAS - MG
Fantasia:   MARIA BERNADETE OLIVEIRA                        CNPJ/CPF:   26.094.201/0001-99      Rep: 21.564     Insc Estad:   0975966580093        Telefone:    (35)3472-1066            E-mail:
E-mail NF-e:     elizangelaod@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014638  CALCADOS PASSO IDEAL LTDA                  AV BERNARDO MASCARENHAS          334   CENTRO                          35770000 - CAETANÓPOLIS - MG
Fantasia:   PASSO IDEAL                                      CNPJ/CPF:   23.752.199/0001-00      Rep: 22.941     Insc Estad:   0995828320045        Telefone:    (31)3714-6975            E-mail:
E-mail NF-e:    RENILDEJESUSFERREIRA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019766  FLANARA CENTER LTDA ME                    AV JOAO PINHEIRO                   3267  Pedra Branca                      34800000 - CAETÉ - MG
Fantasia:    FLANARA CENTER                                  CNPJ/CPF:   71.337.281/0001-10      Rep: 22.500     Insc Estad:   1008507470065        Telefone:    (31) 3651-1576           E-mail:
E-mail NF-e:     flanaracenter@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007457  INEZ ANTONIA DE ARAUJO FERNANDES E CIA LTDA  - AVE CARLOS CRUZ                    293   CENTRO                          34800000 - CAETÉ - MG
Fantasia:    INEZ ANTONIA DE ARAUJO FERNAND                 CNPJ/CPF:   26.358.077/0001-21      Rep: 22.500     Insc Estad:   1006555290053        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     lojasemcensura@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011555  LEME E CIA LTDA                            AVE PREFEITO JOSÉ BARBOSA          489   CENTRO                          37600000 - CAMBUÍ - MG
Fantasia:   LEME E CIA LTDA                                  CNPJ/CPF:   17.927.385/0001-30      Rep: 21.564     Insc Estad:   1061014100027        Telefone:    (35)3431-1619            E-mail:
E-mail NF-e:     julioaleme@globo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009426  CLEAR SERVICE SPORTS LTDA - ME               PCA DOM FERRAO                    2     CENTRO                          37400000 - CAMPANHA - MG
Fantasia:    CLEAR SERVICE SPORTS LTDA - ME                  CNPJ/CPF:   65.119.265/0001-59      Rep: 21.564     Insc Estad:   1097681040029        Telefone:    (35)3261-1195            E-mail:
E-mail NF-e:     paulasoesportes22@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009558  SUELY FERREIRA DA SILVA FERNANDES E CIA LTDA - RUA CORONEL JOSÉ CUSTODIO         425   CENTRO                          37730000 - CAMPESTRE - MG
Fantasia:    SUELY FERREIRA DA SILVA FERNAN                  CNPJ/CPF:   66.346.552/0001-64      Rep: 21.564     Insc Estad:   1103179960049        Telefone:    (31)88311-1712           E-mail:
E-mail NF-e:     sapatariasilva@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021544  JOAQUIM PEDRO ABALEM E COMPANHIA LTDA       Rua, 26                             505   Centro                            38270000 - CAMPINA VERDE - MG
Fantasia:    CALCE CERTO                                     CNPJ/CPF:   25.661.695/0001-83      Rep: 21.496     Insc Estad:   1115984910050        Telefone:    (34) 99997-4471          E-mail:
E-mail NF-e:     jopacrt@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 19

Pág. 19 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

006876  JOSE BRAGA DOS SANTOS CPF 260 111 236-0 - ME DOUTOR GETULIO PORTELA            61    CENTRO                          38970000 - CAMPOS ALTOS - MG
Fantasia:    JOSE BRAGA DOS SANTOS CPF 260                  CNPJ/CPF:   21.905.526/0001-90      Rep: 21.496     Insc Estad:   1154964780010        Telefone:    (37)3426-2091            E-mail:
E-mail NF-e:     lojadobraguinha@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015258  NILLUS CALCADOS LTDA                      RUA CORONEL FREDERICO FRANCO      238   CENTRO                          38970000 - CAMPOS ALTOS - MG
Fantasia:    NILLUS CALCADOS LTDA                            CNPJ/CPF:   02.278.632/0001-47      Rep: 21.496     Insc Estad:   1157291300075        Telefone:    (37)3426-0100            E-mail:
E-mail NF-e:    NILLUSCALCADOS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     06/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008498  SAPATO E CIA                              AV SCO VICENTE DE PAILO 240 A     SN   CENTRO                          37160000 - CAMPOS GERAIS - MG
Fantasia:   SAPATO E CIA                                     CNPJ/CPF:   17.976.411/0001-10      Rep: 21.564     Insc Estad:   0021357040032        Telefone:    (35)88731-1378           E-mail:
E-mail NF-e:     claudiamoreira@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003937  DIVINA GONCALVES DE CARVALHO              RUA SEIS                           598   CENTRO                          38380000 - CANAPOLIS - MG
Fantasia:    DIVINA GONCALVES DE CARVALHO                   CNPJ/CPF:   04.685.461/0001-04      Rep: 21.496     Insc Estad:   1181442790062        Telefone:    (34)9678-1472            E-mail:
E-mail NF-e:     alternativacanapolis@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021757  GAD COMERCIO VAREJISTA LTDA                 RUA,CINCO                          410   CENTRO                          38380000 - CANAPOLIS - MG
Fantasia:   EXPLOSAO MODAS                                 CNPJ/CPF:   01.421.572/0001-07      Rep: 21.496     Insc Estad:   118.984.309/0042      Telefone:    (34) 99972-1598          E-mail:
E-mail NF-e:     explosao-gc@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

001265  ANTONIA MARTINS DOS REIS E CIA LTDA          17 DE DEZEMBRO                    312   CENTRO                          37280000 - CANDEIAS - MG
Fantasia:   ANTONIA MARTINS DOS REIS E CIA                  CNPJ/CPF:   23.318.686/0001-69      Rep: 21.564     Insc Estad:   1205434590078        Telefone:    (35)3833-1008            E-mail:
E-mail NF-e:     toninhacandeias@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021136  EDMAR DOS ANJOS JUNIOR                     Rua conego Jose Antonio Henriques      140   Centro                            36290000 - CAPELA NOVA - MG
Fantasia:   EDMAR CALCADOS                                 CNPJ/CPF:   24.909.535/0001-48      Rep: 13.734     Insc Estad:   0027695810088        Telefone:    (31) 98432-2668          E-mail:
E-mail NF-e:     edimardosanjosjunior@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018307  ALFA SHOES LTDA                             Rua Getulio Vargas                    70     Centro                            39680000 - CAPELINHA - MG
Fantasia:   MODERNA CALCADOS                              CNPJ/CPF:   46.868.916/0001-69      Rep: 22.751     Insc Estad:   004.371.787/0092      Telefone:    (33) 99108-4054          E-mail:
E-mail NF-e:     aranasc@uai.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005555  LOJA SANAS LTDA                         GOVERNADOR VALADARES             21    CENTRO                          39680000 - CAPELINHA - MG
Fantasia:    LOJA SANAS LTDA                                 CNPJ/CPF:   18.126.128/0001-61      Rep: 22.751     Insc Estad:   1234053190073        Telefone:    (33)3516-1232            E-mail:
E-mail NF-e:     aa.samp@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

002948  M E V CALCADOS E CONFECCOES LTDA - ME       GOVERNADOR VALADARES             141   CENTRO                          39680000 - CAPELINHA - MG
Fantasia:   M E V CALCADOS E CONFECCOES LT                  CNPJ/CPF:   18.738.519/0001-37      Rep: 22.751     Insc Estad:   0022092580019        Telefone:    (37)3231-6801            E-mail:
E-mail NF-e:    IMPACTOCALCADOS@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015758  JOSANE COSTA DA SILVEIRA                  RUA DONA NENÊ                     404   CENTRO                          37993000 - CAPETINGA - MG
Fantasia:   JOSANE MODAS E PRESENTES                       CNPJ/CPF:   03.154.209/0001-06      Rep: 21.564     Insc Estad:   1240220170090        Telefone:    (35)3543-1267            E-mail:
E-mail NF-e:    JOSANEMODAS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019791  RAFAEL ROSSA LEITE GUARNIERI                 Rua Evaristo Teodoro de Souza          527   Centro                            37993000 - CAPETINGA - MG
Fantasia:    CALCE BEM CALCADOS E ACESSORIO                 CNPJ/CPF:   29.510.970/0001-19      Rep: 21.564     Insc Estad:   003.116.429/0096      Telefone:    (35) 98411-8854          E-mail:
E-mail NF-e:     calcebemdecapetinga@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021674  ROSEVELT HENRIQUE LOURENÇO                   AV. VICENTE DE PAULA FONTOURA       21    CENTRO                          38360000 - CAPINÓPOLIS - MG
Fantasia:   ROSA DE SARON                                   CNPJ/CPF:   06.934.613/0001-82      Rep: 21.496     Insc Estad:   1263037080012        Telefone:    (34) 99973-9496          E-mail:
E-mail NF-e:     rosevelt-vanessa@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 20

Pág. 20 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017618  DANIELLE GONÇALVES BATISTA EIRELI           AV BURARAMA                       313   CENTRO                          39472000 - CAPITÃO ENÉAS - MG
Fantasia:   AKASO CALCADOS                                 CNPJ/CPF:   31.327.012/0001-59      Rep: 22.941     Insc Estad:   0032614670022        Telefone:    (38)98291-1854           E-mail:
E-mail NF-e:    AKASO1020@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022295  MARIA CRISTINA GONÇALVES PEREIRA           AV BURARAMA                       164   CENTRO                          39472000 - CAPITÃO ENÉAS - MG
Fantasia:    LOJA DA CRISTINA                                 CNPJ/CPF:   36.452.227/0001-15      Rep: 22.941     Insc Estad:   36769580098           Telefone:    (38) 99939-5243          E-mail:
E-mail NF-e:     maria.cristina2011@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021127  ALEX SILVA OLIVEIRA                          Av castelo Branco                     419   Centro                            39810000 - CARAÍ - MG
Fantasia:    NEIDE CALCADOS                                  CNPJ/CPF:   47.331.658/0001-40      Rep: 1          Insc Estad:   44022950064           Telefone:    (33) 98845-7965          E-mail:
E-mail NF-e:     neidebiu@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017935  ERISMAR FERREIRA NOBRE                    RUA JOSÉ VICENTE COIMBRA           230   CENTRO                          39810000 - CARAÍ - MG
Fantasia:   NOBRE CALCADOS                                 CNPJ/CPF:   12.565.533/0001-08      Rep: 22.941     Insc Estad:   0016653620093        Telefone:    (33)88447-7871           E-mail:
E-mail NF-e:    ERISMARFERREIRANOBRE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     26/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014473  CARLA LUCIANA DE MEDEIROS                 RUA CANDIDO SARAIVA NOGUEIRA      89    PONTILHAO                       36280000 - CARANDAÍ - MG
Fantasia:   MALUK SHOES                                     CNPJ/CPF:   11.056.312/0002-14      Rep: 22.619     Insc Estad:   0013464110192        Telefone:    (32)3361-3246            E-mail:
E-mail NF-e:    MALUKSHOESCARANDAI@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     02/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022219   HELIESLIA ORRANA DA COSTA CAMPOS           RUA MAJOR JOAO ROCHA              51    CENTRO                          36280069 - CARANDAÍ - MG
Fantasia:   TOP CALCADOS                                    CNPJ/CPF:   38.440.612/0001-78      Rep: 22.619     Insc Estad:   0038384910065        Telefone:    (32) 99181-1113          E-mail:
E-mail NF-e:     topcalcados2018@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005336  A SENTINELA LTDA                           AVE OLEGARIO MACIEL                286   CENTRO                          35300000 - CARATINGA - MG
Fantasia:   A SENTINELA LTDA                                 CNPJ/CPF:   19.313.972/0001-64      Rep: 22.751     Insc Estad:   1340294290070        Telefone:    (33)3321-3050            E-mail:
E-mail NF-e:     asentinelaltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011317  G G ATACADISTA DE CALCADOS LTDA            RODOVIA BR 458 KM                 136   PARQUE DO RIO DOCE               35300970 - CARATINGA - MG
Fantasia:   G G ATACADISTA DE CALCADOS LTD                 CNPJ/CPF:   00.850.762/0002-68      Rep: 22.751     Insc Estad:   3139466890174        Telefone:    (31)3821-0338            E-mail:
E-mail NF-e:     gg.pedidos@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011053  IRMAOS ARAUJO LTDA                         PCA DOM PEDRO II                   26    CENTRO                          35300033 - CARATINGA - MG
Fantasia:   IRMAOS ARAUJO LTDA                              CNPJ/CPF:   19.323.385/0001-56      Rep: 22.751     Insc Estad:   1340330610025        Telefone:    (33)3321-2154            E-mail:
E-mail NF-e:     irmaosaraujo@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022336  JONEILSON DE OLIVEIRA PEREIRA              R MIGUEL DE CASTRO                 23    CENTRO                          35300028 - CARATINGA - MG
Fantasia:   CARATINGA VARIEDADES                          CNPJ/CPF:   19.982.193/0001-51      Rep: 22.751     Insc Estad:   002.334.505/0030      Telefone:    (33) 9963-2012           E-mail:
E-mail NF-e:     fisoterapia6@live.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

015470  MULTICOISAS COMÉRCIO VAREJISTA LTDA        RUA RAUL SOARES                    252   CENTRO                          35300020 - CARATINGA - MG
Fantasia:    MULTICOISAS COMÉRCIO VAREJISTA                 CNPJ/CPF:   24.474.498/0001-92      Rep: 22.751     Insc Estad:   0027330670014        Telefone:    (33)99748-8635           E-mail:
E-mail NF-e:    PASTORJOELFREITAS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008836  CASA VIEIRA COSTA LTDA - EPP                RUA MESTRE ROQUE                  435   CENTRO                          39665000 - CARBONITA - MG
Fantasia:   CASA VIEIRA COSTA LTDA - EPP                     CNPJ/CPF:   42.914.010/0001-82      Rep: 22.941     Insc Estad:   1358178140057        Telefone:    (38)3526-1241            E-mail:
E-mail NF-e:     casavieiracosta@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019732   LUIZ ROBERTO PEREIRA                           Avenida Januario Ribeiro               415   Centro                            39665000 - CARBONITA - MG
Fantasia:   JONATHANS MODAS                                CNPJ/CPF:   00.659.087/0001-03      Rep: 22.941     Insc Estad:   1359349850011        Telefone:    (38) 99809-0503          E-mail:
E-mail NF-e:     jonathansmodas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 21

Pág. 21 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016760   ELIETE RODRIGUES DE OLIVEIRA               RUA JOÃO BATISTA DA SILVA           21    CENTRO                          39864000 - CARLOS CHAGAS - MG
Fantasia:    ELIETE RODRIGUES                                CNPJ/CPF:   19.393.971/0001-77      Rep: 22.751     Insc Estad:   0022764370091        Telefone:    (33)99391-1181           E-mail:
E-mail NF-e:    FABIOOLIVEIRA1951@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016275  VALTOIR DE OLIVEIRA FERREIRA                PRACA NELSON SARAIVA               12    CENTRO                          39864000 - CARLOS CHAGAS - MG
Fantasia:    VALTOIR DE OLIVEIRA FERREIRA                     CNPJ/CPF:   23.984.222/0001-91      Rep: 22.751     Insc Estad:   1375518290014        Telefone:    (33)91970-0870           E-mail:
E-mail NF-e:     terraeagua@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003139  GONTIJO CALCADOS LTDA - EPP                 TIRADENTES                        226   CENTRO                          35510000 - CARMO DO CAJURU - MG
Fantasia:    GONTIJO CALCADOS LTDA - EPP                     CNPJ/CPF:   23.390.529/0001-64      Rep: 21.564     Insc Estad:   1425439220089        Telefone:    (37)3244-1170            E-mail:
E-mail NF-e:     gontijo-calcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008015  DOUGLAS DA COSTA OLIVEIRA 08562640670       AV FREI GABRIEL                    877   PARNAIBA                         38840000 - CARMO DO PARANAÍBA - MG
Fantasia:   DOUGLAS DA COSTA OLIVEIRA 0856                 CNPJ/CPF:   27.976.239/0001-58      Rep: 21.496     Insc Estad:   0029865550091        Telefone:    (34)3851-4704            E-mail:
E-mail NF-e:     pechik4704@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

013678  JANETE BRAZ DE LIMA                        AV DOUTOR ARISTIDES DE MELO        16    CENTRO                          38840000 - CARMO DO PARANAÍBA - MG
Fantasia:    JANETE BRAZ DE LIMA                              CNPJ/CPF:   16.998.597/0001-45      Rep: 21.496     Insc Estad:   0027274000020        Telefone:    (34)91120-0007           E-mail:
E-mail NF-e:     cesartriangulo@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006977  REDUR CONFECCOES E CALCADOS LTDA - ME      RUA SCO VICENTE                    791   JK                               38840000 - CARMO DO PARANAÍBA - MG
Fantasia:   REDUR CONFECCOES E CALCADOS LT                CNPJ/CPF:   00.459.071/0001-57      Rep: 21.496     Insc Estad:   1439207650037        Telefone:    (34)3851-1319            E-mail:
E-mail NF-e:     joyce_r_s@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009077  CALUSA CALCADOS LTDA - ME                 RUA DELFIM MOREIRA 133 SALA B     SN   CENTRO                          37150000 - CARMO DO RIO CLARO - MG
Fantasia:   CALUSA CALCADOS LTDA - ME                       CNPJ/CPF:   21.781.194/0001-80      Rep: 21.564     Insc Estad:   0025015840055        Telefone:    (35)3608-0024            E-mail:
E-mail NF-e:     calusacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003684   FREIRE E FERREIRA LTDA - EPP                 RANDOLFO FABRINO                  52    CENTRO                          37150000 - CARMO DO RIO CLARO - MG
Fantasia:    FREIRE E FERREIRA LTDA - EPP                      CNPJ/CPF:   16.939.787/0001-91      Rep: 21.564     Insc Estad:   1443608160000        Telefone:    (35)3561-1358            E-mail:
E-mail NF-e:     compras@freileopoldo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014195  TERRANI MAGAZINE LTDA                     RUA CAMILO ASCHAR                 184   CENTRO                          37150000 - CARMO DO RIO CLARO - MG
Fantasia:    DIFATTO                                          CNPJ/CPF:   07.554.669/0001-74      Rep: 21.564     Insc Estad:   1443783170095        Telefone:    (35)3561-1689            E-mail:
E-mail NF-e:    DIFATTO_KARMO@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003517  MANOEL MACHADO DOS SANTOS E CIA LTDA        LUIS ALVES 92 LOJA                  03    CENTRO                          35534000 - CARMÓPOLIS DE MINAS - MG
Fantasia:   MANOEL MACHADO DOS SANTOS E CI                CNPJ/CPF:   66.398.850/0001-06      Rep: 21.564     Insc Estad:   1454248630052        Telefone:    (37)3333-1464            E-mail:
E-mail NF-e:     calcadoshc@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021723  ELIOMAR NERI DE SOUZA LIMA                 RUA , SAO SEBASTIAO                 579   SAO SEBASTIAO DO PONTAL          38292000 - CARNEIRINHO - MG
Fantasia:    MAISA MODAS                                     CNPJ/CPF:   18.414.092/0001-11      Rep: 21.496     Insc Estad:   0021775980081        Telefone:    (17) 99744-5809          E-mail:
E-mail NF-e:     maisa-modas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007063  MARIA APARECIDA MAHALEM BASTOS             CEL SATURNINO PEREIRA 344 -         354   CENTRO                          37980000 - CÁSSIA - MG
Fantasia:   MARIA APARECIDA MAHALEM BASTOS                CNPJ/CPF:   19.341.163/0001-66      Rep: 21.564     Insc Estad:   1512096740086        Telefone:    (35)3541-1276            E-mail:
E-mail NF-e:     lojadololo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007055  ORIVAR SALGADO BASTOS - ME                CORONEL JOÃO CANDIDO              41    CENTRO                          37980000 - CÁSSIA - MG
Fantasia:    ORIVAR SALGADO BASTOS - ME                     CNPJ/CPF:   20.709.952/0001-96      Rep: 21.564     Insc Estad:   1512767820070        Telefone:    (35)3541-1276            E-mail:
E-mail NF-e:     lojadololo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 22

Pág. 22 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019490  COMERCIO DE CALCADOS ARAUJO LTDA           Rua Tenente Luiz Ribeiro               152    Vila Domingos Lopes                36774034 - CATAGUASES - MG
Fantasia:   O MUNDO DOS CALCADOS                          CNPJ/CPF:   18.962.779/0001-91      Rep: 22.619     Insc Estad:   1531925190020        Telefone:    (32) 3421-3017           E-mail:
E-mail NF-e:     omundodoscalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019941  JEANS E CIA DE CAXAMBU LTDA                    Travessa Nossa Sra Remedios           20     Centro                            37440000 - CAXAMBU - MG
Fantasia:    JEANS E CIA                                      CNPJ/CPF:   41.030.319/0001-47      Rep: 21.564     Insc Estad:   0039852280031        Telefone:    (35) 99115-4435          E-mail:
E-mail NF-e:     jeanscaxambu@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010785  MARIA BERNADETE DE FREITAS CINTRA          RUA MINAS GERAIS                   595   CENTRO                          37997000 - CLARAVAL - MG
Fantasia:   MARIA BERNADETE DE FREITAS CIN                  CNPJ/CPF:   05.321.608/0001-31      Rep: 21.564     Insc Estad:   1642041730010        Telefone:    (34)3353-5318            E-mail:
E-mail NF-e:     maria bernardete52@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019857  EDSON RODRIGUES DOS SANTOS                Rua Santo Antonio                    S/N    Centro                            36550000 - COIMBRA - MG
Fantasia:    ELIANA MODAS                                    CNPJ/CPF:   21.862.897/0001-32      Rep: 13.734     Insc Estad:   25086820006           Telefone:    (32) 99962-6348          E-mail:
E-mail NF-e:     elianasilva1312@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010123  LUCAS GONCALVES QUEIROS 09359022608        RUA SENADOR SIMAO DA CUNHA 44 - CASSN   CENTRO                          39770000 - COLUNA - MG
Fantasia:   LUCAS GONCALVES QUEIROS 093590                 CNPJ/CPF:   34.088.701/0001-46      Rep: 22.751     Insc Estad:   0034825670024        Telefone:    (33)87133-3761           E-mail:
E-mail NF-e:     badallus@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019554  PAULO RENATO FERNANDES                        Praca Herculano Torres                18     Centro                            39770000 - COLUNA - MG
Fantasia:   PAULO RENATO                                    CNPJ/CPF:   66.463.449/0001-02      Rep: 22.751     Insc Estad:   4188364000087        Telefone:    (38) 98407-9775          E-mail:
E-mail NF-e:     contauniao@uai.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008925  GIOVANI DOMINIQUINI - ME                   RUA DOS FUNDADORES                144   CENTRO                          37148000 - CONCEIÇÃO DA APARECIDA - MG
Fantasia:    GIOVANI DOMINIQUINI - ME                        CNPJ/CPF:   41.908.310/0001-96      Rep: 21.564     Insc Estad:   1718046320018        Telefone:    (35)3564-1389            E-mail:
E-mail NF-e:     giovannacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008924  APARECIDA DONIZETI DE SOUZA SILVA - ME       AV BRASIL                          560   CENTRO                          38120000 - CONCEIÇÃO DAS ALAGOAS - MG
Fantasia:    APARECIDA DONIZETI DE SOUZA SI                  CNPJ/CPF:   28.037.936/0001-06      Rep: 21.496     Insc Estad:   0029920010065        Telefone:    (34)96837-7866           E-mail:
E-mail NF-e:     pegadasdechinelo@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019472  CONFECCOES ROTA DO CORPO                     Pc Corinto Guerra                     67     Bendeirinha                       35860000 - CONCEIÇÃO DO MATO DENTRO - MG
Fantasia:   ROTA DO CORPO                                   CNPJ/CPF:   49.351.801/0001-90      Rep: 22.036     Insc Estad:   004.533.630/0063      Telefone:    (33) 99812-0596          E-mail:
E-mail NF-e:     rotadocorpoltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009568  VALDENIA CORREA TRINDADE SANTOS 44843712604 RUA 23 DE MARÇO                    63    CENTRO                          35850000 - CONGONHAS DO NORTE - MG
Fantasia:    VALDENIA CORREA TRINDADE SANTO                CNPJ/CPF:   14.929.317/0001-11      Rep: 22.941     Insc Estad:   0019037150004        Telefone:    (31)84804-4071           E-mail:
E-mail NF-e:     valdeniasantos12@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014200  GRAZIELLE A O BRAGA LTDA                   AV PRESIDENTE VARGAS               104   CENTRO                          36410066 - CONGONHAS - MG
Fantasia:   BRAGA CALCADOS                                 CNPJ/CPF:   39.480.799/0001-04      Rep: 21.495     Insc Estad:   0038718820042        Telefone:    (31)96865-5534           E-mail:
E-mail NF-e:    GRUPOBRAGA19@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     29/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016452  MARYNELL CALC CONFEC E PRES LTDA ME         BENEDITO QUINTINO                  33    CENTRO                          36415000 - CONGONHAS - MG
Fantasia:   MARYNELL CALÇADOS                              CNPJ/CPF:   08.187.785/0001-65      Rep: 21.495     Insc Estad:   0010147020042        Telefone:    (31)99744-4633           E-mail:
E-mail NF-e:    ESTACAODOSAPATO33@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018385  RN COMERCIAL E NEGOCIOS LTDA                  Avenida Julia Kubitschek               7      Centro                            36415000 - CONGONHAS - MG
Fantasia:   ROUPA NOVA                                      CNPJ/CPF:   45.213.572/0001-97      Rep: 21.495     Insc Estad:   0042648060073        Telefone:    (31) 3731-1282           E-mail:
E-mail NF-e:     roupanovaad@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 23

Pág. 23 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021522  BEATRIZ DE SOUZA PINTO BRAGA                Rua benjamim constant                248   Sao joao                          36401002 - CONSELHEIRO LAFAIETE - MG
Fantasia:   AMORA                                           CNPJ/CPF:   26.392.071/0001-70      Rep: 22.619     Insc Estad:   0028507050034        Telefone:    (31) 97163-9163          E-mail:
E-mail NF-e:     beatrissimiao@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     29/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014026  FAMA CALÇADOS E ACESSÓRIOS LTDA           RUA BARÃO DE COROMANDEL           29    CENTRO                          36400000 - CONSELHEIRO LAFAIETE - MG
Fantasia:   PEQUENOS PASSOS                                CNPJ/CPF:   14.328.837/0001-79      Rep: 21.495     Insc Estad:   0018432330078        Telefone:    (31)3761-4751            E-mail:
E-mail NF-e:    PEQUENOSPASSOS2010@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003643   LEILA PEREIRA FERNANDES TOLENTINO          DOUTOR MELO VIANA                 93    CENTRO                          36400000 - CONSELHEIRO LAFAIETE - MG
Fantasia:    LEILA PEREIRA FERNANDES TOLENT                  CNPJ/CPF:   02.668.199/0001-56      Rep: 21.495     Insc Estad:   1838146200004        Telefone:    (31)3721-3011            E-mail:
E-mail NF-e:     leilacalcados12@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006112  SAPATARIA FUTURISTA LTDA                  RUA DOUTOR MELO VIANA             128   CENTRO                          36400000 - CONSELHEIRO LAFAIETE - MG
Fantasia:    SAPATARIA FUTURISTA LTDA                        CNPJ/CPF:   19.713.387/0001-51      Rep: 21.495     Insc Estad:   1830204880028        Telefone:    (31)3762-5089            E-mail:
E-mail NF-e:     futurista@viareal.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014566  IRMAS RODRIGUES CALCADOS LTDA             PRACA PADRE FRANCISCO V KEMENAD    1743  CENTRO                          35240000 - CONSELHEIRO PENA - MG
Fantasia:    BERE CALCADOS                                   CNPJ/CPF:   33.110.930/0001-57      Rep: 22.751     Insc Estad:   0034067100019        Telefone:    (33)88180-0189           E-mail:
E-mail NF-e:    BERE.CALCADOS2019@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010695  MERCADAO ELIAS E OLIVEIRA LTDA              AVE GETULIO VERGAS                 1692  CENTRO                          35240000 - CONSELHEIRO PENA - MG
Fantasia:   MERCADAO ELIAS E OLIVEIRA LTDA                  CNPJ/CPF:   18.764.803/0001-88      Rep: 22.751     Insc Estad:   1843622090076        Telefone:    (33)3261-1687            E-mail:
E-mail NF-e:    MERCADAODOSCALCAODSLTDA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003719  ARGENTEX LTDA - ME                      MONSENHOR JOÃO MARTINS           1804  NOVO PROGRESSO                  32115000 - CONTAGEM - MG
Fantasia:   ARGENTEX LTDA - ME                              CNPJ/CPF:   17.060.021/0001-03      Rep: 22.500     Insc Estad:   1863623950028        Telefone:    (31)3393-8052            E-mail:
E-mail NF-e:     gildonetoxavier@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019693  BEST SHOES CALCADOS LTDA                   Rua cel mario campos                 19 c    Industrial                         32230050 - CONTAGEM - MG
Fantasia:    BEST SHOES                                      CNPJ/CPF:   49.773.988/0001-10      Rep: 22.500     Insc Estad:   0045597570064        Telefone:    (31) 99117-1249          E-mail:
E-mail NF-e:     ester.gomes.freitas81@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003431  BIG MAGAZIM GUARARAPES LTDA - ME            PRINCESA ISABEL                    260   SÃO JOAQUIM                     32110000 - CONTAGEM - MG
Fantasia:    BIG MAGAZIM GUARARAPES LTDA -                  CNPJ/CPF:   38.475.240/0001-15      Rep: 22.500     Insc Estad:   1866563380070        Telefone:    (31)3357-1766            E-mail:
E-mail NF-e:     bigguararapes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016199  BLANC CALÇADOS E ACESSÓRIOS               AV JUSCELINO KUBITSCHECK           985   INDUSTRIAL                       32230090 - CONTAGEM - MG
Fantasia:   BLANC                                           CNPJ/CPF:   19.644.776/0001-72      Rep: 22.500     Insc Estad:   002.302.070/0060      Telefone:    (31)91168-8911           E-mail:
E-mail NF-e:    CALCADOSBLANC@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006561  CALCADOS MIRANDA LTDA ME                  AV JOSÉ FARIA DA ROCHA             5872  CIDADE JD ELDORADO               32310210 - CONTAGEM - MG
Fantasia:   CALCADOS MIRANDA LTDA ME                       CNPJ/CPF:   18.265.108/0001-71      Rep: 22.500     Insc Estad:   1863954880060        Telefone:    (31)2557-1611            E-mail:
E-mail NF-e:    ninadmadm@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005843  CALCECON CALCADOS LTDA - ME                AV CORONEL DURVAL DE BARROS       954   PARQUE DUVAL DE BARROS          32242310 - CONTAGEM - MG
Fantasia:   CALCECON CALCADOS LTDA - ME                    CNPJ/CPF:   03.922.809/0001-69      Rep: 22.500     Insc Estad:   2980879490053        Telefone:    (31)3385-5169            E-mail:
E-mail NF-e:     armacaoautentic@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004770  CHAVES CALCADOS LTDA                     RUA APIO CARDOSO                  740   NOVA CONTAGEM                   32050360 - CONTAGEM - MG
Fantasia:   CHAVES CALCADOS LTDA                           CNPJ/CPF:   07.660.026/0001-05      Rep: 22.500     Insc Estad:   1863940740058        Telefone:    (31)3356-8112            E-mail:
E-mail NF-e:     chavescalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 24

Pág. 24 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

008298  COMERCIAL ELVIA EIRELI                     RUA HUNGRIA                       14    ELDORADO                        32341440 - CONTAGEM - MG
Fantasia:   COMERCIAL ELVIA EIRELI                           CNPJ/CPF:   23.344.196/0001-37      Rep: 22.500     Insc Estad:   0026332540060        Telefone:    (31)3398-4577            E-mail:
E-mail NF-e:    PATRICIA@FRANKCALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019483  COMERCIAL OLIVIA CHAVES LTDA                AVENIDA JOAO CESAR DE OLIVEIRA      1275  ELDORADO                        32315000 - CONTAGEM - MG
Fantasia:   FRANK CALCADOS                                 CNPJ/CPF:   44.940.991/0001-68      Rep: 22.500     Insc Estad:   0042466220016        Telefone:    (31) 3398-4577           E-mail:
E-mail NF-e:     patricia@frankcalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014641  EDUARDO GOMES CARNEIRO JUNIOR            RUA TIRADENTES                     3005  INDUSTRIAL                       32230025 - CONTAGEM - MG
Fantasia:   CALCADOS E CIA                                  CNPJ/CPF:   39.742.076/0001-28      Rep: 22.500     Insc Estad:   0038923060097        Telefone:    (31)92160-0919           E-mail:
E-mail NF-e:    CALCADOSECIA2020@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     29/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

018623  ELMO CALCADOS S/A - EM RECUPERACAO JUDICIAL  RODOVIA BR-040                     0     GUANABARA                       32150340 - CONTAGEM - MG
Fantasia:   ELMO CALCADOS                                  CNPJ/CPF:   17.170.416/0027-90      Rep: 22.500     Insc Estad:   186.013.554/3951      Telefone:    (31)9846-67758           E-mail:
E-mail NF-e:     loja20@elmo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021048  EMILANA RENATA HONORIO DOS REIS SIQUEIRA    Rua monsenhor joao martins            1745  Novo progresso                    32115000 - CONTAGEM - MG
Fantasia:   ARGENTEX                                        CNPJ/CPF:   46.622.998/0001-67      Rep: 22.500     Insc Estad:   004.355.883/0067      Telefone:    (31) 98231-5585          E-mail:
E-mail NF-e:     emilanarenata@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011222  ENXOVAIS E CIA LTDA                        AVE AGUA BRANCA 957 - NUM ALTERNATI 9     JARDIM BANDEIRANTES              32371190 - CONTAGEM - MG
Fantasia:   ENXOVAIS E CIA LTDA                              CNPJ/CPF:   02.661.513/0001-79      Rep: 22.500     Insc Estad:   1867968090086        Telefone:    (31)3394-8675            E-mail:
E-mail NF-e:     mileniommodas@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010446  FOX CALCADOS EIRELI                       RUA EXTREMA 78 B                SN   GUANARARA                       32115260 - CONTAGEM - MG
Fantasia:   FOX CALCADOS EIRELI                             CNPJ/CPF:   31.534.798/0002-66      Rep: 22.500     Insc Estad:   0032780070153        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000030  GIOVANNI JANGOLA MOREIRA EIRELI            AGUA BRANCA                       854   JARDIM BANDEIRANTES              32371190 - CONTAGEM - MG
Fantasia:    GIOVANNI JANGOLA MOREIRA EIRE                  CNPJ/CPF:   08.741.139/0001-06      Rep: 22.500     Insc Estad:   0010353780081        Telefone:    (31)3598-1555            E-mail:
E-mail NF-e:     francomatos@live.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003327  INDUSTRIA E COMERCIO STAR LTDA - ME         ANTONIO JOSÉ DA COSTA FERREIRA     226   NACIONAL                        32185010 - CONTAGEM - MG
Fantasia:    INDUSTRIA E COMERCIO STAR LTDA                 CNPJ/CPF:   64.247.356/0001-07      Rep: 22.500     Insc Estad:   1866570850035        Telefone:    (31)3397-1526            E-mail:
E-mail NF-e:     varejao_calcados@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006813  KARINA VEST LTDA - ME                      RUA CORCOVADO 401 B             SN    RIACHO DAS PEDRAS                32285000 - CONTAGEM - MG
Fantasia:    KARINA VEST LTDA - ME                            CNPJ/CPF:   04.835.061/0001-20      Rep: 22.500     Insc Estad:   1861790080048        Telefone:    (31)3313-7837            E-mail:
E-mail NF-e:     lojasmeirece@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022129  LANNA MODAS E CALÇADOS LTDA                Rua simonesia                       260    Industrial São Luís                  32073100 - CONTAGEM - MG
Fantasia:   LANNA MODAS                                    CNPJ/CPF:   29.834.825/0001-93      Rep: 22.500     Insc Estad:   003.142.572/0048      Telefone:    (31) 99643-0796          E-mail:
E-mail NF-e:     lannamodas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003915  LAYLA COMERCIO DE CALCADOS LTDA - ME        RUA REFINARIA DUQUE DE CAXIAS      441   PETROLANDIA                      32072170 - CONTAGEM - MG
Fantasia:    LAYLA COMERCIO DE CALCADOS LTD                 CNPJ/CPF:   06.915.108/0001-90      Rep: 22.500     Insc Estad:   1863049260052        Telefone:    (31)3397-5226            E-mail:
E-mail NF-e:     layla@ig.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019622  LOH CALCADOS PODOLOGIA E ACESSORIOS LTDA    Avenida General David Sarnoff          5160  Cidade Industrial                   32210110 - CONTAGEM - MG
Fantasia:   SUPER COMFORT MINAS                            CNPJ/CPF:   39.697.817/0001-04      Rep: 22.500     Insc Estad:   0038888630058        Telefone:    (31) 99361-8502          E-mail:
E-mail NF-e:     wscjunior@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 25

Pág. 25 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003920  MARCIA MARIA MACEDO TEIXEIRA              RUA MONSENHOR JOÃO MARTINS        2021  NOVO PROGRESSO 2SECA            32115000 - CONTAGEM - MG
Fantasia:   MARCIA MARIA MACEDO TEIXEIRA                   CNPJ/CPF:   00.426.575/0001-70      Rep: 22.500     Insc Estad:   1869161680047        Telefone:    (31)3393-7575            E-mail:
E-mail NF-e:     natybaldow@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007701  MARCO ANTONIO E RODRIGO CALCADOS E ESPORTES RUA VP-1                           1336  NOVA CONTAGEM                   32050030 - CONTAGEM - MG
Fantasia:   MARCO ANTONIO E RODRIGO CALCAD                CNPJ/CPF:   16.904.699/0001-54      Rep: 22.500     Insc Estad:   0020334510040        Telefone:    (31)3913-2167            E-mail:
E-mail NF-e:     marcoantonioerodrigo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005607  MARIA DAS MERCES ROCHA                      JUDITH NAVES DE LIMA                819   SANTA EDWIGES                   32040275 - CONTAGEM - MG
Fantasia:   MARIA DAS MERCES ROCHA                         CNPJ/CPF:   16.693.436/0001-43      Rep: 22.500     Insc Estad:   0020119690012        Telefone:   318612009                E-mail:
E-mail NF-e:     mariadasmercesrose@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017320  MODAPE CALÇADOS LTDA                     RUA MANDARIM                      108   JARDIM DIA LAGO                  32145415 - CONTAGEM - MG
Fantasia:   MODAPE CALÇADOS                                CNPJ/CPF:   45.095.748/0001-53      Rep: 22.500     Insc Estad:   0042569130010        Telefone:    (31)3222-9095            E-mail:
E-mail NF-e:    MODAPE.CALCADOS.M@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006558  NINA CALCADOS LTDA ME                      PCA NOSSA SENHORA DA CONCEICAO    197   NOVO ELDORADO                   32341250 - CONTAGEM - MG
Fantasia:    NINA CALCADOS LTDA ME                           CNPJ/CPF:   00.558.814/0001-46      Rep: 22.500     Insc Estad:   1869267960000        Telefone:    (31)3391-1098            E-mail:
E-mail NF-e:    ninadmadm@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018332  NUBIA DIAS CALçADOS LTDA                    Av vp1                             1506  Nova contagem                    32050030 - CONTAGEM - MG
Fantasia:   SKRUPLUS MODAS                                 CNPJ/CPF:   44.721.679/0001-83      Rep: 22.500     Insc Estad:   423.227.200/11        Telefone:    (31) 99654-1997          E-mail:
E-mail NF-e:     skrupluscalcados2018@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003219  RICARDO ALVES DOS SANTOS - ME                VP-1                               1306  NOVA CONTAGEM                   32050030 - CONTAGEM - MG
Fantasia:   RICARDO ALVES DOS SANTOS - ME                  CNPJ/CPF:   07.936.903/0001-28      Rep: 22.500     Insc Estad:   0010026860031        Telefone:    (31)3393-2698            E-mail:
E-mail NF-e:     skrupluscalcados@terra.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

018111  SALIANA SUELLEN DA SILVA                   AV PADRE JOAQUIM MARTINS           115   ALVORADA                        32042200 - CONTAGEM - MG
Fantasia:   SS CALÇADOS E ACESSÓRIOS                       CNPJ/CPF:   44.799.422/0001-44      Rep: 22.500     Insc Estad:   42374930084           Telefone:    (31)84617-7227           E-mail:
E-mail NF-e:     suellen86@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     23/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003616  SEMPRE MODAS LTDA - ME                   BUENO DO PRADO                    218   JARDIM LAGUNA 3SECAO             32140220 - CONTAGEM - MG
Fantasia:   SEMPRE MODAS LTDA - ME                          CNPJ/CPF:   02.864.159/0001-80      Rep: 22.500     Insc Estad:   1860154230033        Telefone:    (31)3357-7898            E-mail:
E-mail NF-e:     sempre-modas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007067  TOQ TOQ CALCADOS LTDA ME                   JOSÉ AUGUSTO ROCHA 444 - LOJA      03    SANTA HELENA                     32015110 - CONTAGEM - MG
Fantasia:   TOQ TOQ CALCADOS LTDA ME                       CNPJ/CPF:   41.941.733/0001-08      Rep: 22.500     Insc Estad:   1868029770050        Telefone:    (31)3398-3555            E-mail:
E-mail NF-e:     toqtoqcalcados@ibest.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004256  W E N CALCADOS LTDA                      RUA TIRADENTES 2616 - ANDAR 001 LOJA 03    INDUSTRIAL                       32235250 - CONTAGEM - MG
Fantasia:  W E N CALCADOS LTDA                             CNPJ/CPF:   42.864.777/0001-44      Rep: 22.500     Insc Estad:   0628076040093        Telefone:    (31)3361-4978            E-mail:
E-mail NF-e:     sapatariapedeanjo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

014847  WENCESLAU DOS SANTOS COIMBRA JÚNIOR ME    AV SEVERINO BALLESTEROS RODRIGUES 850   RESSACA                         32110005 - CONTAGEM - MG
Fantasia:   SUPER CONFORT                                   CNPJ/CPF:   34.324.851/0001-01      Rep: 22.500     Insc Estad:   0035014320066        Telefone:    (31)2585-2002            E-mail:
E-mail NF-e:    SUPERCOMFORT.FINANCEIRO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000502  ZEZE CALCADOS LTDA - EPP                    TIRADENTES                        2569  INDUSTRIAL                       32230020 - CONTAGEM - MG
Fantasia:    ZEZE CALCADOS LTDA - EPP                         CNPJ/CPF:   20.106.001/0001-22      Rep: 22.500     Insc Estad:   1862654930036        Telefone:    (31)3361-2811            E-mail:
E-mail NF-e:     contato@zezecalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 26

Pág. 26 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017386  ADILSON SÉRGIO GARCIA                     RUA DR ANTÔNIO ALVARENGA          128   CENTRO                          39200000 - CORINTO - MG
Fantasia:   ADILSON CALCADOS                               CNPJ/CPF:   10.522.990/0001-81      Rep: 22.941     Insc Estad:   001.102.734/0008      Telefone:   3837512940              E-mail:
E-mail NF-e:     asgcorinto@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003806  COMERCIAL PAULA E RESENDE LTDA - ME         DOUTOR ANTONIO ALVARENGA         154   CENTRO                          39200000 - CORINTO - MG
Fantasia:   BARBOSA CALCADOS                               CNPJ/CPF:   19.819.432/0001-57      Rep: 22.941     Insc Estad:   1910646590058        Telefone:    (38)3751-1803            E-mail:
E-mail NF-e:    CALCADOSBARBOSA@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017415  ARAUJO SILVEIRA COMERCIO DE CALCADOS LTDA   GERSON COUTINHO DA SILVA 735      735   CENTRO                          38550000 - COROMANDEL - MG
Fantasia:    SEBASTIÃO DOS REIS ARAÚJO                       CNPJ/CPF:   17.676.842/0001-60      Rep: 21.496     Insc Estad:   193.399.520/0037      Telefone:    (34)3841-2325            E-mail:
E-mail NF-e:     nunesdesfile@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008124  CAMILA CONCEICAO BRAGA DE PAULA 08924479660 RUA ZACARIAS ROQUE                38    CENTRO                          35170025 - CORONEL FABRICIANO - MG
Fantasia:    CAMILA CONCEICAO BRAGA DE PAUL                 CNPJ/CPF:   14.871.604/0001-18      Rep: 22.751     Insc Estad:   0018982110070        Telefone:    (31)3841-5522            E-mail:
E-mail NF-e:     brunobritess@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019720  CASTRO E TRISTAO COMERCIO LTDA              Rua coronel silvino pereira              105   Centro                            35170039 - CORONEL FABRICIANO - MG
Fantasia:    DIRETORIO                                       CNPJ/CPF:   09.089.787/0001-84      Rep: 22.751     Insc Estad:   0010437000036        Telefone:    (31) 98782-1340          E-mail:
E-mail NF-e:     visualmodas20@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011265  CENTRAL COMERCIO DE CALCADOS LTDA         RUA CORONEL SILVINO PEREIRA        88    CENTRO                          35170039 - CORONEL FABRICIANO - MG
Fantasia:    CENTRAL COMERCIO DE CALCADOS L                 CNPJ/CPF:   08.243.497/0001-80      Rep: 22.751     Insc Estad:   0010134850076        Telefone:    (31)86741-1972           E-mail:
E-mail NF-e:    CENTRAL.COMCALCADOSLTDA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010444  COMERCIAL VALE DO ACO LTDA                RUA MARIA MATOS                   406   CENTRO                          35170111 - CORONEL FABRICIANO - MG
Fantasia:   COMERCIAL VALE DO ACO LTDA                     CNPJ/CPF:   31.357.380/0001-40      Rep: 22.751     Insc Estad:   0032639510037        Telefone:    (31)98674-1786           E-mail:
E-mail NF-e:     comercialvaledoacoltda@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011717  MARCELA DOS SANTOS SILVA 00252099656        AVENIDA DOUTOR JOSE DE MAGALHAES PI 1764  GIOVANNI                         35170097 - CORONEL FABRICIANO - MG
Fantasia:   MARCELA DOS SANTOS                             CNPJ/CPF:   34.707.054/0001-03      Rep: 22.751     Insc Estad:   0035310360093        Telefone:    (31)87547-7792           E-mail:
E-mail NF-e:    NAYARASILVASANTOS15@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003696  MARIA APARECIDA FERREIRA SASAOKA LTDA      BELO HORIZONTE                    264   CALADINHO                       35171167 - CORONEL FABRICIANO - MG
Fantasia:    CIDINHA CALCADOS                                CNPJ/CPF:   11.865.156/0001-51      Rep: 22.751     Insc Estad:   0015871830048        Telefone:    (31) 98834-8071          E-mail:
E-mail NF-e:     marcelo@shimadzu.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020655  QUELEM NEIVA DE ALMEIDA PEREIRA             Rua Euzebio de Brito                  14     Centro                            35170170 - CORONEL FABRICIANO - MG
Fantasia:   TABARATO CALCADOS                              CNPJ/CPF:   33.289.871/0001-26      Rep: 22.751     Insc Estad:   0034193770044        Telefone:    (31) 98678-0114          E-mail:
E-mail NF-e:     fellipebp@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014576  TABARATO CALCADOS E CONFECCOES LTDA       RUA JOSE CORNELIO                  177   CENTRO                          35170008 - CORONEL FABRICIANO - MG
Fantasia:    TA BARATO                                       CNPJ/CPF:   33.325.685/0001-03      Rep: 22.751     Insc Estad:   0034220850082        Telefone:    (31)86780-0114           E-mail:
E-mail NF-e:    FELLIPEBP@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017652  DANILA KRISTINA DIAS DE OLIVEIRA            RUA VEREADORA ENIVIA GOMES DE SOUZA43    CENTRO                          39569000 - CURRAL DE DENTRO - MG
Fantasia:   LAURA CALCADOS                                 CNPJ/CPF:   34.846.239/0001-07      Rep: 22.941     Insc Estad:   0035424840086        Telefone:    (38)99094-4824           E-mail:
E-mail NF-e:    LORENAMARCIADIAS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020760  GNA COMERCIO DE CALCADOS LTDA                Avenida Dom Pedro II                 420   Centro                            35790210 - CURVELO - MG
Fantasia:    RABELLO CALCADOS                               CNPJ/CPF:   47.564.218/0001-32      Rep: 22.941     Insc Estad:   0044158520096        Telefone:    (38) 3502-0877           E-mail:
E-mail NF-e:     rabellocalcadoscvo2@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 27

Pág. 27 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020066   H. OTTONE MOREIRA                           Av Deputado Renato Azeredo           88     Bela vista                         35796177 - CURVELO - MG
Fantasia:    ZELIA MODAS                                     CNPJ/CPF:   48.306.317/0001-87      Rep: 22.941     Insc Estad:   44647260054           Telefone:    (38) 99921-6128          E-mail:
E-mail NF-e:     postobelavista1995@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003910  IRMAOS FERNANDES LTDA - MTZ                AV DOM PEDRO II                    399   CENTRO                          35790000 - CURVELO - MG
Fantasia:   IRMAOS FERNANDES LTDA - MTZ                    CNPJ/CPF:   19.986.298/0001-89      Rep: 21.495     Insc Estad:   2090288100098        Telefone:    (38)3721-1900            E-mail:
E-mail NF-e:     irmaosfernandesltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004292  VITOR FERNANDES CALCADOS LTDA - ME          AV DOM PEDRO II                    381   CENTRO                          35790000 - CURVELO - MG
Fantasia:    VITOR FERNANDES CALCADOS LTDA                  CNPJ/CPF:   41.745.571/0001-32      Rep: 22.941     Insc Estad:   2097870900090        Telefone:    (38)3721-2717            E-mail:
E-mail NF-e:     lidervitor@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004294  W M Z DOS SANTOS LTDA                    RUA PACÍFICO MASCARENHAS          118   CENTRO                          35790132 - CURVELO - MG
Fantasia:  W M Z DOS SANTOS LTDA                           CNPJ/CPF:   03.545.250/0001-03      Rep: 22.941     Insc Estad:   2090546030054        Telefone:    (38)3721-8190            E-mail:
E-mail NF-e:    CONTABFERNANDOCOSTA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     31/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013830   LIDIANE APARECIDA FERREIRA                 RUA PEDRO JOSÉ VENÂNCIO DE ANDRADE 860   CENTRO                          37910000 - DELFINÓPOLIS - MG
Fantasia:    VILLA CALÇADOS                                  CNPJ/CPF:   38.819.696/0001-55      Rep: 21.564     Insc Estad:   0038490530017        Telefone:    (35)84150-0346           E-mail:
E-mail NF-e:    LIVCALCADOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018375  ADRIEL MENDES 05131346622                      rua teofilo andrade                    76     centro                            35494000 - DESTERRO DE ENTRE RIOS - MG
Fantasia:    ALE CALCADOS                                    CNPJ/CPF:   31.356.821/0001-99      Rep: 13.734     Insc Estad:   326.391.200/50        Telefone:    (32) 3736-1403           E-mail:
E-mail NF-e:     alessandra16a16@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009342  MAR E SIR COMERCIO LTDA - EPP               RUA SAO JOSE                       59    CENTRO                          39735000 - DIVINOLÂNDIA DE MINAS - MG
Fantasia:   MAR E SIR COMERCIO LTDA - EPP                    CNPJ/CPF:   05.980.363/0001-54      Rep: 22.751     Insc Estad:   2222627880056        Telefone:    (33) 98887-1237          E-mail:
E-mail NF-e:     maresircalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016387  ATUAL CALCADOS EIRELI                      AV PRIMEIRO DE JUNHO               597   CENTRO                          35500003 - DIVINÓPOLIS - MG
Fantasia:   KATUXA                                          CNPJ/CPF:   28.898.638/0002-91      Rep: 21.564     Insc Estad:   0030640330193        Telefone:    (37) - 9- 8838 8223       E-mail:
E-mail NF-e:     janete@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     28/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005391  BELA VISTA COMERCIO CALCADOS LTDA          RUA GUAPE                         945   SÃO JOSÉ                         35501251 - DIVINÓPOLIS - MG
Fantasia:    BELA VISTA COMERCIO CALCADOS L                 CNPJ/CPF:   86.645.041/0001-50      Rep: 21.564     Insc Estad:   2239079290050        Telefone:    (37)3212-1223            E-mail:
E-mail NF-e:     belavistacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004714  CALCADOS ALVORADA DIVINOPOLIS LTDA         RUA GOIAS                          406   CENTRO                          35500001 - DIVINÓPOLIS - MG
Fantasia:   CALCADOS ALVORADA LTDA                         CNPJ/CPF:   20.143.186/0001-45      Rep: 21.564     Insc Estad:   2230370150067        Telefone:    (37)3221-6755            E-mail:
E-mail NF-e:    CALCADOSALVORADA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019879   ELITE DOS PéS                                     Av. Parana                          852   São Jose                          35501170 - DIVINÓPOLIS - MG
Fantasia:    ELITE DOS PéS                                    CNPJ/CPF:   18.065.504/0001-55      Rep: 21.564     Insc Estad:   214.387.600/94        Telefone:    (37) 98839-1027          E-mail:
E-mail NF-e:     contatoelitedospes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014348  ESTILO MULHER CONFECÇÕES LTDA             AV PRIMEIRO DE JUNHO               555   CENTRO                          35500003 - DIVINÓPOLIS - MG
Fantasia:    SAPATARIA AVENIDA                               CNPJ/CPF:   05.194.573/0001-17      Rep: 21.564     Insc Estad:   0016090930091        Telefone:    (37)3214-4060            E-mail:
E-mail NF-e:    SA_ESCRITORIO@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000446  MIX MINAS DISTRIBUIDORA LTDA - ME            GOIAS                             2719  IPIRANGAORION                    35502027 - DIVINÓPOLIS - MG
Fantasia:    MIX MINAS DISTRIBUIDORA LTDA -                  CNPJ/CPF:   09.448.084/0001-03      Rep: 21.564     Insc Estad:   0010650600053        Telefone:    (37)3221-4966            E-mail:
E-mail NF-e:     mixminasdistribuidora@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 28

Pág. 28 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

000682  VOA DISTRIBUIDORA LTDA                      RIO DE JANEIRO                     2910  RANCHO ALEGRE                   35502456 - DIVINÓPOLIS - MG
Fantasia:   VOA DISTRIBUIDORA LTDA                          CNPJ/CPF:   65.381.725/0001-12      Rep: 21.564     Insc Estad:   2237571670030        Telefone:    (37)3221-4440            E-mail:
E-mail NF-e:     juquinhaprata@voadistribuidora.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022205  THASSIA NASCIMENTO COURA                 R SAO LUIZ                         201   PONTILHAO                       35440000 - DOM SILVÉRIO - MG
Fantasia:    TEALCE                                           CNPJ/CPF:   18.390.281/0001-00      Rep: 22.619     Insc Estad:   002.175.2960017       Telefone:    (31) 99869-0758          E-mail:
E-mail NF-e:     realceds@yahoo.com.br

     Obs.:                                                           Proprietário :

Condição de Pagamento:     49 60 DD
Data Última Compra:     30/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007114  MAGAZINE MARCIA LTDA                    DOUTOR EDGARD PINTO FIUZA         356   ROSARIO                         35610000 - DORES DO INDAIÁ - MG
Fantasia:   MAGAZINE MARCIA                                CNPJ/CPF:   38.600.995/0001-02      Rep: 21.564     Insc Estad:   2326770170069        Telefone:    (37)3551-2468            E-mail:
E-mail NF-e:    MARIAAUXILIADORAECALDAS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009109  RODRIGO ALVES CPF 929 714 906-53 - ME        RUA BENEDITO VALADARES            38    CENTRO                          35610000 - DORES DO INDAIÁ - MG
Fantasia:   RODRIGO ALVES CPF 929 714 906-                   CNPJ/CPF:   05.788.742/0001-47      Rep: 21.564     Insc Estad:   2322850100055        Telefone:    (37)3551-3775            E-mail:
E-mail NF-e:     rodrigoalves44@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019454  SUPERMERCADO GATTO E GATTO LTDA            Rua Padre Joao Pina do Amaral          87     Centro                            35130000 - ENGENHEIRO CALDAS - MG
Fantasia:   COMERCIAL GATTO                                CNPJ/CPF:   09.596.296/0001-20      Rep: 22.751     Insc Estad:   10728550091           Telefone:    (33) 99800-9751          E-mail:
E-mail NF-e:     josuegatto@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021817  LOJA CARDOSO LTDA                        R doutor joao vaz                     687   Centro                            35490000 - ENTRE RIOS DE MINAS - MG
Fantasia:    LOJA CARDOSO                                    CNPJ/CPF:   22.245.864/0001-06      Rep: 22.619     Insc Estad:   2395145140028        Telefone:    (31) 99723-8585          E-mail:
E-mail NF-e:     camilasantosoli@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020908  GISLENE DE SOUZA PIMENTEL                   Rua Monsenhor Rodolfo 29193230044    69     Centro                            36555000 - ERVÁLIA - MG
Fantasia:    GISLENE DE SOUZA PIMENTEL                       CNPJ/CPF:   27.171.936/0001-31      Rep: 22.619     Insc Estad:   002.919.323/0044      Telefone:    (32) 99986-1499          E-mail:
E-mail NF-e:     valquiriasmodas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022196   IVAIR JOSE RODRIGUES                      R VEREADOR GERALDO LOPES          18    BELA VISTA                       36555000 - ERVÁLIA - MG
Fantasia:    ELE E ELA                                         CNPJ/CPF:   05.559.068/0001-29      Rep: 22.619     Insc Estad:   2402274340088        Telefone:    (32) 98483-1084          E-mail:
E-mail NF-e:     ivairerodrigues@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010800  MARIA IVANA PAES                         RUA VEREADOR GERALDO LOPES 190 LJ ASN    BELA VISTA                       36555000 - ERVÁLIA - MG
Fantasia:   MARIA IVANA PAES                                CNPJ/CPF:   28.488.051/0001-23      Rep: 22.619     Insc Estad:   0030295350091        Telefone:    (32)3554-2117            E-mail:
E-mail NF-e:     lojadavaninha@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003846  DAN VILLE COMERCIO DE CALCADOS LTDA        RUA SENADOR MELO VIANA            39    CENTRO                          35740000 - ESMERALDAS - MG
Fantasia:   DAN VILLE COMERCIO DE CALCADOS                 CNPJ/CPF:   38.496.311/0001-66      Rep: 22.500     Insc Estad:   2416575920010        Telefone:    (31)3538-1674            E-mail:
E-mail NF-e:     marlicalcados.39@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017411  ANTENOR ALVES DE FARIAS E CIA LTDA          RUA CORONEL HEITOR ANTUNES        79    CENTRO                          39510000 - ESPINOSA - MG
Fantasia:   CASA DOS CALCADOS                              CNPJ/CPF:   41.725.482/0001-24      Rep: 22.941     Insc Estad:   243.787.025/0039      Telefone:    (38)3812-1356            E-mail:
E-mail NF-e:     lucianomagalhaesalves@gmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007803  DOMINGOS ANTUNES DOS SANTOS - ME          RUA BAHIA                          84    CENTRO                          39510000 - ESPINOSA - MG
Fantasia:   DOMINGOS ANTUNES DOS SANTOS -                 CNPJ/CPF:   18.865.758/0001-58      Rep: 22.941     Insc Estad:   2431950260078        Telefone:    (38)3812-1539            E-mail:
E-mail NF-e:     pdantunes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003857  HUDSON CARLOS DE SOUZA E CIA LTDA          RUA DA BAHIA                       84    CENTRO                          39510000 - ESPINOSA - MG
Fantasia:   HUDSON CARLOS DE SOUZA E CIA L                 CNPJ/CPF:   16.537.125/0001-95      Rep: 22.941     Insc Estad:   0019986200083        Telefone:    (38)9182-2622            E-mail:
E-mail NF-e:     hudsoncalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 29

Pág. 29 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

008151  JOMAR CALCADOS DE ESPINOSA LTDA           RUA DA BAHIA                       29    CENTRO                          39510000 - ESPINOSA - MG
Fantasia:   JOMAR CALCADOS                                 CNPJ/CPF:   18.420.710/0001-36      Rep: 22.941     Insc Estad:   002.178.177/0000      Telefone:    (38)9915-37216           E-mail:
E-mail NF-e:     ferreira.sidiney@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003512  JUSCELIO D DE OLIVEIRA - ME                 CORONEL HEITOR ANTUNES            14    CENTRO                          39510000 - ESPINOSA - MG
Fantasia:    JUSCELIO D DE OLIVEIRA - ME                      CNPJ/CPF:   13.829.432/0001-51      Rep: 22.941     Insc Estad:   0017913280077        Telefone:    (38)3812-1586            E-mail:
E-mail NF-e:     brazconte@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021725  KAMILA GONçALVES DE PAULA                      rua juvenal ribeiro                    160    jardim oriente                      39510000 - ESPINOSA - MG
Fantasia:    MILLY                                            CNPJ/CPF:   30.350.348/0001-70      Rep: 22.941     Insc Estad:   003.183.840/0052      Telefone:    (38) 99863-7395          E-mail:
E-mail NF-e:     millyshoes@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022007  MAGALHAES ALVES CALCADOS E ACESSORIOS       pc cel heitor antunes                  79     centro                            39510000 - ESPINOSA - MG
Fantasia:   MA                                               CNPJ/CPF:   57.341.758/0001-00      Rep: 22.941     Insc Estad:   004.996.763/0051      Telefone:    (38) 99957-3773          E-mail:
E-mail NF-e:     bompresente.salinas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017156  WISHIN CONFECCOES, CALCADOS E ACESSORIOS LT RUA VEREADOR ANTÔNIO ZAMARIONI    115   DA PONTE ALTA                    37640000 - EXTREMA - MG
Fantasia:   WISHIN                                          CNPJ/CPF:   06.185.744/0007-08      Rep: 22.824     Insc Estad:   0042871250057        Telefone:    (11)3255-5342            E-mail:
E-mail NF-e:    TESOURARIA@WISHIN.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2024                                                                                                          Marca da Última compra :212-WISHIN

021174  CLEUSA PEDROSO DA SILVA                     Rua Alagoas                         28     Alvorada                          35572060 - FORMIGA - MG
Fantasia:   MOCAL SHOES                                     CNPJ/CPF:   46.218.620/0001-00      Rep: 21.564     Insc Estad:   43304120041           Telefone:    (37) 99153-3982          E-mail:
E-mail NF-e:     micalce@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005133   VIA NELLO CALCADOS LTDA                   BERNARDES DE FARIA                 72    CENTRO                          35570000 - FORMIGA - MG
Fantasia:    VIA NELLO CALCADOS EIRELI - EP                    CNPJ/CPF:   03.315.135/0001-34      Rep: 21.564     Insc Estad:   2610364030082        Telefone:    (37)3071-5040            E-mail:
E-mail NF-e:     nfe22@g3v.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017407  CLESIO C & K LTDA EPP                      RUA DIREITA                        238   CENTRO                          39644000 - FRANCISCO BADARÓ - MG
Fantasia:    CLESIO C&K                                       CNPJ/CPF:   41.664.228/0001-63      Rep: 22.941     Insc Estad:   265.779.183/0039      Telefone:    (33)9882-89010           E-mail:
E-mail NF-e:     clesiock@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021160  MARIA SALETE SIMOES                         Rua Direta                          192   Centro                            39644000 - FRANCISCO BADARÓ - MG
Fantasia:   MARIA SALETE                                    CNPJ/CPF:   00.424.956/0001-10      Rep: 22.941     Insc Estad:   2659528640072        Telefone:    (33) 98730-1528          E-mail:
E-mail NF-e:     simoes.salete@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016525  DELMA PEREIRA GLÓRIA ME                   RUA SAFIRA                         58    ALTO ESPERANÇA                   39387000 - FRANCISCO DUMONT - MG
Fantasia:   DELMA MODAS                                    CNPJ/CPF:   08.374.791/0001-21      Rep: 22.941     Insc Estad:   0010310820006        Telefone:    (38)99515-5968           E-mail:
E-mail NF-e:    DELMAMODAS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016853  WASHINGTON JOAQUIM LOPES SANTOS           AV ODILON LOURES                   143   CENTRO                          39387000 - FRANCISCO DUMONT - MG
Fantasia:    ARLETE CONFECCOES                              CNPJ/CPF:   23.215.098/0001-08      Rep: 22.941     Insc Estad:   2665767170022        Telefone:    (38)99886-6263           E-mail:
E-mail NF-e:    ARLLETECONFECCOES@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     02/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003168  RCN CALCADOS E CONFECCOES LTDA - ME        MONTES CLAROS                     1155  CENTRO                          39580000 - FRANCISCO SÁ - MG
Fantasia:   RCN CALCADOS E CONFECCOES LTDA                CNPJ/CPF:   02.243.332/0001-22      Rep: 22.941     Insc Estad:   2677266620086        Telefone:    (38)3233-1311            E-mail:
E-mail NF-e:     rcn.rosilene@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020365  ROCHA ALVES E LIMA LTDA                      Alameda Montes Claros                1112  Centro                            39580000 - FRANCISCO SÁ - MG
Fantasia:   REMESON PERSONAL                               CNPJ/CPF:   02.900.226/0001-74      Rep: 22.941     Insc Estad:   2670040280059        Telefone:    (38) 3233-1251           E-mail:
E-mail NF-e:     remesonpersonalsportweear@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 30

Pág. 30 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020276  THIANNA CONFECCAO LTDA                      Alameda Montes Claros                1153  Centro                            39580000 - FRANCISCO SÁ - MG
Fantasia:   THIANNA                                         CNPJ/CPF:   05.484.272/0001-28      Rep: 22.941     Insc Estad:   2672199650093        Telefone:    (38) 99216-2228          E-mail:
E-mail NF-e:     vanessalaisse@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017955  FARMÁCIA FERNANDES LTDA                   AV DESEMBARGADOR LUCIANO SOUZA LIM2     CENTRO                          35112000 - FREI INOCÊNCIO - MG
Fantasia:   DROGARIA LUZ                                    CNPJ/CPF:   18.953.364/0001-51      Rep: 22.751     Insc Estad:   2691258220117        Telefone:    (33)84331-1004           E-mail:
E-mail NF-e:    FARMALUZFREI@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     12/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014194  RODRIGO CARMO DOS SANTOS                 AV JOSE FERREIRA                   93    CENTRO                          38230000 - FRONTEIRA - MG
Fantasia:   RODRIGO CARMO DOS SANTOS                      CNPJ/CPF:   27.296.560/0001-91      Rep: 21.496     Insc Estad:   0029295100042        Telefone:    (34) 99213-4150          E-mail:
E-mail NF-e:     rodrigo.skinadamoda@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022097  CARLOS VICTOR LOPES BLARD 02889576604       AVENIDA 21 DE DEZEMBRO             875   CENTRO                          36152000 - GOIANA - MG
Fantasia:   AQUARELA                                        CNPJ/CPF:   22.853.889/0001-92      Rep: 22.619     Insc Estad:   25925760018           Telefone:    (32) 99911-2260          E-mail:
E-mail NF-e:     carlosvictorlb@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014908  ALIANCA COMÉRCIO DE CALCADOS LTDA - LOJA 708 RUA ISRAEL PINHEIRO                 2714  CENTRO                          35010130 - GOVERNADOR VALADARES - MG
Fantasia:    ALIANCA COMÉRCIO DE CALCADOS -                 CNPJ/CPF:   38.249.713/0001-66      Rep: 22.751     Insc Estad:   0038234990063        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:    JUNIO@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021483  ANDREZA ANDRADE                           Rua Mica                            15    São Raimundo                     35043350 - GOVERNADOR VALADARES - MG
Fantasia:   ANDREZA SHOES                                  CNPJ/CPF:   37.203.578/0001-55      Rep: 22.751     Insc Estad:   37363660034           Telefone:    (33) 98874-0580          E-mail:
E-mail NF-e:     andrezashoes.gv@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020460  CALCADOS ITAPUA F43                       RUA PECANHA                       520   CENTRO                          35010160 - GOVERNADOR VALADARES - MG
Fantasia:   CALCADOS ITAPUA F43                             CNPJ/CPF:   27.177.096/0057-79      Rep: 19.275     Insc Estad:   2770415010383        Telefone:    (27) 2124-7700           E-mail:
E-mail NF-e:    F43@ITAPUA.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018032  CÁSSIA NUNES LEITE                        RUA ISRAEL PINHEIRO                 2481  SÃO PEDRO                       35020220 - GOVERNADOR VALADARES - MG
Fantasia:    PE ANTE PÉ                                       CNPJ/CPF:   42.820.704/0001-50      Rep: 22.751     Insc Estad:   2778042810000        Telefone:    (33)3271-1844            E-mail:
E-mail NF-e:    CNL.LOJA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

018388  CÁSSIA NUNES LEITE                        RUA ISRAEL PINHEIRO                 2481  SÃO PEDRO                       35020220 - GOVERNADOR VALADARES - MG
Fantasia:    PE ANTE PÉ                                       CNPJ/CPF:   42.820.704/0001-50      Rep: 22.751     Insc Estad:   277.804.281/0000      Telefone:   3332711844              E-mail:
E-mail NF-e:     cnl.loja@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022125  CEDRIC MOTA DE FREITAS                     AV WENCESLAU BRAZ                 1483  SANTA RITA                       35040570 - GOVERNADOR VALADARES - MG
Fantasia:   YANNE CALÇADOS                                 CNPJ/CPF:   36.547.714/0001-61      Rep: 22.751     Insc Estad:   004.931.010/0095      Telefone:    (33) 9915-8888           E-mail:
E-mail NF-e:     cedricf2012@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022292  DEUSMAR DE OLIVEIRA                       R DOUTOR PAULO DE SOUSA LIMA       850   CIDADE NOVA                     35063007 - GOVERNADOR VALADARES - MG
Fantasia:   DEUSMAR CALÇADOS                               CNPJ/CPF:   39.478.099/0001-77      Rep: 22.751     Insc Estad:   38717160049           Telefone:    (33)9994-67639           E-mail:
E-mail NF-e:     brasilforever2019@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008847   EL DOS SANTOS CALCADOS EIRELI - EPP          RUA SCO PAULO                      509   CENTRO                          35010180 - GOVERNADOR VALADARES - MG
Fantasia:    EL DOS SANTOS CALCADOS EIRELI                   CNPJ/CPF:   28.523.486/0001-61      Rep: 22.751     Insc Estad:   0030324320043        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     brenogontijo@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022168  ELISANGELA ALVES LOPES DE OLIVEIRA          R BARBARA HELIODORA               683   CENTRO                          35010040 - GOVERNADOR VALADARES - MG
Fantasia:    PE COM CHINELO                                  CNPJ/CPF:   26.386.207/0001-30      Rep: 22.751     Insc Estad:   28501200050           Telefone:    (33) 98885-7996          E-mail:
E-mail NF-e:     elisangelalopes4270@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 31

Pág. 31 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

009828  ERGUS MODAS EIRELI                       RUA MARECHAL FLORIANO             1390  CENTRO                          35010140 - GOVERNADOR VALADARES - MG
Fantasia:    VIA ÍMPAR MODAS                                 CNPJ/CPF:   05.444.493/0001-72      Rep: 22.751     Insc Estad:   2772147520049        Telefone:    (33)3275-6666            E-mail:
E-mail NF-e:    VIAIMPAR@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019069  F&A COM VAREJISTA DE CALC LTDA ME - FL 28     RUA SETE DE SETEMBRO               3500  CENTRO                          35010173 - GOVERNADOR VALADARES - MG
Fantasia:   BOROTO                                          CNPJ/CPF:   24.813.132/0001-09      Rep: 19.275     Insc Estad:   0027612530023        Telefone:    (33) 3272-4148           E-mail:
E-mail NF-e:     loja15@boroto.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010500  GERLAINE DA PENHA SILVA NUNES 21886856877   RUA VIRGILIO VIEIRA 26 LOJA CX B     SN   SÃO RAIMUNDO                    35041780 - GOVERNADOR VALADARES - MG
Fantasia:    GERLAINE DA PENHA SILVA NUNES                   CNPJ/CPF:   23.030.292/0001-00      Rep: 22.751     Insc Estad:   0026071310083        Telefone:    (33)84672-2195           E-mail:
E-mail NF-e:     gerlaine_ps@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018369  GISLENE CRISTINA XAVIER                      Rua Amelia Abibe                     509   Santa Rita                         35040040 - GOVERNADOR VALADARES - MG
Fantasia:    GISLENE SHOES                                   CNPJ/CPF:   17.643.715/0001-65      Rep: 22.751     Insc Estad:   21050700058           Telefone:    (33) 98820-9069          E-mail:
E-mail NF-e:     gislenecristina.2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022239   KISSILA STEFANE DE OLIVEIRA BARBOSA         R VALE FORMOSO                    220   JARDIM PEROLA                    35051282 - GOVERNADOR VALADARES - MG
Fantasia:   DC CALçADOS                                     CNPJ/CPF:   55.747.749/0001-99      Rep: 22.751     Insc Estad:   49310810009           Telefone:    (33) 99928-5965          E-mail:
E-mail NF-e:     barbosakissila9@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009769  LACERDA COMERCIO VAREJISTA DE CALCADOS LTDA RUA PECANHA                       510   CENTRO                          35010160 - GOVERNADOR VALADARES - MG
Fantasia:   LACERDA COMERCIO VAREJISTA DE                  CNPJ/CPF:   23.422.950/0001-00      Rep: 19.275     Insc Estad:   0026397500071        Telefone:    (33)3271-0127            E-mail:
E-mail NF-e:     loja18@boroto.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021102  LARISSA MERCIA MENDES GOMES                Av Amelia Habib                      275   Santa Rita                         35040040 - GOVERNADOR VALADARES - MG
Fantasia:    LARISSA MERCIA                                  CNPJ/CPF:   43.794.694/0001-99      Rep: 22.751     Insc Estad:   004.167.460/0011      Telefone:    (33) 99914-0728          E-mail:
E-mail NF-e:     lamercia@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/12/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022147  MENDES EMPREENDIMENTOS LTDA              RUA ESMERALDA                     1810  SÃO RAIMUNDO                    35044090 - GOVERNADOR VALADARES - MG
Fantasia:    ALMEIDA                                         CNPJ/CPF:   17.150.397/0001-09      Rep: 22.751     Insc Estad:   20569310075           Telefone:    (33) 98887-5653          E-mail:
E-mail NF-e:     juanderson07@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

013803  NEMES CONFECCOES E COMERCIO LTDA          RUA PAULO DESLANDE                347   VILA ISA                          35044190 - GOVERNADOR VALADARES - MG
Fantasia:   NEMES CONFECCOES E COMERCIO LT                CNPJ/CPF:   21.803.689/0001-62      Rep: 22.751     Insc Estad:   277.314.848/0092      Telefone:    (33)3278-8565            E-mail:
E-mail NF-e:    NEMESCONFECCOESGV@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019456  SPACO DOS PES LTDA                          Rua Arapoca                         26     Jardim ipe                         35043090 - GOVERNADOR VALADARES - MG
Fantasia:   SPACO DOS PES                                   CNPJ/CPF:   09.237.407/0001-01      Rep: 22.751     Insc Estad:   105.455.900/94        Telefone:    (33) 08801-4139          E-mail:
E-mail NF-e:     npe@spacopes.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017019   TEIXEIRA DISTRIBUIDORA LTDA                RUA MONTE SIAO                     315   VILA DOS MONTES                  35041570 - GOVERNADOR VALADARES - MG
Fantasia:    ELIVAM ENXOVAIS                                 CNPJ/CPF:   31.466.522/0001-07      Rep: 22.751     Insc Estad:   0032724070054        Telefone:    (33)88193-3661           E-mail:
E-mail NF-e:    RAFAELSANTIOL34@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018359  ZENE SAPATILHAS                             Rua Colombita                       197   São Raimundo                     35043200 - GOVERNADOR VALADARES - MG
Fantasia:   ZENE SAPATILHAS                                 CNPJ/CPF:   29.141.480/0001-92      Rep: 22.751     Insc Estad:   003.084.488/0035      Telefone:    (33) 98419-7244          E-mail:
E-mail NF-e:     zenileideedersilva@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003717  ARAUJO E MIRANDA CONFECCOES LTDA - ME      DR ODILON BEHRENS                 64    CENTRO                          39740000 - GUANHÃES - MG
Fantasia:   ARAUJO E MIRANDA CONFECCOES LT                 CNPJ/CPF:   22.715.841/0001-18      Rep: 22.751     Insc Estad:   2805463060037        Telefone:    (33)3421-3276            E-mail:
E-mail NF-e:     cinderela_modas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 32

Pág. 32 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019088  CONFECCOES ROTA DO CORPO LTDA                Avenida gov milton campos             2323  Centro                            39740000 - GUANHÃES - MG
Fantasia:   ROTA DO CORPO                                   CNPJ/CPF:   11.463.238/0001-70      Rep: 22.751     Insc Estad:   001.534.927/0087      Telefone:    (33) 98888-0596          E-mail:
E-mail NF-e:     rotadocorpoltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

012064  CRISTIANE FERNANDES DA CRUZ                TRAVESSA DR BRITO                  106   CENTRO                          39740000 - GUANHÃES - MG
Fantasia:    CRISTIANE CALCADOS                              CNPJ/CPF:   30.896.499/0001-28      Rep: 22.751     Insc Estad:   0032290040045        Telefone:    (33)88164-4001           E-mail:
E-mail NF-e:    IMPERIODOSCALCADOS2014@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     04/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003599  MIDIA CONFECCAO E CALCADOS LTDA - ME       DOUTOR BRITO                      84    CENTRO                          39740000 - GUANHÃES - MG
Fantasia:    MIDIA CONFECCAO E CALCADOS LTD                 CNPJ/CPF:   14.812.017/0001-58      Rep: 22.751     Insc Estad:   0018927430050        Telefone:    (33)3421-3393            E-mail:
E-mail NF-e:     midiacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019546   REI DOS CALCADOS LTDA                     RUA DR. ODILON BEHRENS             19    CENTRO                          39740000 - GUANHÃES - MG
Fantasia:    REIS DOS CALCADOS                               CNPJ/CPF:   20.725.032/0001-61      Rep: 22.751     Insc Estad:   2800403500028        Telefone:    (33) 3421-1781           E-mail:
E-mail NF-e:     reidoscalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017831  REQUINTE CALCADOS LTDA                   RUA DR ODILON BEHRENS             123   CENTRO                          39740000 - GUANHÃES - MG
Fantasia:    REQUINTE CALCADOS                              CNPJ/CPF:   97.527.409/0001-00      Rep: 22.751     Insc Estad:   0018026290054        Telefone:    (33)3421-3235            E-mail:
E-mail NF-e:    REQUINTECALCADOS2011@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     08/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020932  LOJA CASAGRANDE CALCADOS LTDA              Av Dona Floriana                     790   Centro                            37800000 - GUAXUPÉ - MG
Fantasia:    LOJA CASA GRANDE                                CNPJ/CPF:   51.842.550/0001-99      Rep: 21.564     Insc Estad:   0046924250084        Telefone:    (35) 99830-1033          E-mail:
E-mail NF-e:     angelabastoscasagrande@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022333   IPA CALÇADOS IAPU LTDA                     R FRANCISCO ALFEU DE OLIVEIRA       19    CENTRO                          35190000 - IAPU - MG
Fantasia:    IPA CALÇADOS IAPU                                CNPJ/CPF:   55.500.457/0001-57      Rep: 22.751     Insc Estad:   49153640004           Telefone:    (31) 3821-6619           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011772  CARVALHO CALCADOS LTDA                    AVENIDA CEL DURVAL DE BARROS       809   DURVAL DE BARROS                32400000 - IBIRITÉ - MG
Fantasia:   CARVALHO CALCADOS                              CNPJ/CPF:   12.940.989/0001-00      Rep: 22.500     Insc Estad:   0017011300066        Telefone:    (31)3272-7008            E-mail:
E-mail NF-e:    FABIANACALCADOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

000035   JAFABLI CALCADOS LTDA                       AVELINO PINHEIRO                   159   JACANA                           32400000 - IBIRITÉ - MG
Fantasia:    JAFABLI CALCADOS LTDA                           CNPJ/CPF:   02.032.034/0001-93      Rep: 22.500     Insc Estad:   2987072700062        Telefone:    (31)3533-4058            E-mail:
E-mail NF-e:     contja@ig.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021763  ODILON LEITE DA COSTA                       Av silva guimaraes                    49     Piratininga                        32423360 - IBIRITÉ - MG
Fantasia:    MIX MODAS                                       CNPJ/CPF:   10.893.078/0001-36      Rep: 22.500     Insc Estad:   0012222010055        Telefone:    (31) 98353-5107          E-mail:
E-mail NF-e:    mixmodas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017399  ANTONIO DULIO RAMOS ALMEIDA               AV CORONEL JOSE BERNARDES         406   CENTRO                          39318000 - ICARAÍ DE MINAS - MG
Fantasia:    DESFILE CALCADOS                                CNPJ/CPF:   25.245.382/0001-44      Rep: 22.036     Insc Estad:   001.055.851/0094      Telefone:   38999435918             E-mail:
E-mail NF-e:     cdesfile@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003804  COMERCIAL PAULA E FILHOS PAULA LTDA - ME      BERENICE MAGALHAES PINTO           317   CENTRO                          32900000 - IGARAPÉ - MG
Fantasia:   COMERCIAL PAULA E FILHOS PAULA                  CNPJ/CPF:   19.871.789/0001-84      Rep: 22.500     Insc Estad:   3014264360082        Telefone:    (31)3534-1303            E-mail:
E-mail NF-e:     comercial_paula@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021106  EZEQUIAS BARBOSA AVILA                      Rua Alexandre Nunes                  208   Centro                            32900000 - IGARAPÉ - MG
Fantasia:    GABRIEL CALCADOS E ACESSORIOS                  CNPJ/CPF:   46.649.721/0001-28      Rep: 22.500     Insc Estad:   0043576220062        Telefone:    (31) 98674-2046          E-mail:
E-mail NF-e:     avilacris1820@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 33

Pág. 33 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018797  IGARAPE PRESENTES LTDA ME                  AV PROFESSOR CLOVIS SALGADO       369   Centro                            32900000 - IGARAPÉ - MG
Fantasia:    ELIS CALCADOS                                   CNPJ/CPF:   07.790.799/0001-06      Rep: 22.500     Insc Estad:   0010075150093        Telefone:    (31) 3534-5412           E-mail:
E-mail NF-e:     eliscalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015708  CELEBRAR CALCADOS EIRELI                  RUA PRIMEIRO DE MARCO              515   CENTRO                          35695000 - IGARATINGA - MG
Fantasia:    CELEBRAR CALCADOS                              CNPJ/CPF:   22.995.335/0001-20      Rep: 21.564     Insc Estad:   0026040740035        Telefone:    (37)99069-9947           E-mail:
E-mail NF-e:    CELEBRARNOVASERRANA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021387  KACULINHA CALçADOS E ESPORTES LTDA          Rua Primeiro de Março                 2      Centro                            35695000 - IGARATINGA - MG
Fantasia:    KACULINHA                                       CNPJ/CPF:   07.605.670/0001-80      Rep: 21.564     Insc Estad:   3023862790098        Telefone:    (37) 3246-1145           E-mail:
E-mail NF-e:     kaculinhacalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     05/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020548  LARISSA KAREN TEIXEIRA ALMEIDA               Rua Floriano Peixoto                  16     Centro                            35695000 - IGARATINGA - MG
Fantasia:    VITORIA CALCADOS                                CNPJ/CPF:   43.950.912/0001-37      Rep: 21.564     Insc Estad:   46233410010           Telefone:    (37) 99914-6830          E-mail:
E-mail NF-e:     lala99146830@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017992  HENRIQUETA MARIA LEÃO CALIXTO              RUA                               838   CENTRO                          38910000 - IGUATAMA - MG
Fantasia:   PONTO DO CALÇADO                               CNPJ/CPF:   37.108.454/0001-90      Rep: 21.564     Insc Estad:   0037278040043        Telefone:    (37)3353-2435            E-mail:
E-mail NF-e:    LAINECALCADOS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     16/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020751  IDEK COMERCIO LTDA                       RUA CINCO                          650   CENTRO                          38910000 - IGUATAMA - MG
Fantasia:   VELHO OESTE                                     CNPJ/CPF:   00.409.945/0001-61      Rep: 21.564     Insc Estad:   303.917.044/0044      Telefone:    (37) 99152-7013          E-mail:
E-mail NF-e:     velhooestecal@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020812  AKEMI KUNITAKE                              Av Alvarenga Peixoto                  667   Centro                            37576000 - INCONFIDENTES - MG
Fantasia:    NINA STORE                                      CNPJ/CPF:   50.344.568/0001-06      Rep: 21.564     Insc Estad:   45961790088           Telefone:    (35) 99960-2637          E-mail:
E-mail NF-e:     ninastore.inbox@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022334  A C M MARTINS LOJAO NOVA BRASILIA LTDA       R OSVALDO SILVA ARAUJO             15    CENTRO                          35330000 - INHAPIM - MG
Fantasia:    LOJAO NOVA BRASILIA                             CNPJ/CPF:   49.607.323/0001-37      Rep: 22.751     Insc Estad:   45496780071           Telefone:    (33) 99858-9335          E-mail:
E-mail NF-e:     pedronovabrasilia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003723   J S GUERRA                               OSVALDO SILVA ARAUJO 253 LOJA      04    CENTRO                          35330000 - INHAPIM - MG
Fantasia:     J S GUERRA                                       CNPJ/CPF:   09.040.196/0001-12      Rep: 22.751     Insc Estad:   0010423490001        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     escritoriodarealce@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019447  FRANCISCO CHAGAS ARRUDAS VASCONCELOS       Av: Manoel Machado Franco            739   Centro                            35310000 - IPABA - MG
Fantasia:   BAZAR CENTRAL                                   CNPJ/CPF:   19.868.181/0001-09      Rep: 22.751     Insc Estad:   7370808960046        Telefone:    (31) 3320-1101           E-mail:
E-mail NF-e:     bazarsaopaulo2022@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022330   IPA CALÇADOS IPABA LTDA                    AV JOSE RODRIGUES DE ALMEIDA       616   CENTRO                          35198000 - IPABA - MG
Fantasia:    IPA CALÇADOS                                    CNPJ/CPF:   59.073.616/0001-35      Rep: 22.751     Insc Estad:   50970430094           Telefone:    (31) 3822-2637           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018566  MAGNUM CESARIO BATISTA CALCADOS            Av Jose Rodrigues de Almeida           742   Centro                            35198000 - IPABA - MG
Fantasia:    MARI CALCADOS                                   CNPJ/CPF:   30.876.013/0001-90      Rep: 22.751     Insc Estad:   32271180040           Telefone:    (31) 97159-7101          E-mail:
E-mail NF-e:     marianegarciarocha@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013964  NADIR FERREIRA DA CRUZ                     AV TRES                            42    DISTRITO VALE VERDE              35198500 - IPABA - MG
Fantasia:    NATTY CALCADOS                                  CNPJ/CPF:   23.832.265/0001-51      Rep: 22.751     Insc Estad:   0026745030063        Telefone:    (33)99870-0229           E-mail:
E-mail NF-e:    NADIR.F.O@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 34

Pág. 34 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019117  A D PEREIRA E CIA LTDA                        Rua Montevideu                      694   Centro                            35164085 - IPATINGA - MG
Fantasia:   MATEUS MODAS                                   CNPJ/CPF:   07.631.324/0001-77      Rep: 22.751     Insc Estad:   3133867210071        Telefone:    (31) 3826-7067           E-mail:
E-mail NF-e:     mateusdenunes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018408  ADRIANA REGO GONCALVES                     Av flores                            354   Bom jardim                        35162274 - IPATINGA - MG
Fantasia:   ADRIANA CALCADOS                               CNPJ/CPF:   19.488.660/0001-91      Rep: 22.751     Insc Estad:   22864180073           Telefone:    (31) 97106-3966          E-mail:
E-mail NF-e:     adrianaregogoncalves@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020617  ALENICE GONCALVES SILVA                     Rua Antonio Boaventura Batista         110    Vila Celeste                        35162484 - IPATINGA - MG
Fantasia:   QUATRO PONTO UM                                CNPJ/CPF:   47.051.492/0001-08      Rep: 22.751     Insc Estad:   0043968510046        Telefone:    (31) 98964-7774          E-mail:
E-mail NF-e:     tudoumpoucoalenice@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019234  BIANCA CAROLINA DE SOUZA SILVA              Rua serra Dourada                    40     Jardim Panorama                   35164235 - IPATINGA - MG
Fantasia:    BIANCA VARIEDADES                               CNPJ/CPF:   40.885.597/0001-13      Rep: 22.751     Insc Estad:   39751660076           Telefone:    (31) 98328-8507          E-mail:
E-mail NF-e:     lopesefigenia734@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006320  BOUTIQUE PIMENTA LTDA - ME                 AV VINTE E OITO DE ABRIL 109 A      SN   CENTRO                          35160004 - IPATINGA - MG
Fantasia:   BOUTIQUE PIMENTA LTDA - ME                      CNPJ/CPF:   11.178.003/0001-36      Rep: 22.751     Insc Estad:   0014241210015        Telefone:    (31)3826-3391            E-mail:
E-mail NF-e:     espacovippcentro@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008481  CARLOS EDUARDO TEIXEIRA LIMA               RUA ANTONIO BOAVENTURA BATISTA    91    VILA CELESTE                      35162484 - IPATINGA - MG
Fantasia:   CARLOS EDUARDO TEIXEIRA LIMA                   CNPJ/CPF:   07.878.060/0001-50      Rep: 22.751     Insc Estad:   0010043190090        Telefone:    (31) 99763-7213          E-mail:
E-mail NF-e:     teixeiralimadu@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007606  CASA DOS RETALHOS SOUZA E VIEIRA LTDA ME    AV FLORES                         751   BOM JARDIM                       35162263 - IPATINGA - MG
Fantasia:   CASA DOS RETALHOS SOUZA E VIEI                  CNPJ/CPF:   19.431.295/0001-89      Rep: 22.751     Insc Estad:   3132164610067        Telefone:    (31)3826-2282            E-mail:
E-mail NF-e:     c_retalho@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018552  CLEIDIANE PATRICIA DE PAIVA DUARTE           Rua Jordao                          34    Canaã                            35164179 - IPATINGA - MG
Fantasia:   MENINA MODAS                                   CNPJ/CPF:   14.143.645/0001-98      Rep: 22.751     Insc Estad:   18244760052           Telefone:    (31) 98718-4213          E-mail:
E-mail NF-e:     welsantolepo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022340  DENISE GONCALVES DE OLIVEIRA MACHADO       AV MINAS GERAIS                    247   CANAA                           35164192 - IPATINGA - MG
Fantasia:   MACHADO CALÇADOS                              CNPJ/CPF:   51.887.049/0001-49      Rep: 22.751     Insc Estad:   004.695.291/0018      Telefone:    (31) 98410-0234          E-mail:
E-mail NF-e:     machadocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

013909  ELAINE FELIPE DOS SANTOS OLIVEIRA            AV FLORES                          601   BOM JARDIM                       35162263 - IPATINGA - MG
Fantasia:    LAYNE SHOES                                     CNPJ/CPF:   42.569.851/0001-08      Rep: 22.751     Insc Estad:   0040857220039        Telefone:    (31)3826-8250            E-mail:
E-mail NF-e:    LAYNESHOES@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003063  ERBRUN CALCADOS E BOLSAS LTDA - ME LOJA 07   SELIM JOSÉ DE SALES                 797   CANAA                           35164504 - IPATINGA - MG
Fantasia:   ERBRUN CALCADOS E BOLSAS LTDA                  CNPJ/CPF:   11.355.964/0001-79      Rep: 22.751     Insc Estad:   0015057220080        Telefone:    (31) 3617-1888           E-mail:
E-mail NF-e:     courobolsasxml@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014791  FABIANE CRISTINA SILVA COSTA                AVENIDA FLORES                     382   BOM JARDIM                       35162263 - IPATINGA - MG
Fantasia:    LOJA FAB FAB                                     CNPJ/CPF:   38.006.874/0001-29      Rep: 22.751     Insc Estad:   0038035650084        Telefone:    (31)99792-2501           E-mail:
E-mail NF-e:    LOJAFABFAB@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000026  FRANCISCA VARIEDADES LTDA                  CAETES                            411   IGUACU                          35162038 - IPATINGA - MG
Fantasia:    FRANCISCA VARIEDADES LTDA                      CNPJ/CPF:   26.403.113/0001-21      Rep: 22.751     Insc Estad:   3136426580015        Telefone:    (31)3821-3298            E-mail:
E-mail NF-e:     franciscamacena@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 35

Pág. 35 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018183  GENESIO MOREIRA MACHADO                  AV MINAS GERAIS                    261   CANAÃ                           35164192 - IPATINGA - MG
Fantasia:   MACHADO CALCADOS                              CNPJ/CPF:   33.000.533/0001-22      Rep: 22.751     Insc Estad:   003.397.093/0030      Telefone:    (31)84100-0234           E-mail:
E-mail NF-e:    MACHADOCALCADOS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     05/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022332   IPA CALCADOS CANAA LTDA                   R JORDAO                          95    CANAA                           35164179 - IPATINGA - MG
Fantasia:    IPA CALCADOS CANAA                              CNPJ/CPF:   55.506.429/0001-47      Rep: 22.751     Insc Estad:   49158100024           Telefone:    (31) 3821-6619           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022331   IPA CALÇADOS IPATINGA LTDA                 AV VINTE E OITO DE ABRIL             07    CENTRO                          35160004 - IPATINGA - MG
Fantasia:    IPA CALÇADOS                                    CNPJ/CPF:   58.286.754/0001-30      Rep: 22.751     Insc Estad:   50524570043           Telefone:    (31) 3822-2637           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018053  IPATINGA COMERCIO DE CALCADOS EIRELLI       AV 28 DE ABRIL                      795   CENTRO                          35160004 - IPATINGA - MG
Fantasia:    FLAGS CALCADOS                                  CNPJ/CPF:   08.060.877/0002-60      Rep: 22.751     Insc Estad:   0010138020116        Telefone:    (31)88866-6331           E-mail:
E-mail NF-e:    FINANCEIROFLAGSREALCE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018411  IPATINGA COMERCIO DE CALCADOS EIRELLI       AV 28 DE ABRIL                      795   CENTRO                          35160004 - IPATINGA - MG
Fantasia:    FLAGS CALCADOS                                  CNPJ/CPF:   08.060.877/0002-60      Rep: 22.751     Insc Estad:   001.013.802/0116      Telefone:    (31)9888-66331           E-mail:
E-mail NF-e:     financeiroflagsrealce@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007607   J F CALCADOS LTDA ME                       AV VINTE E OITO DE ABRIL            705   CENTRO                          35160004 - IPATINGA - MG
Fantasia:     J F CALCADOS LTDA ME                             CNPJ/CPF:   41.850.652/0001-00      Rep: 22.751     Insc Estad:   3134532070058        Telefone:    (31)3822-3728            E-mail:
E-mail NF-e:     adrianaphbc@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008849   JCP CALCADOS EIRELI - EPP                    AV VINTE E OITO DE ABRIL            230   CENTRO                          35160004 - IPATINGA - MG
Fantasia:    JCP CALCADOS EIRELI - EPP                         CNPJ/CPF:   28.494.689/0001-77      Rep: 22.751     Insc Estad:   0030300690061        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020631  LAYNE SHOES CALCADOS LTDA                     Avenida Vinte e Oito de Abril            682   Centro                            35160004 - IPATINGA - MG
Fantasia:    LAYNE SHOES                                     CNPJ/CPF:   51.593.874/0001-30      Rep: 22.751     Insc Estad:   0046762110029        Telefone:    (31) 98544-7715          E-mail:
E-mail NF-e:     layneshoes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021126  LSHOES NET LTDA                             Av Alberto Giovannini                  106    Bethania                          35164538 - IPATINGA - MG
Fantasia:    LAYNE SHOES                                     CNPJ/CPF:   52.537.998/0001-61      Rep: 22.751     Insc Estad:   0047372750040        Telefone:    (31) 98544-7715          E-mail:
E-mail NF-e:     layneshoes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006424  MAGAZINE PIMENTA LTDA ME                  AV SELIM JOSÉ DE SALLES             768   CANAA                           35164213 - IPATINGA - MG
Fantasia:   MAGAZINE PIMENTA LTDA ME                       CNPJ/CPF:   10.694.653/0001-71      Rep: 22.751     Insc Estad:   0011145550053        Telefone:    (31)3822-4826            E-mail:
E-mail NF-e:     terraeagua@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022328  MARIA DOS ANJOS CALÇADO IPATINGA LTDA       AV VINTE E OITO DE ABRIL             546   CENTRO                          35160004 - IPATINGA - MG
Fantasia:   MARIA DOS ANJOS CALÇADO                        CNPJ/CPF:   59.109.197/0001-44      Rep: 22.751     Insc Estad:   50990520080           Telefone:    (31) 3822-2637           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022327  MARIA DOS ANJOS IPATINGA LTDA              AV VINTE E OITO DE ABRIL             460   CENTRO                          35160004 - IPATINGA - MG
Fantasia:   MARIA DOS ANJOS IPATINGA LTDA                   CNPJ/CPF:   59.219.414/0001-59      Rep: 22.751     Insc Estad:   51053740085           Telefone:    (31) 9922-0441           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010106  MARIA HELENA DA TRINDADE 69846391668        AV ESPERANCA 947 LOJA A           SN    ESPERANCA                       35162257 - IPATINGA - MG
Fantasia:   MARIA HELENA DA TRINDADE 69846                 CNPJ/CPF:   26.469.436/0001-18      Rep: 22.751     Insc Estad:   0028578690001        Telefone:    (31)89899-9996           E-mail:
E-mail NF-e:     lennaok@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 36

Pág. 36 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019121  MARTA MARIA CABRAL ME                       Av Esperanca                        351   Esperanca                         35152257 - IPATINGA - MG
Fantasia:   MARTA CABRAL                                    CNPJ/CPF:   26.054.452/0001-40      Rep: 22.751     Insc Estad:   313.174.717/0011      Telefone:    (31) 98810-5663          E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     23/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021083  MIB VALE DO ACO CALCADOS EIRELI F19          Av 28 de Abril                        240   Centro                            35160004 - IPATINGA - MG
Fantasia:    LOJAS MIB                                        CNPJ/CPF:   97.523.232/0001-66      Rep: 22.751     Insc Estad:   0018022420077        Telefone:    (31) 3822-6444           E-mail:
E-mail NF-e:     franquia19@lojasmib.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003131  PALLUM CALCADOS E BOLSAS LTDA - ME LOJA 13    VINTE E OITO DE ABRIL                65    CENTRO                          35160004 - IPATINGA - MG
Fantasia:    PALLUN CALCADOS E BOLSAS LTDA                  CNPJ/CPF:   18.669.859/0001-53      Rep: 22.751     Insc Estad:   0022026050007        Telefone:    (31) 3841-6798           E-mail:
E-mail NF-e:     courobolsasxml@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018092  PHABLO SILVA RAMOS                        AV ALBERTO GIOVANNINI              106   BETHANIA                         35164538 - IPATINGA - MG
Fantasia:    LAYNE SHOES                                     CNPJ/CPF:   46.493.340/0001-00      Rep: 22.751     Insc Estad:   004.347.790/0049      Telefone:    (31)85447-7715           E-mail:
E-mail NF-e:    LAYNESHOES@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004088  REGINA IZABEL DA SILVA GREGORIO            RUA CARLOS GOMES 124 - LJ A        SN    IDEAL                            35162165 - IPATINGA - MG
Fantasia:    REGINA IZABEL DA SILVA GREGORI                  CNPJ/CPF:   38.635.926/0001-26      Rep: 22.751     Insc Estad:   3136789640002        Telefone:    (31)3824-4486            E-mail:
E-mail NF-e:     fiosemalhas92@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003800  SHOPPING PIMENTA LTDA - ME                  JOÃO VALENTIM PASCOAL              704   CENTRO                          35160002 - IPATINGA - MG
Fantasia:   SHOPPING PIMENTA LTDA - ME                      CNPJ/CPF:   12.111.073/0001-30      Rep: 22.751     Insc Estad:   0016170790083        Telefone:    (31)3825-3901            E-mail:
E-mail NF-e:     espacovippcentro2@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005686  VESTE PE CALCADOS LTDA EPP LJ 56             AV PEDRO LINHARES GOMES           3900  CENTRO                          35160291 - IPATINGA - MG
Fantasia:    VESTE PE CALCADOS LTDA EPP LJ                    CNPJ/CPF:   23.605.053/0001-31      Rep: 22.751     Insc Estad:   0026551880096        Telefone:    (37)2101-4100            E-mail:
E-mail NF-e:    NFE@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019186  RENILDA MARIA DOS SANTOS VITORINO ME        Rua Dr.Omar Diniz                    307   Centro                            38350000 - IPIAÇU - MG
Fantasia:   MARANATHA SAPATARIA                            CNPJ/CPF:   01.602.621/0001-08      Rep: 21.496     Insc Estad:   3143289000079        Telefone:    (34) 3252-1219           E-mail:
E-mail NF-e:     carmovsilva@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006397   KALIF CALCADOS LTDA ME                     AV EMILIO ZACARIAS DA SILVA 28 - LJ  03    BELA VISTA                       35900091 - ITABIRA - MG
Fantasia:    KALIF CALCADOS LTDA ME                          CNPJ/CPF:   22.062.723/0001-58      Rep: 21.495     Insc Estad:   3175116050068        Telefone:    (31)3831-3253            E-mail:
E-mail NF-e:     ernanemadureira@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003833  SBX22 CALCADOS E BOLSAS LTDA ME            AV JOÃO PINHEIRO                   267   CENTRO                          35900538 - ITABIRA - MG
Fantasia:   SBX22 CALCADOS E BOLSAS LTDA M                 CNPJ/CPF:   25.023.614/0001-10      Rep: 21.495     Insc Estad:   0027795970028        Telefone:    (31)3831-3329            E-mail:
E-mail NF-e:    FINANCEIROSBX@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

022233  AILTON RIBEIRO GUIMARÃES                  R JANUARIA                         257   CENTRO                          39470000 - ITACARAMBI - MG
Fantasia:   CONFECÇÕES GUIMARÃES                          CNPJ/CPF:   05.402.526/0001-11      Rep: 22.941     Insc Estad:   3212164700072        Telefone:    (38) 99119-8208          E-mail:
E-mail NF-e:     silviocosta@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

017389  CIDA MODAS EIRELLI                        RUA BRASÍLIA                       386   CENTRO                          39470000 - ITACARAMBI - MG
Fantasia:    CIC MODAS                                       CNPJ/CPF:   10.229.126/0001-96      Rep: 22.941     Insc Estad:   001.082.643/0074      Telefone:    (38)9910-83645           E-mail:
E-mail NF-e:     maxcilanotts@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002854  LOJA DO FIO LTDA-ME                        PADRE GREGORIO                    135   CENTRO                          35514000 - ITAGUARA - MG
Fantasia:    LOJA DO FIO LTDA-ME                              CNPJ/CPF:   11.439.531/0001-00      Rep: 22.500     Insc Estad:   0015297160022        Telefone:    (31)9909-4773            E-mail:
E-mail NF-e:     lojadofio@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 37

Pág. 37 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003852  EDUARDO GOMES PEREIRA                    RUA CORONEL PEDRO MENDES          26    CENTRO                          39815000 - ITAIPÉ - MG
Fantasia:   EDUARDO GOMES PEREIRA                          CNPJ/CPF:   10.576.244/0001-70      Rep: 22.941     Insc Estad:   0011055740074        Telefone:    (33)3532-1302            E-mail:
E-mail NF-e:     dudualteticano01@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008906   JL CALCADOS EIRELI - EPP                     AV CORONEL CARNEIRO JUNIOR        89    CENTRO                          37500018 - ITAJUBÁ - MG
Fantasia:     JL CALCADOS EIRELI - EPP                          CNPJ/CPF:   28.025.763/0001-06      Rep: 21.564     Insc Estad:   0029909330024        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011400  KHALIL EMILE EL MOUALLEM E CIA LTDA           PCA DOUTOR WENCESLAU BRAZ         39    CENTRO                          37500000 - ITAJUBA - MG
Fantasia:    KHALIL EMILE EL MOUALLEM E CIA                   CNPJ/CPF:   68.510.742/0001-09      Rep: 21.564     Insc Estad:   3242623100053        Telefone:    (35)3622-0742            E-mail:
E-mail NF-e:     redshoesitj@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021610  ZORAIA MARIA RODRIGUES CARNEIRO           RUA SINHAZINHA LISBOA              28    Sao vicente                        37502096 - ITAJUBÁ - MG
Fantasia:    HILMA CALCADOS                                  CNPJ/CPF:   01.246.483/0001-71      Rep: 21.564     Insc Estad:   3241967550024        Telefone:    (35) 99242-0704          E-mail:
E-mail NF-e:     soraiaaley@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010075  ANTONIO FRANCISCO DA MOTA                RUA CORONEL GENTIL FERNANDES      52    CENTRO                          39670000 - ITAMARANDIBA - MG
Fantasia:   IMPACTO CALCADOS                               CNPJ/CPF:   22.169.222/0001-75      Rep: 21.564     Insc Estad:   0025353460090        Telefone:    (37)99490-0008           E-mail:
E-mail NF-e:    IMPACTOITA1@GMAIL.COM

     Obs.:                                                           Proprietário :

Condição de Pagamento:     1 A VISTA
Data Última Compra:     03/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003317  CLALDIANA SILVA EVANGELISTA - ME             DIAMANTINA                        190   CENTRO                          39670000 - ITAMARANDIBA - MG
Fantasia:    CLALDIANA SILVA EVANGELISTA -                    CNPJ/CPF:   19.874.021/0001-64      Rep: 22.751     Insc Estad:   0023241480046        Telefone:    (38)3521-2530            E-mail:
E-mail NF-e:     ellos01@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003379  CLAYTHON FERNANDES COSTA - ME              PADRE JOÃO AFONSO                 33    CENTR0                          39670000 - ITAMARANDIBA - MG
Fantasia:   CLAYTHON FERNANDES COSTA - ME                  CNPJ/CPF:   66.453.978/0001-17      Rep: 22.751     Insc Estad:   3258282940079        Telefone:    (38)3521-1346            E-mail:
E-mail NF-e:     claythoncalcados@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019378  ELETROLOJA GOMES LTDA                    RUA CONTORNO                      49    FLORESTAL                        39670000 - ITAMARANDIBA - MG
Fantasia:    DEPOSITO FECHADO                               CNPJ/CPF:   00.731.785/0002-53      Rep: 22.751     Insc Estad:   325.941.897/0170      Telefone:    (38) 9 9-9884232         E-mail:
E-mail NF-e:     espacogomesfashion@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014083  ELMAR LOPES DE OLIVEIRA                    PRACA DOS AGRICULTORES            134   CENTRO                          39670000 - ITAMARANDIBA - MG
Fantasia:   BARATAO CALCADOS                               CNPJ/CPF:   21.431.341/0001-91      Rep: 22.751     Insc Estad:   3254786600022        Telefone:    (38)3521-1262            E-mail:
E-mail NF-e:    OBARATAO81@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     16/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019382  TEREZINHA FERNADES MEIRA                   Rua Diamantina                      11     Centro                            39670000 - ITAMARANDIBA - MG
Fantasia:    LOJA MORIAH                                     CNPJ/CPF:   35.926.850/0001-08      Rep: 22.751     Insc Estad:   003.636.552/0093      Telefone:    (38) 99164-6714          E-mail:
E-mail NF-e:     terezinhameira7@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021460  JOSE CLOVES PINHEIRO EPP                        Praca dos fundadores                  73     Centro                            39830000 - ITAMBACURI - MG
Fantasia:    STILUS CALCADOS                                 CNPJ/CPF:   06.005.061/0001-28      Rep: 22.751     Insc Estad:   327.262.920/0084      Telefone:    (33) 99976-8182          E-mail:
E-mail NF-e:     aline.2008ca@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004765  VILMA FRANCISCA SANTOS                    RUA BELO HORIZONTE                342   CENTRO                          39625000 - ITAOBIM - MG
Fantasia:   CALCADOS MENDONCA DE ITAOBIM L                CNPJ/CPF:   07.603.297/0001-29      Rep: 22.941     Insc Estad:   3334212990071        Telefone:    (33)3734-1282            E-mail:
E-mail NF-e:     calcadosmendonca@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020282   33.634.629 SIRLENE DE OLIVEIRA SILVA            Avenida Ribeiro Pena                  104   Centro                            35550000 - ITAPECERICA - MG
Fantasia:   KRONUSS COMERCIO DE CALCADOS E                CNPJ/CPF:   33.634.629/0001-42      Rep: 21.564     Insc Estad:   34462770030           Telefone:    (37) 99809-9042          E-mail:
E-mail NF-e:     kromusscalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 38

Pág. 38 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016973  TANIA EUNICE FERREIRA CARVALHO             RUA VIGÁRIO ANTUNES                56    CENTRO                          35550000 - ITAPECERICA - MG
Fantasia:   DSON CALÇADOS                                  CNPJ/CPF:   39.829.579/0001-35      Rep: 21.564     Insc Estad:   0038992550014        Telefone:    (37)99343-3514           E-mail:
E-mail NF-e:    VANESSACARVALHO.HA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     08/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022078  DERRARA CALÇADOS E ACESSÓRIOS LTDA         Rua expedicionários                   577   Santa Terezinha                    35685000 - ITATIAIUÇU - MG
Fantasia:   DERRARA                                         CNPJ/CPF:   54.677.456/0001-10      Rep: 22.500     Insc Estad:   0048660400054        Telefone:    (31) 97104-3711          E-mail:
E-mail NF-e:     dcshoesloja@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018675  TELES MODAS LTDA                          AV JOSE FRANCISCO DA SILVA          143   Centro                            35685000 - ITATIAIUÇU - MG
Fantasia:   BRUNA FONSECA MODAS                           CNPJ/CPF:   04.519.702/0001-37      Rep: 22.500     Insc Estad:   3371320580030        Telefone:    (31) 3572-1654           E-mail:
E-mail NF-e:     loja.brunafonseca@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006448  WILTON CAMPOS NOGUEIRA EIRELLI             RUA PRIMEIRO DE MAIO               25    CENTRO                          35685000 - ITATIAIUÇU - MG
Fantasia:   WILTON CAMPOS                                  CNPJ/CPF:   21.258.843/0001-62      Rep: 22.500     Insc Estad:   3371040050081        Telefone:    (31)3572-1149            E-mail:
E-mail NF-e:    NOGUEIRAIRMAO@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005386  AMAURY DE FARIA                          RUA DOUTOR JOSÉ BALBINO            518   CENTRO                          37975000 - ITAÚ DE MINAS - MG
Fantasia:   AMAURY DE FARIA                                 CNPJ/CPF:   17.344.268/0001-43      Rep: 21.564     Insc Estad:   7233795040008        Telefone:    (35)3536-1939            E-mail:
E-mail NF-e:     lojafaria@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008204  STILLER-CALCADOS E ARTIGOS ESPORTIVOS LTDA - RUA JOSÉ BALBINO                   318   CENTRO                          37975000 - ITAÚ DE MINAS - MG
Fantasia:    STILLER-CALCADOS E ARTIGOS ESP                  CNPJ/CPF:   01.814.452/0001-70      Rep: 21.564     Insc Estad:   7236749610045        Telefone:    (35)3536-1805            E-mail:
E-mail NF-e:     patricktribos@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010723  CONFECCOES REINA LTDA                    RUA MELO VIANA 54 LETRA A         SN   CENTRO                          35680048 - ITAÚNA - MG
Fantasia:   CONFECCOES REINA LTDA                          CNPJ/CPF:   22.679.724/0001-46      Rep: 21.564     Insc Estad:   3385333770014        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     reizon_michel@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003847  DELLAS CALCADOS LTDA                     RUA ANTONIO DE MATOS              105   CENTRO                          35680030 - ITAÚNA - MG
Fantasia:    DELLAS CALCADOS LTDA                           CNPJ/CPF:   21.873.898/0001-82      Rep: 21.564     Insc Estad:   3384835000087        Telefone:    (37)3241-4202            E-mail:
E-mail NF-e:     dellascalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017253  FARIA E PARREIRAS CALCADOS LTDA            RUA DR JOSÉ GONÇALVES              184   CENTRO                          35680032 - ITAÚNA - MG
Fantasia:    FARIA E PARREIRAS                                CNPJ/CPF:   03.590.705/0001-02      Rep: 21.564     Insc Estad:   3380597500033        Telefone:    (37)99112-4932           E-mail:
E-mail NF-e:    PARPASSO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016249  MARIA ELIETE DIAS BRITO                     PCA PREFEITO PRECILIO GUSMAO       90    CENTRO                          39610000 - ITINGA - MG
Fantasia:   BAZAR AYSSA E JOSA                              CNPJ/CPF:   04.463.340/0001-00      Rep: 22.941     Insc Estad:   3401547190080        Telefone:    (33)3423-3622            E-mail:
E-mail NF-e:    JOSAPHATVERGUSF@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007638  COMERCIAL ASP LTDA                       RUA ABDALA MUSSA                  609   JD DO ROSARIO                    38304042 - ITUIUTABA - MG
Fantasia:   COMERCIAL ASP LTDA                              CNPJ/CPF:   86.436.839/0001-92      Rep: 21.496     Insc Estad:   3428797810007        Telefone:    (34)9920-89410           E-mail:
E-mail NF-e:     sirleiagmar@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005699  DEIVID NOVAIS FONTES - ME                  RUA VINTE E DOIS                    982   CENTRO                          38300076 - ITUIUTABA - MG
Fantasia:    DEIVID NOVAIS FONTES - ME                        CNPJ/CPF:   04.582.690/0001-95      Rep: 21.496     Insc Estad:   3421420910056        Telefone:    (34)3268-2085            E-mail:
E-mail NF-e:     feiraoitb@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019718  RASPHINE LTDA                              Rua vinte                           1086  Centro                            38300074 - ITUIUTABA - MG
Fantasia:    RASPHINE CALCADOS                              CNPJ/CPF:   19.607.662/0001-52      Rep: 21.496     Insc Estad:   3424464390093        Telefone:    (34) 3268-2395           E-mail:
E-mail NF-e:     rasphine@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 39

Pág. 39 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003340   IVAL COMERCIO LTDA - ME                     BENEDITO QUINTINO                  315   CENTRO                          35830000 - JABOTICATUBAS - MG
Fantasia:    IVAL COMERCIO LTDA - ME                          CNPJ/CPF:   21.815.014/0001-33      Rep: 22.500     Insc Estad:   3462636300095        Telefone:    (31)3683-1093            E-mail:
E-mail NF-e:     ivalcomercio@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017850  MARA S COSTA DIAS                        RUA BENEDITO QUINTINO              373   CENTRO                          35830000 - JABOTICATUBAS - MG
Fantasia:   MARA                                            CNPJ/CPF:   71.440.952/0001-74      Rep: 22.500     Insc Estad:   3468678140091        Telefone:    (31)3398-2018            E-mail:
E-mail NF-e:     lojadamara@yahoo.com.bt

     Obs.:                                                           Proprietário :

Data Última Compra:     13/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

015095  VAGNO JUNIO NOGUEIRA DA SILVA              AV CEL MOACIR JOSE DA SILVA         273   CENTRO                          39508000 - JAÍBA - MG
Fantasia:    PORTAL DOS CALCADOS                            CNPJ/CPF:   38.263.969/0001-28      Rep: 22.941     Insc Estad:   0038246160044        Telefone:    (38)99271-8153           E-mail:
E-mail NF-e:    PORTALDOSCALCADOSJAIBA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016344  ANATOLIO FERREIRA LIMA                     AV DO COMERCIO                    156   CENTRO                          39440001 - JANAÚBA - MG
Fantasia:    LOJAO DO POVO                                   CNPJ/CPF:   22.077.416/0001-40      Rep: 22.941     Insc Estad:   3514535440045        Telefone:    (38)3821-4721            E-mail:
E-mail NF-e:    GRAFITEXJANAUBA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

001272  CAMINOR CALCADOS MINAS NORTE LTDA - MTZ    DO COMERCIO                       291   CENTRO                          39440000 - JANAÚBA - MG
Fantasia:   CAMINOR CALCADOS MINAS NORTE L                CNPJ/CPF:   09.149.401/0001-82      Rep: 22.941     Insc Estad:   0010483400033        Telefone:    (38)3821-3324            E-mail:
E-mail NF-e:     rafael.jba@gammix.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006930  CONFECCOES PEREIRA DE JANAUBA LTDA - ME     AV DO COMERCIO                    146   CENTRO                          39440000 - JANAÚBA - MG
Fantasia:   KORPUS MODAS                                   CNPJ/CPF:   02.046.337/0001-65      Rep: 22.941     Insc Estad:   3517093250001        Telefone:    (38)3821-1850            E-mail:
E-mail NF-e:    GILMARECC.GS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021733  JUPH COMERCIO DE CALCADOS                 AV COMERCIO                       505   CENTRO                          39440001 - JANAÚBA - MG
Fantasia:    PASSARELA                                       CNPJ/CPF:   24.009.987/0002-54      Rep: 22.941     Insc Estad:   3515815670181        Telefone:    (38) 3821-2622           E-mail:
E-mail NF-e:    gammanfe@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021411  LAECIO QUINTINO PARAGUASSU                 Rua Padre Henrique                   59     Centro                            39480000 - JANUÁRIA - MG
Fantasia:   PONTA PE CALCADOS                               CNPJ/CPF:   04.641.290/0002-94      Rep: 22.941     Insc Estad:   3521416100183        Telefone:    (38) 3621-2943           E-mail:
E-mail NF-e:     laercioqp@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016570  LAERCIO QUINTINO PARAGUAÇU                RUA PADRE HENRIQUE                69    CENTRO                          39480000 - JANUÁRIA - MG
Fantasia:   BRUNA CALCADOS                                 CNPJ/CPF:   04.641.290/0001-03      Rep: 22.941     Insc Estad:   3521416100000        Telefone:    (38)3621-1088            E-mail:
E-mail NF-e:    LAERCIOQP@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     15/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003224  PASSO FIRME CALCADOS LTDA - ME               ITAPIRACABA                        36    CENTRO                          39480000 - JANUÁRIA - MG
Fantasia:   PASSO FIRME CALCADOS LTDA - ME                  CNPJ/CPF:   14.909.730/0001-14      Rep: 22.941     Insc Estad:   0019019570005        Telefone:    (38)3621-2310            E-mail:
E-mail NF-e:     passofirmecalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007339  ROSANGELA FERREIRA CARNEIRO               RUA RAU SOARES                    36    CENRO                           39480000 - JANUÁRIA - MG
Fantasia:   ROSANGELA FERREIRA CARNEIRO                    CNPJ/CPF:   24.299.557/0001-33      Rep: 22.941     Insc Estad:   0027150400000        Telefone:    (38)99973-4958           E-mail:
E-mail NF-e:     rosangelaferreira33@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008323  SUPERENE MAGAZINE LTDA                    AV CONEGO RAMIRO LEITE             184   CENTRO                          39480000 - JANUÁRIA - MG
Fantasia:   SUPERENE MAGAZINE                              CNPJ/CPF:   00.771.376/0001-08      Rep: 22.941     Insc Estad:   3520093700027        Telefone:    (38)3621-3698            E-mail:
E-mail NF-e:     noeantunes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018125  SHOW TENIS LTDA                           PÇA TENENTE MOL                    20    CENTRO                          35390000 - JEQUERI - MG
Fantasia:   SHOW TÊNIS                                      CNPJ/CPF:   19.109.472/0001-05      Rep: 22.619     Insc Estad:   0022472970030        Telefone:    (31) 99207-6656          E-mail:
E-mail NF-e:     showtenis@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 40

Pág. 40 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017968  ANDRESSA ARAUJO DOS SANTOS               RUA INÁCIO MURTA                   72    CENTRO                          39960000 - JEQUITINHONHA - MG
Fantasia:    FLOR MINEIRA MODAS                              CNPJ/CPF:   24.745.647/0001-00      Rep: 22.941     Insc Estad:   0027556870090        Telefone:    (33)3741-1026            E-mail:
E-mail NF-e:    ELISMAIX@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015232  EDRIENE OLIVEIRA FERNANDES                RUA INACIO MURTA                   48    CENTRO                          39960000 - JEQUITINHONHA - MG
Fantasia:    EDRIENE OLIVEIRA FERNANDES                      CNPJ/CPF:   13.137.193/0001-79      Rep: 22.941     Insc Estad:   0017216990064        Telefone:    (33)99186-6365           E-mail:
E-mail NF-e:    EDRIENEOLIVEIRAFERNANDES@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     28/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

003402  JOSE ALCIMAR RODRIGUES SOUTO - ME           PREFEITO IZIDORO MURTA             52    CENTRO                          39960000 - JEQUITINHONHA - MG
Fantasia:    JOSE ALCIMAR RODRIGUES SOUTO -                 CNPJ/CPF:   18.383.018/0001-85      Rep: 22.941     Insc Estad:   3582190670040        Telefone:    (33)3741-1567            E-mail:
E-mail NF-e:     jarsouto@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003569  KASUAL LOJA DE DEPARTAMENTO LTDA - EPP       AVEMIDA GETULIO VARGAS            4803  CARNEIRINHOS                    35930003 - JOÃO MONLEVADE - MG
Fantasia:   KASUAL LOJA DE DEPARTAMENTO LT                 CNPJ/CPF:   00.227.667/0001-21      Rep: 21.495     Insc Estad:   3629017240076        Telefone:    (31)3851-4726            E-mail:
E-mail NF-e:     kasualcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020564  LNS COMERCIAL DE CALCADOS LTDA              Av Getulio Vargas                     4885  Carneirinhos                       35930002 - JOÃO MONLEVADE - MG
Fantasia:    RABELLO CALCADOS                               CNPJ/CPF:   45.321.997/0001-10      Rep: 21.495     Insc Estad:   0042720270008        Telefone:    (31) 3851-0029           E-mail:
E-mail NF-e:     rabello-joaomonlevade@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016909  KAREN MARTINS SANTOS                     RUA CAPITAO SPERDIAO               642   CENTRO                          38770000 - JOÃO PINHEIRO - MG
Fantasia:   KAREN MARTINS SANTOS                           CNPJ/CPF:   42.699.341/0001-47      Rep: 22.941     Insc Estad:   0040937810096        Telefone:    (38)99486-6407           E-mail:
E-mail NF-e:    PIZANESTOREJP@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005706  WALQUIRIA GONZAGA                       RUA CAPITAO SPERIDIAO              548   CENTRO                          38770000 - JOÃO PINHEIRO - MG
Fantasia:    WALQUIRIA GONZAGA                              CNPJ/CPF:   03.122.235/0001-44      Rep: 21.495     Insc Estad:   3630203610033        Telefone:    (38)3561-1449            E-mail:
E-mail NF-e:     andreiacalcadosjp@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

001268  BOM D CALCADOS LTDA                      TANUS SALIBA                       222   CENTRO                          35675000 - JUATUBA - MG
Fantasia:   BOM D CALCADOS LTDA                            CNPJ/CPF:   06.240.647/0001-77      Rep: 22.500     Insc Estad:   7402878790069        Telefone:    (31)3535-9081            E-mail:
E-mail NF-e:     lojasbomdemais@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020253  LAZARA FONSECA DE MORAIS                      Avenida Tanus Saliba                  190   Centro                            35675000 - JUATUBA - MG
Fantasia:    CIA DA MODA                                     CNPJ/CPF:   47.484.846/0001-08      Rep: 22.500     Insc Estad:   0044116260010        Telefone:    (31) 99234-9677          E-mail:
E-mail NF-e:     lazara42fonseca@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018373  PAULO CESAR DE MORAIS                         Avenida Tanus Saliba                  190   Centro                            35675000 - JUATUBA - MG
Fantasia:    CIA DA MODA                                     CNPJ/CPF:   08.896.619/0001-38      Rep: 22.500     Insc Estad:   104.047.600/31        Telefone:    (31) 3535-5056           E-mail:
E-mail NF-e:     lucasjrmoraes97@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009725  ALCIDES CRISTOVAO FERNANDES 55321470600    RUA IBITIGUAIA 509 LOJA             101   SANTA LUZIA                      36030000 - JUIZ DE FORA - MG
Fantasia:    ALCIDES CRISTOVAO FERNANDES 55                 CNPJ/CPF:   12.447.109/0001-50      Rep: 22.619     Insc Estad:   0016528450080        Telefone:    (32)3232-1007            E-mail:
E-mail NF-e:     michele_cristovao@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022187  ANGELA SA STORE LTDA                      AV PRESIDENTE COSTA E SILVA         1623  SAO PEDRO                       36037000 - JUIZ DE FORA - MG
Fantasia:   ANGELA STORE                                    CNPJ/CPF:   58.597.929/0001-20      Rep: 22.619     Insc Estad:   50692940022           Telefone:    (32) 98867-3032          E-mail:
E-mail NF-e:     angelacristinadesa@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022090  BETHSHOES JF LTDA                        RUA SAO SEBASTIAO                  516   CENTRO                          36013970 - JUIZ DE FORA - MG
Fantasia:   BETH SHOES                                      CNPJ/CPF:   22.173.037/0001-54      Rep: 22.619     Insc Estad:   0025356510020        Telefone:    (32) 99969-6350          E-mail:
E-mail NF-e:     bthalmeida@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     09/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 41

Pág. 41 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019908  CLAUDIA APARECIDA MORGATTO                   Avenida Brasil                       6345  Mariano Procopio                   36080060 - JUIZ DE FORA - MG
Fantasia:    TILEY CALCADOS                                  CNPJ/CPF:   11.434.992/0002-62      Rep: 22.619     Insc Estad:   0015284590180        Telefone:    (32) 3321-4243           E-mail:
E-mail NF-e:     nfe@tileycalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016108   FELIPE EVELING COSTA                      RUA JOSÉ DE SOUZA CHAGAS           56    BONSUCESSO                      36061340 - JUIZ DE FORA - MG
Fantasia:    FELIPE EVELING                                   CNPJ/CPF:   33.033.504/0001-67      Rep: 22.619     Insc Estad:   0033996680007        Telefone:    (32)3215-0579            E-mail:
E-mail NF-e:    JESSICANATALIASOLAREIS@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022095  GERALDO MAGELA CAMPOS                     AVENIDA DOUTOR SIMEAO DE FARIA     1856  SANTA CRUZ                      36088000 - JUIZ DE FORA - MG
Fantasia:   GE CALCADOS                                     CNPJ/CPF:   05.024.535/0001-16      Rep: 22.619     Insc Estad:   3671746840081        Telefone:    (32) 3221-9137           E-mail:
E-mail NF-e:     geraldomagelacampos@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008508  JOSEMAR COMERCIAL LTDA - ME                RUA FRANCISCO FONTAINHA           626   SANTO ANTONIO                   36071510 - JUIZ DE FORA - MG
Fantasia:   JOSEMAR COMERCIAL LTDA - ME                     CNPJ/CPF:   64.341.746/0001-41      Rep: 22.619     Insc Estad:   3676985460063        Telefone:    (32)3211-5477            E-mail:
E-mail NF-e:     josemarltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019052  JOYCEARA DE OLIVEIRA CHAGAS                 GALERIA BELLINI                     401   CENTRO                          36013030 - JUIZ DE FORA - MG
Fantasia:   TOP CALCADOS                                    CNPJ/CPF:   27.723.649/0001-97      Rep: 22.619     Insc Estad:   004.333.985/0062      Telefone:    (37) 99922-1470          E-mail:
E-mail NF-e:     joytheooliveira@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021711  JOZILENE TAVARES DE ARAUJO BEZERRA LTDA      Rua halfeld                          354   Centro                            36010000 - JUIZ DE FORA - MG
Fantasia:    VITORIA CALCADOS                                CNPJ/CPF:   05.286.138/0001-12      Rep: 22.619     Insc Estad:   3671936640075        Telefone:    (32) 3216-1495           E-mail:
E-mail NF-e:     calcadosvitoria@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

017279  PURA AUDÁCIA LTDA                        RUA BRAZ BERNARDINO               133   CENTRO                          36010320 - JUIZ DE FORA - MG
Fantasia:   PURA AUDÁCIA                                    CNPJ/CPF:   16.809.619/0001-81      Rep: 22.619     Insc Estad:   0020241020042        Telefone:    (32)91308-8757           E-mail:
E-mail NF-e:    PURAUDACIAJF@HOTMAIL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     10/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008857  SHOPCAL COMERCIO DE CALCADOS LTDA - ME     RUA JARBAS DE LERY SANTOS          1675  CENTRO                          36013150 - JUIZ DE FORA - MG
Fantasia:   SHOPCAL COMERCIO DE CALCADOS L                CNPJ/CPF:   06.315.455/0001-82      Rep: 22.619     Insc Estad:   3672912570019        Telefone:    (32)3212-3331            E-mail:
E-mail NF-e:    MGVASCONCELLOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021168  TOP CALCADOS JF LTDA                        Rua Batista de Oliveira                 401   Centro                            36013300 - JUIZ DE FORA - MG
Fantasia:   TOP CALCADOS                                    CNPJ/CPF:   50.418.832/0001-09      Rep: 22.619     Insc Estad:   0046008520041        Telefone:    (37) 99922-1470          E-mail:
E-mail NF-e:     chrisprocopiodsilva@iclou.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016560  VALENTINE CALÇADOS EIRELI - ME              RUA BRAZ BERNARDINO               164   CENTRO                          36010320 - JUIZ DE FORA - MG
Fantasia:    VALENTINE CALÇADOS                             CNPJ/CPF:   24.753.106/0001-24      Rep: 22.619     Insc Estad:   0027562270031        Telefone:    (37)99803-2728           E-mail:
E-mail NF-e:    CONTATO@VALENTINECALCADOS.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     15/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005200  ANA MEIRE DE JESUS                          JUCA LIMIRIO                        242   CENTRO                          38720000 - LAGOA FORMOSA - MG
Fantasia:   ANA MEIRE DE JESUS                               CNPJ/CPF:   20.002.176/0001-90      Rep: 21.496     Insc Estad:   3754127850050        Telefone:    (34)3824-2174            E-mail:
E-mail NF-e:     anameiremodas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015320  EDUARDO BRAS DE LIMA ME                   RUA JUCA LIMIRIO                    281   CENTRO                          38720000 - LAGOA FORMOSA - MG
Fantasia:   EDUARDO BRAS DE LIMA ME                        CNPJ/CPF:   65.105.918/0001-40      Rep: 21.496     Insc Estad:   3757490730006        Telefone:    (34)3824-0426            E-mail:
E-mail NF-e:    STILLUS2012@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     12/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005207  LEOPOLDO GENESIO DE LIMA                  CLARIMUNDO FONSECA                101   CENTRO                          38720000 - LAGOA FORMOSA - MG
Fantasia:   LEOPOLDO GENESIO DE LIMA                       CNPJ/CPF:   18.467.316/0001-53      Rep: 21.496     Insc Estad:   3751830370080        Telefone:    (34)3824-2211            E-mail:
E-mail NF-e:     leopoldogenesiolima@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 42

Pág. 42 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016433  ARNOBIO RESENDE COMERCIO DE CALCADOS      AV ACADÊMICO NILO FIGUEIREDO       216   VILA PINTO COELHO                33450000 - LAGOA SANTA - MG
Fantasia:   CONTAINER CALCADOS                             CNPJ/CPF:   34.073.781/0002-47      Rep: 22.500     Insc Estad:   0035995600150        Telefone:    (31)98329-7890           E-mail:
E-mail NF-e:    CONTAINERADM@YAHOO.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019366  ARNOBIO RESENDE                          AV ACADEMICO NILO FIGUEIREDO       236   BRANT                           33230292 - LAGOA SANTA - MG
Fantasia:   CONTAINER CALCADOS                             CNPJ/CPF:   34.073.781/0001-66      Rep: 22.500     Insc Estad:   003.599.560/0079      Telefone:    (31) 99723-6373          E-mail:
E-mail NF-e:     containercalcadosoutlet@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016217  CASA SANTA MARTA LTDA                    RUA MILTON CAMPOS                 359   CENTRO                          33230070 - LAGOA SANTA - MG
Fantasia:   SANTA MARTA                                     CNPJ/CPF:   20.245.684/0001-07      Rep: 22.500     Insc Estad:   3760698560093        Telefone:    (31)3681-1597            E-mail:
E-mail NF-e:    CASASANTAMARTA3@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019171  SERRA CALCADOS LTDA                            Pc Doutor lund                       97     Centro                            33230076 - LAGOA SANTA - MG
Fantasia:   SERRA CALCADOS                                 CNPJ/CPF:   49.707.899/0001-76      Rep: 22.500     Insc Estad:   004.555.662/0024      Telefone:    (31) 98329-7890          E-mail:
E-mail NF-e:     matrizserra74@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013901  DIANA DE BARROS SILVA MORBECK             RUA DR GARCAO STOCKLER            255   CENTRO                          37480000 - LAMBARI - MG
Fantasia:   SANTOS CALÇADOS                                CNPJ/CPF:   19.433.839/0001-41      Rep: 21.564     Insc Estad:   0022804010090        Telefone:    (35)3331-1162            E-mail:
E-mail NF-e:    SANTOSCALCADOS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016878  MARIA APARECIDA DO CARMO PEREIRA           RUA NAPOLEÃO REIS                  8     CENTRO                          36455000 - LAMIM - MG
Fantasia:    CIRCUITO DA MODA                                CNPJ/CPF:   04.110.033/0001-45      Rep: 13.734     Insc Estad:   3791024040045        Telefone:    (31)3754-1379            E-mail:
E-mail NF-e:    CIRCUITODAMODALAMIM@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004087  EDMEA MAGALHAES LAMEIRAS ALVES            RUA SANTANA  169 - LOJA             1     CENTRO                          37200000 - LAVRAS - MG
Fantasia:   EDMEA MAGALHAES LAMEIRAS ALVES                CNPJ/CPF:   19.029.539/0001-00      Rep: 21.564     Insc Estad:   0022394300000        Telefone:    (35)3821-8206            E-mail:
E-mail NF-e:     ronaldoalves1952@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009569  HENRIQUE SILVA MURAD LTDA                 AV COMANDANTE SOARES JUNIOR      410   DR.JOAO RIBEIRO                  37205066 - LAVRAS - MG
Fantasia:   HENRIQUE SILVA MURAD - ME                       CNPJ/CPF:   08.227.263/0001-40      Rep: 13.734     Insc Estad:   0010152450033        Telefone:    (35) 3821-6249           E-mail:
E-mail NF-e:     clara.murad@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011377  PREMIUN CALCADOS EIRELI                    PRACA DOUTOR AUGUSTO SILVA 66 LJ   02    CENTRO                          37200000 - LAVRAS - MG
Fantasia:   PREMIUN CALCADOS EIRELI                         CNPJ/CPF:   28.911.031/0001-13      Rep: 13.734     Insc Estad:   0030651080002        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     cristianecompras@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021923  LUCIANE DE LIMA SOUSA                       Rua francisco andrade bastos           196   Centro                            36700022 - LEOPOLDINA - MG
Fantasia:   ESPACO VERSATILE                                CNPJ/CPF:   15.527.216/0001-87      Rep: 22.619     Insc Estad:   001.961.0890091       Telefone:    (32) 99964-4338          E-mail:
E-mail NF-e:     lucianelima7666@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003921  MARCO ANTONIO SALGUEIRO                  RUA TIAGO JOSÉ PEREIRA              53    TRES CRUZES                      36700000 - LEOPOLDINA - MG
Fantasia:   MARCO ANTONIO SALGUEIRO                       CNPJ/CPF:   18.822.541/0001-60      Rep: 22.619     Insc Estad:   0022175950069        Telefone:    (32)3441-9944            E-mail:
E-mail NF-e:     marco.salgueiro@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014214  PE DE ANJO CALCADOS LEOPOLDINA LTDA        RUA BARAO DE COTEGIPE              131   CENTRO                          36700084 - LEOPOLDINA - MG
Fantasia:    PE DE ANJO CALCADOS                             CNPJ/CPF:   10.393.985/0001-16      Rep: 22.619     Insc Estad:   0010938340093        Telefone:    (32)3441-3152            E-mail:
E-mail NF-e:    PEDEANJO.CALCADOS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     16/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006883  IZABEL CARVALHO DE SOUZA LAGE ME           DOUTOR MANOEL DE PAULA            16    CENTRO                          36140000 - LIMA DUARTE - MG
Fantasia:    IZABEL CARVALHO DE SOUZA LAGE                  CNPJ/CPF:   25.839.002/0001-08      Rep: 22.619     Insc Estad:   3866117850015        Telefone:    (32)3281-2096            E-mail:
E-mail NF-e:     andreaclage@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/12/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 43

Pág. 43 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019902  TANSLEI MARIEL DE OLIVEIRA                  R DR MANOEL DE PAULA               08    CENTRO                          36140000 - LIMA DUARTE - MG
Fantasia:    TILEY CALCADOS                                  CNPJ/CPF:   02.787.428/0001-51      Rep: 22.619     Insc Estad:   3862543390097        Telefone:    (32) 3281-1018           E-mail:
E-mail NF-e:     nfe@tileycalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016974  MARIA APARECIDA DE MELO MOREIRA            RUA SAO PAULO                      751   CENTRO                          38295000 - LIMEIRA DO OESTE - MG
Fantasia:   MARIA APARECIDA DE MELO MOREIR                 CNPJ/CPF:   28.133.938/0001-07      Rep: 21.496     Insc Estad:   0030002210096        Telefone:    (34)3453-0548            E-mail:
E-mail NF-e:    MAYMARCIA@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     21/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019986  CARLOS EDUARDO ANTUNES VIEIRA              Av Montes Claros                     183   Centro                            39437000 - LONTRA - MG
Fantasia:    POIT DAS SANDALIAS                              CNPJ/CPF:   42.129.618/0001-04      Rep: 13.734     Insc Estad:   0040583100007        Telefone:    (38) 99927-9986          E-mail:
E-mail NF-e:     poitdassandalias@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010011  MARCIA RODRIGUES DOS SANTOS ROCHA 148293668AV MONTES CLAROS                  181   CENTRO                          39437000 - LONTRA - MG
Fantasia:   MARCIA RODRIGUES DOS SANTOS RO                CNPJ/CPF:   32.926.827/0001-17      Rep: 13.734     Insc Estad:   0033917300060        Telefone:    (38)99911-6824           E-mail:
E-mail NF-e:     nelcisojw@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011249  ALEXANDRE DE MOURA DIAS                  RUA ARTUR XAVIER PEDROSO           595   CENTRO                          37750000 - MACHADO - MG
Fantasia:   ALEXANDRE DE MOURA DIAS                        CNPJ/CPF:   11.066.361/0001-57      Rep: 21.564     Insc Estad:   0013522410033        Telefone:    (35) 99992-3131          E-mail:
E-mail NF-e:    xande_mmg@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019143  CASA DOIS IRMãOS LTDA                           Praça Antonio Carlos                  86     Centro                            37750000 - MACHADO - MG
Fantasia:   CASA DOIS IRMãOS                                CNPJ/CPF:   22.226.724/0001-90      Rep: 21.564     Insc Estad:   3900568760048        Telefone:    (35) 3295-1317           E-mail:
E-mail NF-e:     josesergiodesouzaraujo@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021575  GODOY DOMINGUES COM. DE CALCADOS E VESTUAR PRAÇA ANTONIO CARLOS              50    CENTRO                          37750000 - MACHADO - MG
Fantasia:   MARY RÔ                                         CNPJ/CPF:   53.077.399/0001-75      Rep: 21.564     Insc Estad:   0047723120010        Telefone:    (35) 99714-4449          E-mail:
E-mail NF-e:     marirrocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007948  GONCALVES COMERCIO DE CALCADOS LTDA       PRACA ANTONIO CARLOS              50    CENTRO                          37750000 - MACHADO - MG
Fantasia:    MARI-RO CALCADOS                               CNPJ/CPF:   17.331.471/0001-85      Rep: 21.564     Insc Estad:   3903727780091        Telefone:    (35)3295-2252            E-mail:
E-mail NF-e:     marirrocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019027  CASSIA TEREZINHA DE ALMEIDA ALVES            Rua Marechal Floriano Peixoto           118   Centro                            37305000 - MADRE DE DEUS DE MINAS - MG
Fantasia:   CASUAL STORE                                    CNPJ/CPF:   34.819.374/0001-55      Rep: 13.734     Insc Estad:   0035402060070        Telefone:    (32) 99800-3271          E-mail:
E-mail NF-e:     casualstoreminas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003588  A ROCHALAR LTDA - ME                      PEDRO ABRANTES                    270   CENTRO                          39690000 - MALACACHETA - MG
Fantasia:   A ROCHALAR LTDA - ME                            CNPJ/CPF:   19.511.948/0001-30      Rep: 22.941     Insc Estad:   3921273180009        Telefone:    (33)3514-1329            E-mail:
E-mail NF-e:     esquinaodaeconomia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010059  LOJA GUEDES E FILHOS LTDA                   AVE PEDRO ABRANTES                468   CENTRO                          39690000 - MALACACHETA - MG
Fantasia:    LOJA GUEDES E FILHOS LTDA                       CNPJ/CPF:   18.048.702/0001-00      Rep: 22.941     Insc Estad:   3921128700072        Telefone:    (33)3514-1219            E-mail:
E-mail NF-e:     lojaguedesefilhos@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021237   PATRICIA ESTEVES CORDEIRO                  AV Pedro Abrantes                    270   Centro                            39690000 - MALACACHETA - MG
Fantasia:   ESQUINAO DA ECONOMIA                           CNPJ/CPF:   23.641.379/0001-14      Rep: 22.941     Insc Estad:   26582520008           Telefone:    (33) 99111-1346          E-mail:
E-mail NF-e:     esquinaodaeconomia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010724  PEREIRA E MACEDO LTDA                     RUA MONSENHOR JORDE LOPES         28    CENTRO                          39690000 - MALACACHETA - MG
Fantasia:    PEREIRA E MACEDO LTDA                           CNPJ/CPF:   11.930.346/0001-05      Rep: 22.941     Insc Estad:   0015951760089        Telefone:    (33)91021-1191           E-mail:
E-mail NF-e:     wellenpm@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 44

Pág. 44 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020334  JULIANA CUSTODIO PEREIRA                    Rua Jose Gomes Lira                  190   Centro                            39516000 - MAMONAS - MG
Fantasia:   IMPACTO CALCADOS                               CNPJ/CPF:   31.505.071/0001-70      Rep: 22.941     Insc Estad:   0032756960004        Telefone:    (38) 99801-8835          E-mail:
E-mail NF-e:     agnaldoorlindohotmailcom080@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007438  MARIA JOSE APARECIDO ME                    PRACA COSTA E SILVA                 84    CENTRO                          39460000 - MANGA - MG
Fantasia:   MARIA JOSE APARECIDO ME                         CNPJ/CPF:   02.426.295/0001-98      Rep: 22.941     Insc Estad:   3937372900021        Telefone:    (38)3615-1470            E-mail:
E-mail NF-e:     mariajoseaparecido@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007893  IDEAL CALCADOS EIRELI                      AV SALIME NACIF                    710   CENTRO                          36900974 - MANHUAÇU - MG
Fantasia:   KATUXA CALCADOS                                CNPJ/CPF:   29.063.824/0001-92      Rep: 13.734     Insc Estad:   003.077.846/0010      Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:    JUNIO@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

001266  ANTONIO MENDES DA SILVA - ME               GUARANI                           52    CENTRO                          35666000 - MARAVILHAS - MG
Fantasia:   ANTONIO MENDES DA SILVA - ME                    CNPJ/CPF:   18.061.796/0001-58      Rep: 21.564     Insc Estad:   3971405980058        Telefone:    (37)3272-1238            E-mail:
E-mail NF-e:     marcos.lojamendes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017870  JUSSARA MACEDO OLIVEIRA VILAS BOAS          AV JOSE DE CAMPOS SALES            223   CENTRO                          37517000 - MARIA DA FÉ - MG
Fantasia:    IMPÉRIO MODAS                                   CNPJ/CPF:   29.050.919/0001-71      Rep: 21.564     Insc Estad:   0030768070040        Telefone:    (35)91369-9133           E-mail:
E-mail NF-e:    IMPERIOMODASMARIADAFE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     08/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021556  MAURICIO ANTONIO VALENTE                   Rua mestre nicanor                   47     Centro                            35420000 - MARIANA - MG
Fantasia:    STILLOS KIDS                                     CNPJ/CPF:   17.347.564/0001-06      Rep: 22.619     Insc Estad:   0020759630070        Telefone:    (31) 3558-5268           E-mail:
E-mail NF-e:     adrianadlvieira@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     28/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014955  ORGANIZAÇÃO JESSICA É JENIFHER LTDA         AVENIDA SALVADOR FURTADO          145   CENTRO                          35420000 - MARIANA - MG
Fantasia:   ORGANIZAÇÃO JESSICA                            CNPJ/CPF:   71.086.516/0001-49      Rep: 22.619     Insc Estad:   4008355370081        Telefone:    (31)3557-2008            E-mail:
E-mail NF-e:    GRUPO.L.A@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003979  RELIVRE CALÇADOS, ROUPAS E ACESSORIOS      RUA SEBASTICO LEMOS               22    SÃO GERALDO                     35606000 - MARTINHO CAMPOS - MG
Fantasia:    RELIVRE CALÇADOS, ROUPAS E ACE                  CNPJ/CPF:   08.220.858/0001-73      Rep: 21.564     Insc Estad:   0010137070047        Telefone:    (37)3524-1645            E-mail:
E-mail NF-e:     lojapistalivre@yahoo.com.br;lojapistalivre@yahoo.com.br;lojapistal

     Obs.:                                                           Proprietário :

Data Última Compra:     29/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022252  LAYLA DE OLIVEIRA EMERICK VILELA 09509055697  1 AV JOAO BATISTA                   335   CENTRO                          36972000 - MARTINS SOARES - MG
Fantasia:    LAYLA DE OLIVEIRA EMERICK VILE                   CNPJ/CPF:   32.031.877/0001-36      Rep: 22.619     Insc Estad:   003.318.6910005       Telefone:    (33) 98438-3759          E-mail:
E-mail NF-e:     layla_enerick@hotmail.com

     Obs.:                                                           Proprietário :

Condição de Pagamento:     23 21 DIAS
Data Última Compra:     20/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018558  ESTACAO DA MODA MASCULINA E FEMININA E CALCA Praca Jose de Assis lebrao              30     Centro                            39915000 - MATA VERDE - MG
Fantasia:   ESTACAO DA MODA MASCULINA E FE                 CNPJ/CPF:   47.588.214/0001-94      Rep: 22.941     Insc Estad:   0044169880005        Telefone:    (33) 98822-6094          E-mail:
E-mail NF-e:     diosmarcentral_bisoterias@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021713  ALFREDO DA SILVA VIANA                      Rua presidente Tancredo neves          101   Centro                            35670000 - MATEUS LEME - MG
Fantasia:    CRIS MODAS                                      CNPJ/CPF:   54.637.162/0001-64      Rep: 22.500     Insc Estad:   0048636490065        Telefone:    (31) 99304-5571          E-mail:
E-mail NF-e:     crismodas60@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020766  ALFREDO DA SILVA VIANNA                     Rua Presidente Tancredo Neves          101   Centro                            35670000 - MATEUS LEME - MG
Fantasia:    CRIS MODAS                                      CNPJ/CPF:   46.969.460/0001-23      Rep: 22.500     Insc Estad:   004.378.573/0063      Telefone:    (31) 99304-5571          E-mail:
E-mail NF-e:     crismodas60@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005757  FUTURISTA CALCADOS E CONFEC LTDA - MTZ       GETULIO VARGAS                    267   CENTRO                          35670000 - MATEUS LEME - MG
Fantasia:    FUTURISTA CALCADOS E CONFEC LT                 CNPJ/CPF:   03.224.496/0001-75      Rep: 22.500     Insc Estad:   4070298090006        Telefone:    (31)3535-9570            E-mail:
E-mail NF-e:     lojasbomdemais@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 45

Pág. 45 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

002897  LUCELIO APARECIDO DE FREITAS - ME            PRESIDENTE CASTELO BRANCO         0     CENTRO                          39527000 - MATO VERDE - MG
Fantasia:    LUCELIO APARECIDO DE FREITAS -                   CNPJ/CPF:   23.912.744/0001-88      Rep: 22.941     Insc Estad:   4105350580067        Telefone:    (38)9972-7079            E-mail:
E-mail NF-e:     lucelio9d@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010662  MARCIA TANIA DIAS FREITAS                   AVE PRESIDENTE CASTELO BRANCO      148   CENTRO                          39527000 - MATO VERDE - MG
Fantasia:   MARCIA TANIA DIAS FREITAS                        CNPJ/CPF:   21.880.299/0001-96      Rep: 22.941     Insc Estad:   4104981360050        Telefone:    (38)3813-1390            E-mail:
E-mail NF-e:     sapatariatania@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003985  SAPATARIA ETEROVICK LTDA                   PCA BOM JESUS                      116   CENTRO                          35720000 - MATOZINHOS - MG
Fantasia:    SAPATARIA ETEROVICK LTDA                        CNPJ/CPF:   18.772.871/0001-99      Rep: 22.500     Insc Estad:   4112217220052        Telefone:    (31)3712-1634            E-mail:
E-mail NF-e:     scallycalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021401  VANESSA MARQUES DA SILVA D ASSUMPCAO GONCA Av. caio martins                      908   São Sebastião                      35720000 - MATOZINHOS - MG
Fantasia:   VW CALCADOS                                    CNPJ/CPF:   52.837.074/0001-80      Rep: 22.500     Insc Estad:   0047567590034        Telefone:    (31) 99707-4455          E-mail:
E-mail NF-e:     vanessamsilva1@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017846  RC CALCADOS LTDA                         RUA GETÚLIO VARGAS                 220   CENTRO                          39650000 - MINAS NOVAS - MG
Fantasia:    PE QUENTE CALCADOS                             CNPJ/CPF:   08.319.482/0001-59      Rep: 22.751     Insc Estad:   0010212960083        Telefone:    (33)91251-1285           E-mail:
E-mail NF-e:    PEQUENTE_RC@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006559  RILDO CHAGAS BARBOSA ME                   PCA AMPARO                        16    CENTRO                          39650000 - MINAS NOVAS - MG
Fantasia:    PE QUENTE CALCADOS                             CNPJ/CPF:   86.482.494/0001-03      Rep: 22.751     Insc Estad:   4189168450076        Telefone:    (33)3764-1232            E-mail:
E-mail NF-e:    PEQUENTE10@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005229  LENE CALCADOS LTDA                     BOM JESUS                         276   CENTRO                          39373000 - MIRABELA - MG
Fantasia:    LENE CALCADOS LTDA                              CNPJ/CPF:   03.949.697/0001-30      Rep: 22.941     Insc Estad:   4200901490089        Telefone:    (38)3239-1155            E-mail:
E-mail NF-e:     edilenemartins22@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017868  MARIA DE FATIMA MORAIS                    RUA JOÃO RESENDE                  58    CENTRO                          36790000 - MIRAÍ - MG
Fantasia:   ARTMANHA                                        CNPJ/CPF:   26.183.061/0001-25      Rep: 22.619     Insc Estad:   4226238410049        Telefone:    (32) 99137-8263          E-mail:
E-mail NF-e:     fatimamcumani@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008264  MARLUCIO FERREIRA - ME                    RUA DOUTOR RESENDE 20 LOJA B     SN   CENTRO                          36790000 - MIRAÍ - MG
Fantasia:   MARLUCIO FERREIRA - ME                          CNPJ/CPF:   02.264.126/0001-07      Rep: 22.619     Insc Estad:   4227351900014        Telefone:    (329)9936--6114          E-mail:
E-mail NF-e:     sapatariadomarlucio@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

001278  CASA REAL LTDA                         DO COMERCIO                       193   CENTRO                          35470000 - MOEDA - MG
Fantasia:   CASA REAL LTDA                                   CNPJ/CPF:   19.209.766/0001-09      Rep: 21.495     Insc Estad:   4230751690029        Telefone:    (31)3575-1021            E-mail:
E-mail NF-e:     casarealmoeda@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014890  MARIA HELENA GONÇALVES DO PRADO           PRACA CRISTO REI                   26    CENTRO                          39495000 - MONTALVÂNIA - MG
Fantasia:   MARIA HELENA GONÇALVES DO PRAD                CNPJ/CPF:   26.324.194/0001-74      Rep: 22.941     Insc Estad:   4275585230021        Telefone:    (38)3614-1307            E-mail:
E-mail NF-e:    MARIAHELENAGP@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     05/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021600  FRANCISCA DANTAS VIEIRA                   RUA , BENJAMIM CONSTANT            14    CENTRO                          38475000 - MONTE ALEGRE DE MINAS - MG
Fantasia:   DESTAK MODAS                                   CNPJ/CPF:   21.708.854/0001-05      Rep: 21.496     Insc Estad:   4283191400040        Telefone:    (34) 3283-1238           E-mail:
E-mail NF-e:     fdvieira@ol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003674  EDVALDO JOSE DE AQUINO - ME                CORONEL JONATHAS                  58    CENTRO                          39500000 - MONTE AZUL - MG
Fantasia:   EDVALDO JOSE DE AQUINO - ME                     CNPJ/CPF:   21.985.684/0001-06      Rep: 22.941     Insc Estad:   4294370460099        Telefone:    (38)3811-1177            E-mail:
E-mail NF-e:     lojaeliane1@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 46

Pág. 46 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

007049  FERNANDO FAMUEL PEREIRA DE OLIVEIRA         PRACA CEL JONATHAS                 10    CENTRO                          39500000 - MONTE AZUL - MG
Fantasia:   FERNANDO FAMUEL PEREIRA DE OLI                  CNPJ/CPF:   09.370.931/0001-56      Rep: 22.941     Insc Estad:   0010614130000        Telefone:    (38)9135-5602            E-mail:
E-mail NF-e:     fernandofamuel@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019232  GAMMA ROUPAS E CALCADOS LTDA                 Praca coronel jonathas                 328   Centro                            39500000 - MONTE AZUL - MG
Fantasia:   GAMMA                                           CNPJ/CPF:   01.135.304/0001-29      Rep: 22.941     Insc Estad:   429.610.989/0095      Telefone:    (38) 3831-1522           E-mail:
E-mail NF-e:     jucelia@gammix.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016761  SAMUEL FILIPE ALVES BARBOSA                AV TREMEDAL                       198   CENTRO                          39500000 - MONTE AZUL - MG
Fantasia:    ELLEN CALCADOS                                  CNPJ/CPF:   42.020.201/0001-09      Rep: 22.941     Insc Estad:   0042767710098        Telefone:    (38)91371-1741           E-mail:
E-mail NF-e:    ELLENCALCADOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010152  JERUZA FELICIO DE OLIVEIRA 04833391643        AVENIDA DONA CLARA                312   CENTRO                          38500000 - MONTE CARMELO - MG
Fantasia:   MODA CONFORT                                   CNPJ/CPF:   32.995.198/0001-87      Rep: 21.496     Insc Estad:   0033967190048        Telefone:    (34)3842-3669            E-mail:
E-mail NF-e:     jeruza.f.oliveira@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014022  KARINE CARMEM MARINHO SILVA               AV PARANAIBA                       520   BOA VISTA                        38500000 - MONTE CARMELO - MG
Fantasia:    KARINE CARMEM MARINHO SILVA                    CNPJ/CPF:   16.558.499/0001-97      Rep: 21.496     Insc Estad:   0020001760068        Telefone:    (34)99035-5117           E-mail:
E-mail NF-e:    KARINECARMEM688@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004755   LELIANE PINHEIRO DE RESENDE MUNDIM         RUA RAUL SOARES                    80    CENTRO                          38500000 - MONTE CARMELO - MG
Fantasia:    LELIANE PINHEIRO DE RESENDE MU                  CNPJ/CPF:   25.325.564/0001-25      Rep: 21.496     Insc Estad:   4315863030090        Telefone:    (34)3842-1808            E-mail:
E-mail NF-e:     cheiadegracacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021838  NILSO GONCALVES SILVA E CIA LTDA             Av romualdo rezende                  1477   Vila nova                          38500000 - MONTE CARMELO - MG
Fantasia:   MAGAZINE DOS ESPORTES                          CNPJ/CPF:   00.818.786/0001-59      Rep: 21.496     Insc Estad:   4319454970058        Telefone:    (34) 3842-3788           E-mail:
E-mail NF-e:     magazinedosesportes@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009305  NELSON PEDROSO FILHO - CPF 324 181 756 - 34 - EP RUA PREFEITO JOSÉ CARLOS FRANCISCO 392   CENTRO                          37580000 - MONTE SIÃO - MG
Fantasia:   NELSON PEDROSO FILHO - CPF 324                  CNPJ/CPF:   86.461.985/0002-59      Rep: 21.564     Insc Estad:   4348805110152        Telefone:    (35)3441-2982            E-mail:
E-mail NF-e:     npcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011830  ALAUICE PEREIRA DE OLIVEIRA EIRELI           RUA DOM PEDRO SEGUNDO            370   CENTRO                          39400058 - MONTES CLAROS - MG
Fantasia:    ALAUICE PEREIRA                                  CNPJ/CPF:   35.195.291/0001-03      Rep: 22.941     Insc Estad:   0035711040065        Telefone:    (51)383225-713           E-mail:
E-mail NF-e:    ESCRITORIOVENUS@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003759  BOAVENTURA E CIA LTDA - ME                DOUTOR SANTOS                     102   CENTRO                          39400001 - MONTES CLAROS - MG
Fantasia:   BOAVENTURA E CIA LTDA - ME                       CNPJ/CPF:   65.277.741/0001-60      Rep: 22.941     Insc Estad:   4337911860070        Telefone:    (38)3690-1317            E-mail:
E-mail NF-e:     boaventuraecia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003700  CALCADOS DA MODA MONTES CLAROS LTDA       GOVERNADOR VALADARES             249   CENTRO                          39400047 - MONTES CLAROS - MG
Fantasia:   CALCADOS DA MODA MONTES CLAROS               CNPJ/CPF:   01.058.204/0001-46      Rep: 22.941     Insc Estad:   4339607060079        Telefone:    (38)3690-1340            E-mail:
E-mail NF-e:    BRUNOBOAVENTURA.S@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007529  CALCADOS FERREIRA LTDA                    RUA DOM PEDRO II                   385   CENTRO                          39400058 - MONTES CLAROS - MG
Fantasia:   CALCADOS FERREIRA LTDA                          CNPJ/CPF:   17.657.537/0001-21      Rep: 22.941     Insc Estad:   4334013010040        Telefone:    (38)3221-9100            E-mail:
E-mail NF-e:     creditenis-escritorio@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003418  COMERCIAL DE CALCADOS SOUZA E PEREIRA LTDA - SCO FRANCISCO                     351   CENTRO                          39400048 - MONTES CLAROS - MG
Fantasia:   COMERCIAL DE CALCADOS SOUZA E                  CNPJ/CPF:   16.422.705/0001-37      Rep: 22.941     Insc Estad:   0019935890007        Telefone:    (38)3216-9610            E-mail:
E-mail NF-e:     loja16@lojascometa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 47

Pág. 47 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

001282  COMERCIAL ROBELMAR LTDA                DO FLAMENGO                       407   MARACANA                        39403069 - MONTES CLAROS - MG
Fantasia:   COMERCIAL ROBELMAR LTDA                        CNPJ/CPF:   71.421.465/0001-64      Rep: 22.941     Insc Estad:   4338654630012        Telefone:    (38)3213-1729            E-mail:
E-mail NF-e:     robimcalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016597  COMERCIAL SOARES FONSECA LTDA             RUA PADRE GANGANA                 179   SANTOS REIS                      39401166 - MONTES CLAROS - MG
Fantasia:    IDEAL CONFECCOES                                CNPJ/CPF:   71.233.134/0002-81      Rep: 22.941     Insc Estad:   4338492950165        Telefone:    (38)3212-7985            E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     05/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015167  COMERCIO DE CALCADOS OLIVEIRA EIRELI        RUA SÃO FRANCISCO                 393   CENTRO                          39400048 - MONTES CLAROS - MG
Fantasia:    MIB CALCADOS                                    CNPJ/CPF:   08.643.308/0001-67      Rep: 22.941     Insc Estad:   0010281130086        Telefone:    (38)88496-6037           E-mail:
E-mail NF-e:    FRANQUIA14@LOJASMIB.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     07/12/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009273  DEUSELINA CORREA SILVA - ME                RUA CORONEL JOAQUIM COSTA         182   CENTRO                          39400049 - MONTES CLAROS - MG
Fantasia:    DEUSELINA CORREA SILVA - ME                     CNPJ/CPF:   26.605.677/0001-47      Rep: 22.941     Insc Estad:   0028697270065        Telefone:    (38)98627-7302           E-mail:
E-mail NF-e:     planetapemoc@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012522  DIAS E ALMEIDA COMERCIAL LTDA              RUA CICERO ROMAO BATISTA           760   JARDIM PRIMAVERA                 39404158 - MONTES CLAROS - MG
Fantasia:    HIZA CALÇADOS                                   CNPJ/CPF:   34.979.700/0001-91      Rep: 22.941     Insc Estad:   0035531620063        Telefone:    (38)213-1-1444           E-mail:
E-mail NF-e:    IZACALCADOS2019@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015328  DILSON MENDES MATOS JUNIOR                RUA JOÃO CARDOSO DE OLIVEIRA       494   VILA CAMPOS                      39403069 - MONTES CLAROS - MG
Fantasia:    DISTRIBUIDORA JUNIOR CALCADOS                  CNPJ/CPF:   41.846.049/0001-47      Rep: 22.941     Insc Estad:   0017861640035        Telefone:    (38)99791-1471           E-mail:
E-mail NF-e:    JUNIORCALCADOS19@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002919  DU FORTE CALCADOS LTDA EPP               DOS MANGABEIRAS                   179   SAGRADA FAMILIA                  39401018 - MONTES CLAROS - MG
Fantasia:   DU FORTE CALCADOS LTDA EPP                      CNPJ/CPF:   13.004.949/0001-01      Rep: 22.941     Insc Estad:   0017073860081        Telefone:    (38)3222-6894            E-mail:
E-mail NF-e:     dufortecalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

015166  ELSON FN BATISTA CALCADOS EIRELI            PRAÇA DOUTOR CARLOS VERSIANI       50    CENTRO                          39400612 - MONTES CLAROS - MG
Fantasia:    MIB CALCADOS                                    CNPJ/CPF:   18.143.671/0001-77      Rep: 22.941     Insc Estad:   0021513690043        Telefone:    (38)91758-8727           E-mail:
E-mail NF-e:    FRANQUIA23@LOJASMIB.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     30/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020501  GILTON PEREIRA DE SOUZA                     Rua E 26831580084                   114    Belvedere                         39406150 - MONTES CLAROS - MG
Fantasia:    GILTON                                           CNPJ/CPF:   23.923.106/0001-62      Rep: 22.941     Insc Estad:   002.683.158/0084      Telefone:    (38) 99112-9679          E-mail:
E-mail NF-e:     giltongps@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018297   IRIS MODAS E ACESSORIOS LTDA                Rua Macedonia                       118   Santos Reis                        39401228 - MONTES CLAROS - MG
Fantasia:    IRIS MODAS                                      CNPJ/CPF:   43.946.264/0001-45      Rep: 22.941     Insc Estad:   0041778210023        Telefone:    (38) 99144-6918          E-mail:
E-mail NF-e:     irismodas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

003395  JOAO PAULO COSTA NASCIMENTO - ME           GERALDO ATHAYDE                   740   ALTO SÃO JOÃO                    39400292 - MONTES CLAROS - MG
Fantasia:   JOAO PAULO COSTA NASCIMENTO -                  CNPJ/CPF:   10.821.598/0001-33      Rep: 22.941     Insc Estad:   0011690900075        Telefone:    (38)3213-0397            E-mail:
E-mail NF-e:     joaodedeusmarques@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

003695  LEMOK CALCADOS LTDA - EPP                 DOUTOR SANTOS                     146   CENTRO                          39400001 - MONTES CLAROS - MG
Fantasia:   LEMOK CALCADOS LTDA - EPP                       CNPJ/CPF:   04.386.097/0001-73      Rep: 22.941     Insc Estad:   4331215610029        Telefone:    (38)3690-1390            E-mail:
E-mail NF-e:     calcadosbsw@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021675  LOS PES CALCADOS LTDA ME                   AV JOAQUIM DE ABREU                261   DISTRITO NOVA ESPERANÇA          39414000 - MONTES CLAROS - MG
Fantasia:   LOS PES                                          CNPJ/CPF:   21.280.388/0001-00      Rep: 22.941     Insc Estad:   0024536530061        Telefone:    (38) 98406-4760          E-mail:
E-mail NF-e:     lospescalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 48

Pág. 48 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

016855  MARIA APARECIDA RUAS                     RUA CORONEL JOAQUIM COSTA         148   CENTRO                          39400049 - MONTES CLAROS - MG
Fantasia:    BINHA CALCADOS                                  CNPJ/CPF:   26.346.569/0001-05      Rep: 22.941     Insc Estad:   4336437750077        Telefone:    (38)98020-0642           E-mail:
E-mail NF-e:    DELVAIRFERREIRA122@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003756  MARIA VALDETE RIBEIRO PEREIRA                ACACIAS                            79    JK                               39404342 - MONTES CLAROS - MG
Fantasia:   MARIA VALDETE RIBEIRO PEREIRA                   CNPJ/CPF:   01.315.566/0001-75      Rep: 22.941     Insc Estad:   4339770430068        Telefone:    (38)3215-1490            E-mail:
E-mail NF-e:     nossalojamoc@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020403  MARIANA DANIELE BOTELHO RUAS               Rua Coronel Joaquim Costa             176   Centro                            39400049 - MONTES CLAROS - MG
Fantasia:    PE BONITO CALCADOS                              CNPJ/CPF:   42.892.228/0001-83      Rep: 22.941     Insc Estad:   0041055660003        Telefone:    (38) 99250-3260          E-mail:
E-mail NF-e:     adenilsonalvessoares@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019605  MARILENE PEREIRA SOUTO AGUIAR               Rua Magnesita                       200   Monte Carmelo                     39402070 - MONTES CLAROS - MG
Fantasia:    JM CALCADOS                                     CNPJ/CPF:   27.733.462/0001-74      Rep: 22.941     Insc Estad:   29660330014           Telefone:    (38) 99170-7048          E-mail:
E-mail NF-e:     marilenesoutoaguiar@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002842  MEU PE CALCADOS E ACESSORIOS LTDA - ME      CORONEL JOAQUIM COSTA             147   CENTRO                          39400049 - MONTES CLAROS - MG
Fantasia:   MEU PE CALCADOS E ACESSORIOS L                 CNPJ/CPF:   11.797.809/0001-02      Rep: 22.941     Insc Estad:   0015786780040        Telefone:    (38)3216-9034            E-mail:
E-mail NF-e:     adenilsonalvessoares@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016622  MIRIAM DE JESUS RODRIGUES FIUZA            RUA CORONEL JOAQUIM COSTA         138   CENTRO                          39400049 - MONTES CLAROS - MG
Fantasia:   IMPACTO CALCADOS                               CNPJ/CPF:   44.167.523/0001-00      Rep: 22.941     Insc Estad:   0041928620078        Telefone:    (38)92514-4969           E-mail:
E-mail NF-e:    MIRIAMJESUS557@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008333  MJ E BRUNOS CALCADOS LTDA - ME              PRACA BEATO FRANCISCO COLL         6    MARACANA                        39403081 - MONTES CLAROS - MG
Fantasia:   BRUNOS CALCADOS                                CNPJ/CPF:   26.095.547/0001-01      Rep: 22.941     Insc Estad:   0020499530012        Telefone:    (38)3215-5622            E-mail:
E-mail NF-e:    BRUNOSCALCADOS20@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014911  PAM COMÉRCIO DE CALCADOS EIRELI            RUA BOA VONTADE                   127   SANTA RITA I                      39400415 - MONTES CLAROS - MG
Fantasia:    DISTRIBUIDORA ABF                               CNPJ/CPF:   35.685.153/0001-02      Rep: 22.941     Insc Estad:   0036152700035        Telefone:    (38)99577-7178           E-mail:
E-mail NF-e:    TONYBATISTA2@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009913  PASSARELA CALCADOS E ACESSORIOS DE MONTES C RUA SCO FRANCISCO 394 LETRA A     SN   CENTRO                          39400048 - MONTES CLAROS - MG
Fantasia:    PASSARELA CALCADOS E ACESSORIO                 CNPJ/CPF:   32.398.823/0002-94      Rep: 22.941     Insc Estad:   0033499090171        Telefone:    (38)3213-4193            E-mail:
E-mail NF-e:     escritoriovenus@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022075  RENATA ALVES BORGES 04702767623            AVENIDA C                          150   JARDIM PRIMAVERA                 39404151 - MONTES CLAROS - MG
Fantasia:   RENATA ALVES BORGES 0470276762                 CNPJ/CPF:   18.198.246/0001-85      Rep: 22.941     Insc Estad:   002.156.603/0013      Telefone:    (31)9919-29799           E-mail:
E-mail NF-e:     virginiarochafarias@gmail.com

     Obs.:                                                           Proprietário :

Condição de Pagamento:     43 30/60/90/120 DIAS
Data Última Compra:     27/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

000492  RODRIGUES E SOARES LTDA                   PADRE GANGANA                     196   SANTOS REIS                      39401166 - MONTES CLAROS - MG
Fantasia:   RODRIGUES E SOARES LTDA                        CNPJ/CPF:   02.124.239/0001-07      Rep: 22.941     Insc Estad:   4337148610099        Telefone:    (38)3212-7220            E-mail:
E-mail NF-e:     heloiza_variedades@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022211  ROSANGELA DA SILVA PEREIRA                 AV CORACAO DE JESUS                692   SAO GERALDO                     39403170 - MONTES CLAROS - MG
Fantasia:   ROSANGELA CONFECÇÕES                          CNPJ/CPF:   41.981.738/0001-64      Rep: 22.941     Insc Estad:   40493270060           Telefone:    (38) 98848-4091          E-mail:
E-mail NF-e:     rosangelaconfeccao@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016923  SAMYRA CALCADOS E ACESSORIOS LTDA          AV CASTELAR PRATES                 58    MAJOR PRATES                     39403206 - MONTES CLAROS - MG
Fantasia:   SAMYRA CALCADOS                                CNPJ/CPF:   04.850.817/0001-00      Rep: 22.941     Insc Estad:   4331602860088        Telefone:    (38)3214-8018            E-mail:
E-mail NF-e:    SAMYRA.2010@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     07/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 49

Pág. 49 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021023  SILVANO GONCALVES PEREIRA                  Rua Joaquim Queiroz                  65      Distrito Nova Esperanca              39414000 - MONTES CLAROS - MG
Fantasia:   CONFECCOES ALTERNATIVA                         CNPJ/CPF:   04.019.243/0001-22      Rep: 22.941     Insc Estad:   4330936720011        Telefone:    (38) 3215-1490           E-mail:
E-mail NF-e:     nossalojamoc@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019333  W EME LTDA                                     Avenida francisco caetani               1112   Major Prates                      39403202 - MONTES CLAROS - MG
Fantasia:   ANSA MAGAZINE                                   CNPJ/CPF:   18.880.112/0001-40      Rep: 22.941     Insc Estad:   4334268740019        Telefone:    (38) 3690-1021           E-mail:
E-mail NF-e:    nfe.weme@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021386   ZELIA ALVES DA SILVA                            Avenida Castelar Prates                310   Major prates                       39403206 - MONTES CLAROS - MG
Fantasia:   AMARAL STORE                                    CNPJ/CPF:   09.006.481/0001-17      Rep: 22.941     Insc Estad:   001.040.794/0090      Telefone:    (38) 99921-7326          E-mail:
E-mail NF-e:     zelia.amaral2015@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022314  LUZIA DOS SANTOS CORDEIRO DANTAS           PC JOSE BATISTA                     206   CENTRO                          39547000 - MONTEZUMA - MG
Fantasia:    LUZIA DOS SANTOS CORDEIRO DANT                CNPJ/CPF:   39.460.110/0001-71      Rep: 22.941     Insc Estad:   38703890015           Telefone:    (38) 99931-3161          E-mail:
E-mail NF-e:     luziasantosmtz@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016250  EDMAR XAVIER DA COSTA                    RUA CEL.ARNALDO XAVIER CORDEIRO    209   CENTRO                          35628000 - MORADA NOVA DE MINAS - MG
Fantasia:   CALÇADOS E CIA                                  CNPJ/CPF:   09.626.082/0001-59      Rep: 21.564     Insc Estad:   001074107.00-30       Telefone:    (37)3755-2430            E-mail:
E-mail NF-e:    EDVARMORADA@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     04/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

012303  OSMAR JOSÉ DOS SANTOS                    RUA CORONEL ARNADO XAVIER CORDEIRO425   CENTRO                          35628000 - MORADA NOVA DE MINAS - MG
Fantasia:   OSMAR CALÇADOS                                 CNPJ/CPF:   18.032.524/0001-20      Rep: 21.564     Insc Estad:   4351498710011        Telefone:    (37)3755-1687            E-mail:
E-mail NF-e:    VISUALMODASMORADA@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005335  A C DE SOUZA OLIVEIRA COMERCIO - ME          AV DOUTOR PASSOS                 738   BARRA                           36884002 - MURIAÉ - MG
Fantasia:   A C DE SOUZA OLIVEIRA COMERCIO                  CNPJ/CPF:   17.137.079/0001-08      Rep: 13.734     Insc Estad:   0020557000076        Telefone:    (94)3346-2800            E-mail:
E-mail NF-e:     anaclaudiaacessorios@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

021192  DIOGO LUIZ CAVALCANTE DE ARAUJO EIRELI        Praca joao pinheiro                   183 L 8 Centro                            36880043 - MURIAÉ - MG
Fantasia:    PARAIBANAS                                      CNPJ/CPF:   33.909.335/0001-86      Rep: 21.080     Insc Estad:   34684470059           Telefone:    (21) 96804-4882          E-mail:
E-mail NF-e:     paraibanasescritorio@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022161  ENEDINA DE FREITAS NEVES                  RUA PASCHOAL DEMARQUES            32    DORNELAS                        36884186 - MURIAÉ - MG
Fantasia:   UNIVERSO DO CHINELO                            CNPJ/CPF:   55.166.332/0001-32      Rep: 22.619     Insc Estad:   48952700031           Telefone:    (32) 98867-8052          E-mail:
E-mail NF-e:     ninihafreitas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007002  OFICINA DA MODA CALCADOS E ROUOAS LTDA     PASCHOAL DEMARQUE                59    DORNELAS                        36880000 - MURIAÉ - MG
Fantasia:   NOVA ESTUDANTIL CALCADOS E ROU                 CNPJ/CPF:   68.506.922/0001-09      Rep: 22.619     Insc Estad:   4397718700040        Telefone:    (32) 3721-1414           E-mail:
E-mail NF-e:     oficinadamoda37211414@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007053   VIA VILLE CALCADOS ROUPAS LTDA - EPP         DOUTOR ALVES PEQUENO 180 - LOJA 34 E5     CENTRO                          36880000 - MURIAÉ - MG
Fantasia:    VIA VILLE CALCADOS ROUPAS LTDA                  CNPJ/CPF:   01.031.037/0001-40      Rep: 22.619     Insc Estad:   4399595590073        Telefone:    (32)3722-1181            E-mail:
E-mail NF-e:     viaville2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

000047  KATIA CILENE DE FREITAS STOFEL               BENEDITO VALADARES                94    CENTRO                          36958000 - MUTUM - MG
Fantasia:    KATIA CILENE DE FREITAS STOFEL                   CNPJ/CPF:   38.598.371/0001-90      Rep: 22.036     Insc Estad:   4409100090087        Telefone:    (33)3312-1438            E-mail:
E-mail NF-e:     kitt_vest@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002923  SAPARRO CALCADOS E CONFECCOES LTDA - ME     BENEDITO VALADARES                248   CENTRO                          36955000 - MUTUM - MG
Fantasia:   SAPARRO CALCADOS E CONFECCOES                 CNPJ/CPF:   05.920.986/0001-31      Rep: 22.036     Insc Estad:   3132536340023        Telefone:    (33)3312-1730            E-mail:
E-mail NF-e:     kittvest@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 50

Pág. 50 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

007065  ANGELA BASTOS CASAGRANDE                  PRACA PEDRO DE ALCANTARA MAGALHAES 22    CENTRO                          37890000 - MUZAMBINHO - MG
Fantasia:    LOJA CASAGRANDE CALCADOS LTDA                 CNPJ/CPF:   13.580.334/0001-23      Rep: 21.564     Insc Estad:   0017666460031        Telefone:    (35) 99830-1033          E-mail:
E-mail NF-e:     angelabastoscasagrande@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022193  DELFINOS E SOUZA LTDA                       Av dr americo luz                     280   Centro                            37890000 - MUZAMBINHO - MG
Fantasia:    LOJAO SAO PAULO                                 CNPJ/CPF:   34.921.743/0001-16      Rep: 21.564     Insc Estad:   35485440037           Telefone:    (35) 99949-7437          E-mail:
E-mail NF-e:     marialuciasouza465@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

017291  FERNANDO FIGUEIREDO ANGELICA              AV SANTOS DUMONT                  209   CENTRO                          39860000 - NANUQUE - MG
Fantasia:    HAVAÍ CALCADOS                                  CNPJ/CPF:   29.189.799/0001-98      Rep: 3.471      Insc Estad:   0030885950011        Telefone:    (33)91170-0874           E-mail:
E-mail NF-e:    FERNANDOCALCADOSNANUQUE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

013942  MODA & CIA 02 LTDA                         AV SANTOS DRUMOND                219   CENTRO                          39860000 - NANUQUE - MG
Fantasia:   MODA & CIA 02 LTDA                               CNPJ/CPF:   10.831.571/0001-21      Rep: 3.471      Insc Estad:   0011750640040        Telefone:    (33)88071-1278           E-mail:
E-mail NF-e:    GRUPOMODAECIAANA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021152  ANTONIO CARLOS ALVES E ALVES LTDA             Avenida Sao Joao                     1900   Vila Leolita                        37250000 - NEPOMUCENO - MG
Fantasia:    LOJA CRUZEIRO                                   CNPJ/CPF:   86.498.631/0001-06      Rep: 13.734     Insc Estad:   4468859860026        Telefone:    (35) 99993-7478          E-mail:
E-mail NF-e:     lojacruzeiro@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016811  LOURENCONI GARCIA CALCADOS E CONFECCOES SOCRUA DR ERNANE VILELA LIMA           244   CENTRO                          37250000 - NEPOMUCENO - MG
Fantasia:    TROPICANA                                       CNPJ/CPF:   20.459.355/0001-50      Rep: 13.734     Insc Estad:   0023787110046        Telefone:    (35)3861-1936            E-mail:
E-mail NF-e:    LOJASTROPICANA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

014599   CLELIA DE SOUZA                          RUA GOVERNADOR VALADARES         665   CENTRO                          35920000 - NOVA ERA - MG
Fantasia:   SOUARTE MODAS                                  CNPJ/CPF:   06.295.675/0001-91      Rep: 22.751     Insc Estad:   4472898850073        Telefone:    (31)3861-1175            E-mail:
E-mail NF-e:    SOUARTEMODAS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022329   IPA CALÇADOS NOVA ERA LTDA                 R GOVERNADOR VALADARES            611   CENTRO                          35920000 - NOVA ERA - MG
Fantasia:    IPA CALÇADOS                                    CNPJ/CPF:   59.073.672/0001-70      Rep: 22.751     Insc Estad:   50970480083           Telefone:    (31) 3822-2637           E-mail:
E-mail NF-e:     mateus.gerencia@ggatacadista.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011898  CASA ESTRELA EIRELI                        PRAÇA DOUTOR ANTONIO FONSECA JUNIO 2     CENTRO                          34000000 - NOVA LIMA - MG
Fantasia:   CASA ESTRELA                                    CNPJ/CPF:   19.251.495/0001-50      Rep: 22.500     Insc Estad:   4480586890019        Telefone:    (31)3541-1235            E-mail:
E-mail NF-e:     financeiro@casaestrela.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010481  COMERCIAL NOPEL EIRELI                    RUA BERNARDINO DELIMA             56    CENTRO                          34000000 - NOVA LIMA - MG
Fantasia:   COMERCIAL NOPEL EIRELI                          CNPJ/CPF:   23.499.770/0001-26      Rep: 22.500     Insc Estad:   0026461550003        Telefone:    (31)3492-6875            E-mail:
E-mail NF-e:    PATRICIA@FRANKCALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006380  CONSTANTINOS LIBONI COUGIAS ME             SANTA CRUZ 76 - LETRA A             76    CENTRO                          34000000 - NOVA LIMA - MG
Fantasia:   CONSTANTINOS LIBONI COUGIAS ME                 CNPJ/CPF:   64.299.019/0001-63      Rep: 22.500     Insc Estad:   4487279530020        Telefone:    (31)3541-2860            E-mail:
E-mail NF-e:    ATENASCONFECCOES@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021499  FOX FASHION REPRESENTACAO COMERCIAL LTDA   Rua Rio Verde                       17    Nossa Senhora de Fátima             34012379 - NOVA LIMA - MG
Fantasia:   FOX FASHION REPRESENTACAO                      CNPJ/CPF:   27.057.532/0001-11      Rep: 22.619     Insc Estad:                            Telefone:    (55)5555-55              E-mail:
E-mail NF-e:     opoj.assessoria@gmail.comm

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003766  MILPE CONFECCOES E CALCADOS LTDA - ME       BERNARDINO DE LIMA                 102   CENTRO                          34000000 - NOVA LIMA - MG
Fantasia:    MILPE CONFECCOES E CALCADOS LT                 CNPJ/CPF:   23.787.328/0001-03      Rep: 22.500     Insc Estad:   4485586970092        Telefone:    (31)3541-3738            E-mail:
E-mail NF-e:     sapatariamilpe@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 51

Pág. 51 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019374   PATRICIA FERNANDA COURA SILVA               Rua bias fortes                       208   Centro                            34000168 - NOVA LIMA - MG
Fantasia:   COURA SHOES                                    CNPJ/CPF:   32.348.494/0001-96      Rep: 22.500     Insc Estad:   003.345.687/0051      Telefone:    (31) 3542-5851           E-mail:
E-mail NF-e:     patyfer31@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017639  VILMA LUCIA ALVES FERREIRA SILVA             R DOMINGOS RODRIGUES              62    CENTRO                          34000075 - NOVA LIMA - MG
Fantasia:    VILA DOS ESPORTES                               CNPJ/CPF:   04.804.675/0001-44      Rep: 22.500     Insc Estad:   5391586410017        Telefone:    (31)3541-2980            E-mail:
E-mail NF-e:    VILLAFINANCEIRO@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003597  ANA PAULA GASPAR SARRASSINI - ME             DELFIM MOREIRA                     293   CENTRO                          37860000 - NOVA RESENDE - MG
Fantasia:   ANA PAULA GASPAR SARRASSINI -                   CNPJ/CPF:   07.107.066/0001-24      Rep: 21.564     Insc Estad:   4513325750044        Telefone:    (35)3562-1617            E-mail:
E-mail NF-e:     marquinhocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003652  ANDREIA LUCIA FERNANDES - ME               CORONEL JAIME GOMES               47    CENTRO                          37860000 - NOVA RESENDE - MG
Fantasia:    ANDREIA LUCIA FERNANDES - ME                    CNPJ/CPF:   97.532.827/0001-88      Rep: 21.564     Insc Estad:   0018031920036        Telefone:    (35)3562-2191            E-mail:
E-mail NF-e:     deinha_fer@ig.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     11/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016058  VALDENES APARECIDO GOMES                 RUA DELFIM MOREIRA                 43    CENTRO                          37860000 - NOVA RESENDE - MG
Fantasia:    DRIDENIS CALÇADOS                              CNPJ/CPF:   18.927.643/0001-40      Rep: 21.564     Insc Estad:   0022281660036        Telefone:    (35)92060-0486           E-mail:
E-mail NF-e:    VALDENIS-98@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010084  CELEBRAR AS MELHORES MARCAS EIRELI          TRAVESSA TREZE DE MAIO             86    CENTRO                          35520124 - NOVA SERRANA - MG
Fantasia:    CELEBRAR CALCADOS                              CNPJ/CPF:   28.127.138/0001-75      Rep: 21.564     Insc Estad:   0029995480093        Telefone:    (37)3226-2475            E-mail:
E-mail NF-e:    CELEBRARNOVASERRANA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010395  MARIA APARECIDA MENDES FONTES 02986791670   Rua da Saudade                      145   Centro                            35520287 - NOVA SERRANA - MG
Fantasia:   SUPER NOVA CALCADOS                            CNPJ/CPF:   33.797.140/0001-91      Rep: 21.564     Insc Estad:   0034594150039        Telefone:    (37)91258-8241           E-mail:
E-mail NF-e:     angelicafontes88@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007270  ORIGINAL FIT COMERCIO LTDA                 RUA PARA DE MINAS                  950   BELA VISTA                       35519000 - NOVA SERRANA - MG
Fantasia:    ORIGINAL FIT COMERCIO LTDA                      CNPJ/CPF:   66.306.200/0002-66      Rep: 21.564     Insc Estad:   4527646220183        Telefone:    (37)3226-2226            E-mail:
E-mail NF-e:     pfc_ns@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017155  SBX 23 CALCADOS BOLSAS E CONFECCOES LTDA    RUA VEREADOR JESUS MARTINS         27    CENTRO                          35520084 - NOVA SERRANA - MG
Fantasia:   COURO BOLSAS                                   CNPJ/CPF:   45.750.425/0001-56      Rep: 21.564     Insc Estad:   0042999470088        Telefone:    (31)91434-4629           E-mail:
E-mail NF-e:    FINANCEIROSBX@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     21/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

016434   RITA DE CÁSSIA RIBEIRO DE ALMEIDA           RUA CAROLINA MACHADO              273   CENTRO                          34990000 - NOVA UNIÃO - MG
Fantasia:   CONTAINER                                       CNPJ/CPF:   40.386.284/0001-10      Rep: 22.500     Insc Estad:   0039399970000        Telefone:    (31)83297-7890           E-mail:
E-mail NF-e:     ritaribeiro085@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020951  EDILENE GOMES ANTUNES BATISTA               Rua David Mussi                      81     Centro                            39820000 - NOVO CRUZEIRO - MG
Fantasia:    DILA CALCADOS                                   CNPJ/CPF:   31.143.102/0001-90      Rep: 22.941     Insc Estad:   32489970062           Telefone:    (33) 99939-5927          E-mail:
E-mail NF-e:     dilacalcadosofc@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

020434  JAILSON ALVES BATISTA                       Rua joaquim maravilha                77     Centro                            39820000 - NOVO CRUZEIRO - MG
Fantasia:   MARCELLA CALCADOS                              CNPJ/CPF:   42.333.061/0001-10      Rep: 22.941     Insc Estad:   004.070.453/0023      Telefone:    (33) 98832-8445          E-mail:
E-mail NF-e:     jasson-128@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021885  FERREIRA E SILVA SAPATARIA                 RUA VITOLDO J KRASNOVOLSKI         370    centro                            39817000 - NOVO ORIENTE DE MINAS - MG
Fantasia:    FERREIRA                                         CNPJ/CPF:   17.150.706/0001-32      Rep: 22.941     Insc Estad:   20569670012           Telefone:    (33) 98857-1818          E-mail:
E-mail NF-e:     butiquedalusapataria@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 52

Pág. 52 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003225  PAULO QUINTILIANO RODRIGUES DE ANDRADE - EPP TANCREDO NEVES                    40    CENTRO                          39817000 - NOVO ORIENTE DE MINAS - MG
Fantasia:   PAULO QUINTILIANO RODRIGUES DE                 CNPJ/CPF:   70.989.207/0001-16      Rep: 22.941     Insc Estad:   8188313180036        Telefone:    (33)3532-8028            E-mail:
E-mail NF-e:     casa-andrade@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007379   JK CALCADOS LTDA                          AV MARACANA                      37    CENTRO                          35540000 - OLIVEIRA - MG
Fantasia:    JK CALCADOS LTDA                                CNPJ/CPF:   20.037.952/0001-97      Rep: 21.564     Insc Estad:   0023392320099        Telefone:    (31)331-6-6265           E-mail:
E-mail NF-e:     stiloscalcadosestoque@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007194  RODOSNACK OLIVEIRA LANCHONETE E RESTAURANTE RODOVIA BR 381                  SN    PERIMETRO DE EX                  35540000 - OLIVEIRA - MG
Fantasia:   RODOSNACK OLIVEIRA LANCHONETE                 CNPJ/CPF:   09.381.903/0001-34      Rep: 21.564     Insc Estad:   0010618690034        Telefone:    (37)3332-9110            E-mail:
E-mail NF-e:     adrianaines9@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019190  EDNESIA GERALDA ALBERGARIA ROCHA             Praca Dimas Martins Viana              103   Centro                            36828000 - ORIZÂNIA - MG
Fantasia:   BAZAR JOICE                                      CNPJ/CPF:   06.111.469/0001-84      Rep: 13.734     Insc Estad:   8222796330081        Telefone:    (32) 98401-0267          E-mail:
E-mail NF-e:     joycemodasorizania@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007592  ANTONIO CARLOS DIAS                      RUA TREZE DE MAIO                  578   CENTRO                          37570000 - OURO FINO - MG
Fantasia:   ANTONIO CARLOS DIAS                             CNPJ/CPF:   09.504.870/0001-72      Rep: 21.564     Insc Estad:   0010683110098        Telefone:    (35)3441-1500            E-mail:
E-mail NF-e:     financeirotoqueto@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009306  NELSON PEDROSO FILHO - CPF 324 181 756 - 34 - EP RUA TREZE DE MAIO                  946   CENTRO                          37570000 - OURO FINO - MG
Fantasia:   NELSON PEDROSO FILHO - CPF 324                  CNPJ/CPF:   86.461.985/0001-78      Rep: 21.564     Insc Estad:   4608805110041        Telefone:    (35)3441-2421            E-mail:
E-mail NF-e:     npcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007026  REAL COMERCIO DE CALCADOS LTDA - MTZ        AV VISCONDE DE IBITURUNA           240   CENTRO                          35400000 - OURO PRETO - MG
Fantasia:    REAL COMERCIO DE CALCADOS LTDA                 CNPJ/CPF:   09.410.300/0001-13      Rep: 22.619     Insc Estad:   001.063.305/0067      Telefone:    (31)3222-4700            E-mail:
E-mail NF-e:     financeiro@pedemulher.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018012  COTINHA MODAS LTDA                       RUA MANOEL MODESTO                17    CENTRO                          39818000 - PADRE PARAÍSO - MG
Fantasia:   COTINHA MODAS                                  CNPJ/CPF:   15.466.981/0001-34      Rep: 22.941     Insc Estad:   0019553980023        Telefone:    (33)84369-9918           E-mail:
E-mail NF-e:    GILSONGONCALVEST12@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010656  EUZER RODRIGUES DA SILVA 73208744668        RUA PREISDENTE BERNARDES          16    CENTRO                          39818000 - PADRE PARAÍSO - MG
Fantasia:   EUZER RODRIGUES DA SILVA 73208                  CNPJ/CPF:   27.605.936/0001-00      Rep: 22.941     Insc Estad:   0029554920024        Telefone:    (33)84016-6914           E-mail:
E-mail NF-e:     euzerloja@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016296  CONFECÇÕES SABRINA INDÚSTRIA COM E REPRESEN RUA CAMILO MENDONÇA               573   CENTRO                          35622000 - PAINEIRAS - MG
Fantasia:   SHOPPING DOS CALÇADOS                          CNPJ/CPF:   65.226.300/0001-39      Rep: 21.564     Insc Estad:   4647542230059        Telefone:    (37)88051-1841           E-mail:
E-mail NF-e:    VANIA1841@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010716  NELSON CALCADOS PAINEIRAS LTDA            RUA DEPUTADO EDUARDO LUCAS        758   CENTRO                          35622000 - PAINEIRAS - MG
Fantasia:   NELSON CALCADOS                                CNPJ/CPF:   08.342.022/0001-41      Rep: 21.564     Insc Estad:   0010272440027        Telefone:    (37)88151-1560           E-mail:
E-mail NF-e:     limacalcados.1931@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021254  ALESSANDER ARLEY DE ABREU ME                Rua Pedro Vieira                      50     Centro                            35669000 - PAPAGAIOS - MG
Fantasia:   XANDY CALCADOS                                 CNPJ/CPF:   00.894.191/0001-82      Rep: 13.734     Insc Estad:   4699507080021        Telefone:    (37) 3274-1744           E-mail:
E-mail NF-e:     xandycalcadosmg@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012452  JULIANA APARECIDA DE CAMPOS 06591022694     RUA GABRIEL DE OLIVEIRA             87    CENTRO                          35669000 - PAPAGAIOS - MG
Fantasia:    JULIANA                                          CNPJ/CPF:   19.781.027/0001-97      Rep: 13.734     Insc Estad:   0023157810030        Telefone:    (37)9976-1084            E-mail:
E-mail NF-e:    BIOLOGAJUJU@YAHOO.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 53

Pág. 53 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

007050  LU CALCADOS LTDA                           PCA PADRE JOSÉ PEREIRA COELHO       14    CENTRO                          35660015 - PARÁ DE MINAS - MG
Fantasia:    LU CALCADOS                                     CNPJ/CPF:   07.887.287/0001-62      Rep: 21.564     Insc Estad:   0010025670050        Telefone:    (37)3236-0476            E-mail:
E-mail NF-e:    LUCIANASILVEIRA02@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021776  MAF CALCADOS E CONFECCOES LTDA            R BENEDITO VALADARES               324   Centro                            35660630 - PARÁ DE MINAS - MG
Fantasia:   IMPACTO MODAS                                  CNPJ/CPF:   52.015.850/0001-67      Rep: 21.564     Insc Estad:   0047037180033        Telefone:    (37) 9994-1383           E-mail:
E-mail NF-e:    impactomodaspm@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005854  PE NA TERRA CALCADOS LTDA - EPP             RUA SCO JOSÉ                       380   CENTRO                          35660014 - PARÁ DE MINAS - MG
Fantasia:    PE NA TERRA CALCADOS LTDA - EP                   CNPJ/CPF:   86.490.109/0001-70      Rep: 21.564     Insc Estad:   4718877970096        Telefone:    (37)3236-0525            E-mail:
E-mail NF-e:     penaterracalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003984  SALTO CHIK CALCADOS LTDA                  RUA MONTES CLAROS                 23    SANTOS DUMONT                   35660332 - PARÁ DE MINAS - MG
Fantasia:   SALTO CHIK CALCADOS LTDA                       CNPJ/CPF:   01.627.426/0001-32      Rep: 21.564     Insc Estad:   4713383360012        Telefone:    (37)3236-7171            E-mail:
E-mail NF-e:     soniaapamaro@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

001163  WMD CALCADOS E CONFECCOES LTDA - ME        BENEDITO VALADARES                324   CENTRO                          35660630 - PARÁ DE MINAS - MG
Fantasia:   WMD CALCADOS E CONFECCOES LTDA                CNPJ/CPF:   11.422.598/0001-23      Rep: 21.564     Insc Estad:   0015245000059        Telefone:    (37)3232-0030            E-mail:
E-mail NF-e:     impactomodas10@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011140  EZIO CARLOS DA SILVA                       AV DEPUTADO QUINTINO VARGAS       332   CENTRO                          38600000 - PARACATU - MG
Fantasia:    VIA CHINELOS                                     CNPJ/CPF:   30.296.670/0001-68      Rep: 22.941     Insc Estad:   0031795750030        Telefone:    (38)9974-72573           E-mail:
E-mail NF-e:    VIACALCADOSPTU@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018830  NELSON NETO SIQUEIRA 47776544604              Av. Olegario Maciel                    727   Centro                            38600210 - PARACATU - MG
Fantasia:    Pé LEVE                                          CNPJ/CPF:   43.012.471/0001-22      Rep: 22.941     Insc Estad:   004.113.249/0030      Telefone:    (38) 99998-7668          E-mail:
E-mail NF-e:     maniaparacatu@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009572  OUSADIA SHOP LTDA - EPP                    AV DEPUTADO QUINTINO VARGAS       426   CENTRO                          38600000 - PARACATU - MG
Fantasia:   OUSADIA SHOP LTDA - EPP                          CNPJ/CPF:   04.988.742/0001-28      Rep: 22.941     Insc Estad:   4701707160062        Telefone:    (38)3671-3166            E-mail:
E-mail NF-e:     ousadiashopmg@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021205  VALMIRA MARTINS SILVA                       Av Deputado Quintino Vargas           210   Centro                            38600212 - PARACATU - MG
Fantasia:    CHINELOS E CIA                                   CNPJ/CPF:   45.777.341/0001-06      Rep: 22.941     Insc Estad:   004.301.863/0033      Telefone:    (38) 99751-6177          E-mail:
E-mail NF-e:     chinelociaptu@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

001286  COURAMA MODAS LTDA                         PREFEITO NESTOR EUSTAQUIO          120   CENTRO                          37120000 - PARAGUAÇU - MG
Fantasia:   COURAMA MODAS LTDA                            CNPJ/CPF:   00.461.808/0001-76      Rep: 21.564     Insc Estad:   4729202110090        Telefone:    (35)3267-1837            E-mail:
E-mail NF-e:    contato@couramamodas.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

016508  VEIGA E MACIEL LTDA                        AV GETULIO VARGAS                  15    CENTRO                          35774000 - PARAOPEBA - MG
Fantasia:    LOJA MACIEL                                      CNPJ/CPF:   19.964.634/0001-92      Rep: 22.941     Insc Estad:   4744372080090        Telefone:    (31)3714-1335            E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     31/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019131  JOSE LUIZ COURBASSIER LTDA                  Rua Tenente Viotti                    414   Centro                            37460000 - PASSA QUATRO - MG
Fantasia:   PACO CALCADOS                                  CNPJ/CPF:   18.175.422/0001-63      Rep: 21.564     Insc Estad:   4761940250087        Telefone:    (35) 3371-2280           E-mail:
E-mail NF-e:     pacop464@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005442  MISTER GOMES CALCADOS LIMITADA - LJ 119      GERALDO DA SILVA MAIA              27    CENTRO                          37900096 - PASSOS - MG
Fantasia:    MISTER GOMES CALCADOS LIMITADA                 CNPJ/CPF:   09.644.100/0001-25      Rep: 21.564     Insc Estad:   0010753960010        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 54

Pág. 54 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

005441  PASSOS CALCADOS LIMITADA  - LJ 102            EXPEDICIONARIOS                   170   CENTRO                          37900130 - PASSOS - MG
Fantasia:   PASSOS CALCADOS LIMITADA  - LJ                   CNPJ/CPF:   07.595.521/0001-88      Rep: 21.564     Insc Estad:   4793893840016        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003932  CALCADOS CABRINE LTDA                    RUA PADRE CALDEIRA                 328   CENTRO                          38700044 - PATOS DE MINAS - MG
Fantasia:   CALCADOS CABRINE LTDA                          CNPJ/CPF:   05.852.296/0001-92      Rep: 21.496     Insc Estad:   4802491530079        Telefone:    (34)3821-2561            E-mail:
E-mail NF-e:     vicente_cabrine@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021851  COMERCIAL DE CALCADOS NETOS E ROCHA LTDA    Rua padre caldeira                    190   Centro                            38700044 - PATOS DE MINAS - MG
Fantasia:   PRO PE                                           CNPJ/CPF:   34.944.622/0001-90      Rep: 21.496     Insc Estad:   0035504500087        Telefone:    (34) 3822-1964           E-mail:
E-mail NF-e:     comercialnetosrocha@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021847  COMERCIAL DELOR LTDA                       Rua dos caetes                       859    Alvorada                          38701394 - PATOS DE MINAS - MG
Fantasia:   PROPE CALCADOS                                  CNPJ/CPF:   01.649.208/0001-07      Rep: 21.496     Insc Estad:   480.334.772/0002      Telefone:    (34) 3822-1964           E-mail:
E-mail NF-e:     propecalcadosmg@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021902  GLEIMAR MODAS LTDA                         Av brasil                            1418  Centro                            38700188 - PATOS DE MINAS - MG
Fantasia:    GLEIMAR MODAS                                  CNPJ/CPF:   30.214.830/0001-82      Rep: 21.496     Insc Estad:   0031734620005        Telefone:    (34) 99975-7423          E-mail:
E-mail NF-e:     gleimar.modas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005650  COMERCIAL NUNES E COSTA LTDA              RUA CORONEL JOÃO CANDIDO DE AGUIAR 281   CENTRO                          38740001 - PATROCINIO - MG
Fantasia:   COMERCIAL NUNES E COSTA LTDA                   CNPJ/CPF:   11.524.081/0001-45      Rep: 21.496     Insc Estad:   0015472780012        Telefone:    (34)3832-0003            E-mail:
E-mail NF-e:     paulofernandoptc@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021623  COMERCIO DE CALCADOS GONCALVES            Av RUI BARBOSA                     193   Centro                            38740036 - PATROCINIO - MG
Fantasia:   RRAGUIOS                                        CNPJ/CPF:   46.436.617/0001-55      Rep: 21.496     Insc Estad:   004.344.382/0034      Telefone:    (34) 98895-8434          E-mail:
E-mail NF-e:     nalvaraguios@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010965  VANDA LUCIA MARTINS GOMES 02422435688      RUA SILVESTRE MOREIRA              2465  SANTA TEREZINHA                  38740000 - PATROCINIO - MG
Fantasia:   VANDA LUCIA MARTINS GOMES 0242                 CNPJ/CPF:   16.946.520/0001-21      Rep: 21.496     Insc Estad:   0020376280034        Telefone:    (34)3874-2058            E-mail:
E-mail NF-e:     vandinha-ptc@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022315  NUNES & QUEIROZ LTDA                       PC DR ANTONIO DA C PEREIRA          240   CENTRO                          39700000 - PEÇANHA - MG
Fantasia:    L & M CALCADOS E ROUPAS                         CNPJ/CPF:   22.289.698/0001-40      Rep: 22.751     Insc Estad:   4865371140047        Telefone:    (33) 99800-5287          E-mail:
E-mail NF-e:     lmcalcadoseroupas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018018  RAIMUNDO QUEIROZ CIA LTDA                  PRACA ANTÔNIO CUNHA               150   CENTRO                          39700000 - PEÇANHA - MG
Fantasia:   A PREDILETA                                      CNPJ/CPF:   18.086.389/0001-03      Rep: 22.751     Insc Estad:   4861529930051        Telefone:    (33)3411-1328            E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     26/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011860   KEILA DE SOUZA SILVA                      RUA SÃO JOÃO                    SN   CENTRO                          36847000 - PEDRA DOURADA - MG
Fantasia:    KEILA DE SOUZA SILVA                             CNPJ/CPF:   08.515.474/0001-88      Rep: 13.734     Insc Estad:   0010288170040        Telefone:    (32)3751-1563            E-mail:
E-mail NF-e:    KEILAMODAS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     15/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006524   CIBELE APARECIDA FERNANDES SILVA           RUA COMENDADOR ANTONIO ALVES 1081 SN   CENTRO                          33600000 - PEDRO LEOPOLDO - MG
Fantasia:    CIBELE APARECIDA FERNANDES SIL                  CNPJ/CPF:   71.379.341/0001-68      Rep: 22.500     Insc Estad:   4938611390086        Telefone:    (31)3662-1110            E-mail:
E-mail NF-e:     cjcalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006480   JUNIELLE MERCANTIL LTDA ME                  HEITOR CLAUDIO DE SALES 562 - LETRA ASN    FELIPE CLAUDIO SALES              33600000 - PEDRO LEOPOLDO - MG
Fantasia:    JUNIELLE MERCANTIL LTDA ME                      CNPJ/CPF:   03.402.653/0001-95      Rep: 22.500     Insc Estad:   4930433440050        Telefone:    (31)3662-2804            E-mail:
E-mail NF-e:     juniellemercantil@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 55

Pág. 55 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017238  PODIUM SAPATARIA LTDA                     RUA HERBSTER                      320   CENTRO                          33600000 - PEDRO LEOPOLDO - MG
Fantasia:   PODIUM SAPATARIA                                CNPJ/CPF:   24.123.334/0001-10      Rep: 22.500     Insc Estad:   0027005620003        Telefone:    (31)98313-3289           E-mail:
E-mail NF-e:    AKERLEYSANTOS@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     05/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004265  WIVAN CALCADOS LTDA - FL01                 RUA COMENDADOR ANTONIO ALVES 786 - SN   CENTRO                          33600000 - PEDRO LEOPOLDO - MG
Fantasia:   WIVAN CALCADOS LTDA - FL01                      CNPJ/CPF:   64.271.950/0002-14      Rep: 22.500     Insc Estad:   4936443870150        Telefone:    (31)3661-1554            E-mail:
E-mail NF-e:     wivancalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

020124  LUANA DE CARVALHO SILVA                     Rua Governador Valadares              314   Centro                            37260000 - PERDÕES - MG
Fantasia:    ELLAS CALCADOS                                  CNPJ/CPF:   30.774.232/0001-68      Rep: 21.564     Insc Estad:   0032185300016        Telefone:    (35) 99769-1845          E-mail:
E-mail NF-e:     ellascacadoseaacessorios2021@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012578  NARA CONFECCOES LTDA                      AVENIDA DOUTOR REGIS BITENCOURT   91    CENTRO                          37260000 - PERDÕES - MG
Fantasia:   NARA CONFECCOES                                CNPJ/CPF:   22.652.119/0001-81      Rep: 21.564     Insc Estad:   4995744530056        Telefone:    (35)3864-1188            E-mail:
E-mail NF-e:    NARACONFECCOES@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     17/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004382  MARIA SUELI DAS DORES ALMEIDA SILVA         RUA NOSSO SENHOR DO BONFIM 326 -  SN   CENTRO                          35526000 - PIEDADE DOS GERAIS - MG
Fantasia:    SUELI MODAS LTDA                                CNPJ/CPF:   01.430.877/0001-85      Rep: 22.500     Insc Estad:   5049851960060        Telefone:    (31)98315-3724           E-mail:
E-mail NF-e:     mariasuelialmeida@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     09/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009612  ARISLENE FERREIRA DE SOUZA                  PC MARIA JORGE MIZIARA              160   CENTRO                          38210000 - PIRAJUBA - MG
Fantasia:   CALCADOS & CIA.                                  CNPJ/CPF:   07.474.744/0001-97      Rep: 21.496     Insc Estad:   5073556930010        Telefone:    (34)3322-0826            E-mail:
E-mail NF-e:     setacalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015425  SPASSO CALCADOS DE PIRAPETINGA LTDA         AVENIDA GOV.BEN.VALADARES        SN   CENTRO                          36730000 - PIRAPETINGA - MG
Fantasia:   SPASSO CALÇADOS LTDA                           CNPJ/CPF:   04.514.079/0001-20      Rep: 22.739     Insc Estad:   5111333130095        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     bsbeltrao@oulook.com;escritoriospasso@gmail.com;escritoriospass

     Obs.:                                                           Proprietário :

Data Última Compra:     13/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018954  CALCADOS TAVARES E XAVIER                   Rua cel quintino vargas                25     Centro                            39270000 - PIRAPORA - MG
Fantasia:    SKALA SPORT                                     CNPJ/CPF:   08.681.945/0001-28      Rep: 22.941     Insc Estad:   001.029.181/0047      Telefone:    (38) 3741-3048           E-mail:
E-mail NF-e:    skspmg@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018959  COMERCIAL DE CALCADOS PIRAPORA LTDA         Av Rodolfo malard                    98     Centro                            39270074 - PIRAPORA - MG
Fantasia:    RABELLO CALCADOS                               CNPJ/CPF:   48.942.108/0001-20      Rep: 22.941     Insc Estad:   004.507.171/0030      Telefone:    (38) 3741-7178           E-mail:
E-mail NF-e:     rabellopirapora@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005230   LF CALCADOS E ACESSORIOS LTDA                PIO XII                             925   SANTOS DUMONT                   39270000 - PIRAPORA - MG
Fantasia:   ESPACO DO PE                                    CNPJ/CPF:   23.083.420/0001-84      Rep: 22.941     Insc Estad:   0026117880090        Telefone:    (38)3741-1475            E-mail:
E-mail NF-e:    ESPACODOPEOFICIAL@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     09/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016314  SKALA MODAS PIRAPORA LTDA                 RUA DA BAHIA                       514   CENTRO                          39270088 - PIRAPORA - MG
Fantasia:    SKALA MODAS                                     CNPJ/CPF:   04.537.712/0001-03      Rep: 22.941     Insc Estad:   5121328610076        Telefone:    (38)3741-1706            E-mail:
E-mail NF-e:    SKMPMG@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     26/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

010881  GERALDO FERREIRA DO VALE                  RUA LACERDINO ROCHA               105   CENTRO                          35650000 - PITANGUI - MG
Fantasia:   GERALDO FERREIRA DO VALE                        CNPJ/CPF:   14.994.722/0001-13      Rep: 21.564     Insc Estad:   0019101030000        Telefone:    (37)3271-5761            E-mail:
E-mail NF-e:     calcadosduvalle@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017939   LIVIA VIEGAS NAZAR                          PCA DA CÂMARA                     34    CENTRO                          35650000 - PITANGUI - MG
Fantasia:    LIVIA MULTIPLACE                                 CNPJ/CPF:   08.641.322/0001-21      Rep: 21.564     Insc Estad:   0010291290035        Telefone:    (37)99458-8735           E-mail:
E-mail NF-e:    MULTIPLACE.LIVIA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 56

Pág. 56 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020973  CALCADOS PIUMHI LTDA                       Rua Bossuet Costa                    145   Centro                            37925000 - PIUMHI - MG
Fantasia:    VILA CALCADOS - KATUXA                          CNPJ/CPF:   52.149.078/0001-76      Rep: 21.564     Insc Estad:   47124020034           Telefone:    (37) 3027-1498           E-mail:
E-mail NF-e:    compras2g2v@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008183  DAYSE DE CASTRO PEREIRA                   RUA SANTO ANTONIO                 193   CENTRO                          37925000 - PIUMHI - MG
Fantasia:   DAYSE DE CASTRO PEREIRA                         CNPJ/CPF:   01.681.473/0001-64      Rep: 21.495     Insc Estad:   5153364300024        Telefone:    (37)3371-3360            E-mail:
E-mail NF-e:     republica.moda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/11/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005987  NERCI FERREIRA CPF 623 317 446-53 - EPP        PRACA SCO FRANCISCO               374   CENTRO                          37757000 - POÇO FUNDO - MG
Fantasia:    NERCI FERREIRA CPF 623 317 446                   CNPJ/CPF:   64.223.415/0001-07      Rep: 21.564     Insc Estad:   5176380130092        Telefone:    (35)3283-1052            E-mail:
E-mail NF-e:     nerci.f@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008205  ARMINDO PACHECO DE SOUSA , LOJA DE CALÇADOS RUA JUNQUEIRAS 500 LOJA 05 E       500   CENTRO                          37701033 - POÇOS DE CALDAS - MG
Fantasia:   ARMINDO PACHECO DE SOUSA CPF 6                 CNPJ/CPF:   10.516.699/0002-81      Rep: 21.564     Insc Estad:   0023969420113        Telefone:    (35)3712-2161            E-mail:
E-mail NF-e:     gerencialevince2@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021501  CWNETO REPRESENTACOES                   RUA EDUARDO CAVINI                 35    JARDIM IPÊ                        37704207 - POÇOS DE CALDAS - MG
Fantasia:   WALTER CASTRO                                  CNPJ/CPF:   65.362.477/0001-62      Rep: 21.564     Insc Estad:                            Telefone:    (55)5555-555             E-mail:
E-mail NF-e:     cwnetto@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006228   J LONGO E CIA LTDA EPP                        ASSIS FIGUEIREDO                   893   CENTRO                          37701000 - POÇOS DE CALDAS - MG
Fantasia:     J LONGO E CIA LTDA EPP                           CNPJ/CPF:   19.368.281/0001-68      Rep: 21.564     Insc Estad:   5182264150038        Telefone:    (35)3729-1636            E-mail:
E-mail NF-e:     pedidos@principecalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     29/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002851   LILIAM GORETTI SILVA - ME                   PERNAMBUCO                        734   CENTRO                          37701021 - POÇOS DE CALDAS - MG
Fantasia:    LILIAM GORETTI SILVA - ME                         CNPJ/CPF:   04.852.832/0001-97      Rep: 21.564     Insc Estad:   0016016700029        Telefone:    (35)3722-2355            E-mail:
E-mail NF-e:     liliamgoretti@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006227  SEN CENSURA MAGAZINE LTDA                 AV EDUARDO LUCIANO MARRAS        110   CONJ HAB P A JUNQUEI              37706215 - POÇOS DE CALDAS - MG
Fantasia:   FRANCISCO LOPES RODRIGUES ME                   CNPJ/CPF:   41.825.506/0001-17      Rep: 21.564     Insc Estad:   5187942160070        Telefone:    (35)3712-4014            E-mail:
E-mail NF-e:     censura.cal.@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

020649  ANTONIA INES DE LIMA SOUSA 529             RUA PRESIDENTE ANTONIO CARLOS      70    TREVO                           35640000 - POMPÉU - MG
Fantasia:    PE E CIA                                          CNPJ/CPF:   02.226.943/0001-62      Rep: 21.564     Insc Estad:   4527253190017        Telefone:    (37) 3523-3507           E-mail:
E-mail NF-e:     sousaines654@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003849  DENISE CRISTINA DE JESUS CAMPOS            RUA DONA JOAQUINA                 250   CENTRO                          35640000 - POMPÉU - MG
Fantasia:    DENISE CRISTINA DE JESUS CAMPO                  CNPJ/CPF:   02.874.178/0001-97      Rep: 21.564     Insc Estad:   5209952800064        Telefone:    (37)3523-1331            E-mail:
E-mail NF-e:     denise@netpeu.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     13/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021058   ELVIS FRANCE DA SILVA 08486378605            Rua Dona Joaquim                    165   Centro                            35640000 - POMPÉU - MG
Fantasia:   PODEROSA CALCADOS                              CNPJ/CPF:   32.788.506/0001-01      Rep: 21.564     Insc Estad:   003.380.945/0030      Telefone:    (37) 99938-0954          E-mail:
E-mail NF-e:    poderosapompeu@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019885  KENIA APARECIDA SILVA FERREIRA               Rua Messião Jaccob                   447   Centro                            35640000 - POMPÉU - MG
Fantasia:    FLOR DE LIZ                                      CNPJ/CPF:   24.168.289/0001-10      Rep: 21.564     Insc Estad:   002.704.171/0068      Telefone:    (37) 99965-0038          E-mail:
E-mail NF-e:     keniaap89@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019811  MARIA ILIDIA DE CAMPOS VALADARES DUARTE     Rua Dona Joaquim                    169   Centro                            35640000 - POMPÉU - MG
Fantasia:   MARIA ILIDIA CALçADOS                            CNPJ/CPF:   71.025.845/0001-80      Rep: 21.564     Insc Estad:   520.378.824/0086      Telefone:    (37) 99989-1300          E-mail:
E-mail NF-e:     centro.calcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 57

Pág. 57 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021530  ANA CAROLINA DE ANDRADE                    Rua santo antonio                    23 loja Palmeiras                         35430054 - PONTE NOVA - MG
Fantasia:   CAROL CALCADOS                                 CNPJ/CPF:   43.959.890/0001-76      Rep: 22.619     Insc Estad:   0041786870061        Telefone:    (31) 99872-7720          E-mail:
E-mail NF-e:     carolcalcados2018@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019476  DESTAK CALCADOS LTDA ME                    Rua Santo Antonio                    237   Santo Antonio                      35430190 - PONTE NOVA - MG
Fantasia:   DESTAK CALCADOS                                CNPJ/CPF:   27.653.547/0001-42      Rep: 22.619     Insc Estad:   0029593930086        Telefone:    (31) 98855-0054          E-mail:
E-mail NF-e:     marcoseangelica2009@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007338  PAULO SERGIO RODRIGUES FIALHO              AV DR JOSÉ MARIANO                115   PALMEIRAS                        35430228 - PONTE NOVA - MG
Fantasia:    CALCIVET                                         CNPJ/CPF:   00.057.347/0001-70      Rep: 22.619     Insc Estad:   5218818720069        Telefone:    (31)3817-3070            E-mail:
E-mail NF-e:    CALCIVESTPONTENOVA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     17/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021529  PEGADAS CALCADOS                           Av dr jose mariano 52                 52     Palmeiras                         35430228 - PONTE NOVA - MG
Fantasia:   PEGADAS CALCADOS                               CNPJ/CPF:   42.848.440/0001-43      Rep: 22.619     Insc Estad:   5218074220012        Telefone:    (31) 98973-4502          E-mail:
E-mail NF-e:     pegadascalcados55@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005231   LJ RODRIGUES COM DE CALC LTDA               BENJAMIN CONSTANT                 185   CENTRO                          39520000 - PORTEIRINHA - MG
Fantasia:   FOCCO CALCADOS                                 CNPJ/CPF:   07.107.263/0001-43      Rep: 22.941     Insc Estad:   5223371720007        Telefone:    (38)92361-1554           E-mail:
E-mail NF-e:    LILIANTIEGO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018562  PORTAL MAGAZINE LTDA                       Rua Benjamin Constant                289   Centro                            39520000 - PORTEIRINHA - MG
Fantasia:    PORTAL MAGAZINE                                 CNPJ/CPF:   49.146.652/0001-28      Rep: 22.941     Insc Estad:   452.032.900/08        Telefone:    (38) 3831-1522           E-mail:
E-mail NF-e:     portalmagazine@gammix.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021650  CAMPOS CONFECCOES E VESTUARIOS LTDA         Pc jose maciel 37                     37     Centro                            36576000 - PORTO FIRME - MG
Fantasia:    LOJA DA ROSI                                     CNPJ/CPF:   02.833.463/0001-60      Rep: 22.619     Insc Estad:   5231489700059        Telefone:    (31) 99894-3917          E-mail:
E-mail NF-e:     rosilenefcsobreira@hotmail.co

     Obs.:                                                           Proprietário :

Data Última Compra:     04/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003791  CARLOS ALBERTO FREIRE - ME                 RUA TORQUATO FERREIRA             90    CENTRO                          39827000 - POTÉ - MG
Fantasia:   CARLOS ALBERTO FREIRE - ME                      CNPJ/CPF:   86.651.726/0001-00      Rep: 22.036     Insc Estad:   524.906.309/0075      Telefone:    (33)3225-1380            E-mail:
E-mail NF-e:     albertolojas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017976  HELIADE SOUSA SANTOS SILVA                RUA VICENTE GONCALVES             169   CENTRO                          39827000 - POTÉ - MG
Fantasia:   MANU CALCADOS                                  CNPJ/CPF:   26.854.972/0001-37      Rep: 22.036     Insc Estad:   0028922100044        Telefone:    (33)88489-9261           E-mail:
E-mail NF-e:    HELIDESOUSASANTOS2020@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     04/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021640  ARTMANHALTDA                            RUA SILVIANO BRANDA                272   Centro                            37550000 - POUSO ALEGRE - MG
Fantasia:   ARTMANHA                                        CNPJ/CPF:   38.584.470/0001-12      Rep: 21.564     Insc Estad:   5256871780001        Telefone:    (35) 3422-8939           E-mail:
E-mail NF-e:     artmanhapa@uol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     30/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008905  BOSCHI CALCADOS EIRELI - EPP                AV DOUTOR LISBOA                  67    CENTRO                          37550000 - POUSO ALEGRE - MG
Fantasia:   BOSCHI CALCADOS EIRELI - EPP                     CNPJ/CPF:   27.932.464/0001-92      Rep: 21.564     Insc Estad:   0029828350092        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018005  CALCADOS BOM PASSO LTDA                   AV PREF OLAVO GOMES DE OLIVEIRA     1807  JARDIM OLÍMPICO                  37558420 - POUSO ALEGRE - MG
Fantasia:   BOM PASSO CALCADOS                             CNPJ/CPF:   31.614.254/0001-23      Rep: 21.564     Insc Estad:   0032845400098        Telefone:    (35)3022-8390            E-mail:
E-mail NF-e:    BOMPASSO2017@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008848  CALCADOS D PAULA EIRELI - EPP                RODOVIA BR459                   SN   CENTRO                          37556140 - POUSO ALEGRE - MG
Fantasia:   CALCADOS D PAULA EIRELI - EPP                    CNPJ/CPF:   27.932.455/0001-00      Rep: 21.564     Insc Estad:   0029828320061        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:    NFE@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 58

Pág. 58 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

004766  CALCE E LEVE LTDA - ME                     RUA ADALBERTO FERRAZ              549   CENTRO                          37550000 - POUSO ALEGRE - MG
Fantasia:    CALCE E LEVE LTDA - ME                            CNPJ/CPF:   04.391.129/0001-29      Rep: 21.564     Insc Estad:   5251219430016        Telefone:    (35)3422-0010            E-mail:
E-mail NF-e:     calceleve02@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002238  KEIKO FUJITA CALCADOS LTDA                 AV DOUTOR LISBOA                  44    CENTRO                          37550110 - POUSO ALEGRE - MG
Fantasia:    KEIKO FUJITA CALCADOS LTDA                      CNPJ/CPF:   21.303.255/0001-01      Rep: 19.689     Insc Estad:   0024559270023        Telefone:    (35)3422-9532            E-mail:
E-mail NF-e:     fiscal@tunodacalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021537  JOANA DARC SANTANA PERES                   Rua tenente reis                      714   Centro                            38140000 - PRATA - MG
Fantasia:   DARC MODAASS                                   CNPJ/CPF:   33.558.042/0001-00      Rep: 21.496     Insc Estad:   0034399110066        Telefone:    (34) 99682-7722          E-mail:
E-mail NF-e:     joanaa.santanaa.peres@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018354  MARCIO BOCARDES RODRIGUES                 Rua Anisio Bernardino Alves            32     Centro                            35230000 - RESPLENDOR - MG
Fantasia:   BORçADES CALçADOS                              CNPJ/CPF:   18.033.632/0001-17      Rep: 22.751     Insc Estad:   0021409210065        Telefone:    (33) 99968-8112          E-mail:
E-mail NF-e:     marciobocardes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003359  BARCELOS QUINTELA CONFECCOES LTDA - ME      Rua Jose Maria Alkimim                18    São Pedro                         33805483 - RIBEIRAO DAS NEVES - MG
Fantasia:    LOJA ELDONE                                     CNPJ/CPF:   21.167.499/0001-04      Rep: 22.500     Insc Estad:   5462705140041        Telefone:    (31)624-1-1386           E-mail:
E-mail NF-e:     eldone@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003458  COMERCIO DE CALCADOS BOTAFOGO LTDA - ME    AV GUANABARA                      48    BOTAFOGO JUSTINOPOLIS            33902310 - RIBEIRAO DAS NEVES - MG
Fantasia:    LIPE CALÇADOS                                   CNPJ/CPF:   13.411.124/0001-01      Rep: 22.500     Insc Estad:   0017497420020        Telefone:    (31)3639-2775            E-mail:
E-mail NF-e:    WANDERLEIACOUTOLUCIO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002901  CRIAR CALCADOS EIRELI - EPP                  DENISE CRISTINA ROCHA              452   GUADALAJARA JUSTINOPOLIS         33900001 - RIBEIRAO DAS NEVES - MG
Fantasia:    CRIAR CALCADOS EIRELI - EPP                      CNPJ/CPF:   19.133.133/0002-45      Rep: 22.500     Insc Estad:   0022497600163        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002922  DECKER MODAS LTDA - EPP                     DENISE CRISTINA ROCHA              466   GUADALAJARA JUSTINOPOLIS         33900001 - RIBEIRAO DAS NEVES - MG
Fantasia:   DECKER MODAS LTDA - EPP                         CNPJ/CPF:   24.042.244/0001-03      Rep: 22.500     Insc Estad:   5465962890000        Telefone:    (31)3456-1170            E-mail:
E-mail NF-e:    COMPRAS@DECKERCALCADOS.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020997  MAURILDES F DE SOUZA                        Av denise cristina da rocha             857    Guadalajara(Justinopolis)             33900001 - RIBEIRAO DAS NEVES - MG
Fantasia:   MARY CALCADOS                                  CNPJ/CPF:   26.664.202/0001-21      Rep: 22.500     Insc Estad:   28752170004           Telefone:    (31) 98909-7879          E-mail:
E-mail NF-e:     rannarayka@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011561  PONTO DOS CALCADOS LTDA ME               RUA HELENA SAPORI FALUBA           319   VENEZA                          33933460 - RIBEIRAO DAS NEVES - MG
Fantasia:   PONTO DOS CALCADOS LTDA ME                     CNPJ/CPF:   30.668.050/0001-02      Rep: 22.500     Insc Estad:   0032094880036        Telefone:    (31)3638-7201            E-mail:
E-mail NF-e:    WARLEMALVES4@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     30/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021108  ROBERTO ROCHA JARDIM                       Rua Joao de Gois Sobrinho             47     Centro Justinopolis                  33900800 - RIBEIRAO DAS NEVES - MG
Fantasia:   SONHOS HOT DOG                                 CNPJ/CPF:   31.371.088/0001-81      Rep: 22.500     Insc Estad:   32649620099           Telefone:    (31) 99353-4756          E-mail:
E-mail NF-e:     rrjardim@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/12/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008085  TAINARA CALCADOS LTDA - ME                 RUA TRES                           187   CONJUNTO NOVA PAMPULHA          33937125 - RIBEIRAO DAS NEVES - MG
Fantasia:    TAINARA CALCADOS LTDA - ME                      CNPJ/CPF:   14.219.770/0001-34      Rep: 22.500     Insc Estad:   0018321150098        Telefone:    (31)3355-5918            E-mail:
E-mail NF-e:     tainaracalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014906  VASCONCELOS VAREJISTA DE CALCADOS LTDA     AVENIDA DENISE CRISTINA DA ROCHA   857   GUADALAJARA JUSTINOPOLIS         33933460 - RIBEIRAO DAS NEVES - MG
Fantasia:   VASCONCELOS VAREJISTA                          CNPJ/CPF:   08.272.637/0002-20      Rep: 22.500     Insc Estad:   0010162940181        Telefone:    (31)3447-7062            E-mail:
E-mail NF-e:    LIPECALCADOS@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 59

Pág. 59 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021570  CLAUDIA APARECIDA LOPES CRUZ                Rua dr joao pinheiro 68b               68     Centro                            35370000 - RIO CASCA - MG
Fantasia:    LOJA DA CLAUDIA                                  CNPJ/CPF:   71.452.429/0001-68      Rep: 22.619     Insc Estad:   5498720820010        Telefone:    (31) 97215-2947          E-mail:
E-mail NF-e:     claudia.lopescruz@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021569  CLAUDIO FARACE LOPES ME                     Rua imaculada conceicao 35 c           35     Centro                            35370000 - RIO CASCA - MG
Fantasia:    LOJA DO CLAUDIO                                 CNPJ/CPF:   03.503.201/0001-08      Rep: 22.619     Insc Estad:   5490529020024        Telefone:    (31) 98104-3444          E-mail:
E-mail NF-e:     ctrocha2006@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018669  MARCIA APARECIDA DE SOUZA                 RUA ANTONIO PEDRO DE MELO         280   Centro                            35485000 - RIO MANSO - MG
Fantasia:                                                     CNPJ/CPF:   17.442.148/0001-89      Rep: 22.500     Insc Estad:   0020862330025        Telefone:    (31) 9864-9787           E-mail:
E-mail NF-e:    marciamodas74@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016356  INOVACAO CALCADOS LTDA                   RUA REGINA MENDES SILVEIRA         2     CENTRO                          39530000 - RIO PARDO DE MINAS - MG
Fantasia:   A VISTAO PONTA PE                                CNPJ/CPF:   06.061.452/0001-60      Rep: 22.941     Insc Estad:   6802710760095        Telefone:    (38)99148-1626           E-mail:
E-mail NF-e:    AVISTAOPONTAPERPM@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022189  MARCIA SIMONE FERREIRA DOS SANTIS2          PRAÇA DR MIGUEL                    160   CENTRO                          39530000 - RIO PARDO DE MINAS - MG
Fantasia:   ORLANDO CALçADOS                               CNPJ/CPF:   18.039.596/0001-07      Rep: 22.941     Insc Estad:   21413910017           Telefone:    (38) 99104-2903          E-mail:
E-mail NF-e:     orlandofernandes30@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

002829  COMERCIAL SOUARTE LTDA                   DUQUE DE CAXIAS                    112   CENTRO                          35940000 - RIO PIRACICABA - MG
Fantasia:   COMERCIAL SOUARTE EIRELI - EPP                   CNPJ/CPF:   71.184.121/0001-89      Rep: 22.036     Insc Estad:   5578611710042        Telefone:    (31) 3854-1331           E-mail:
E-mail NF-e:     souarterp@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019576   RITA APARECIDA CALDEIRA COTA                Rua Duque de Caxias                  20     Centro                            35940000 - RIO PIRACICABA - MG
Fantasia:    JULIANA PRESENTE                                CNPJ/CPF:   03.473.070/0001-55      Rep: 22.036     Insc Estad:   5570504240088        Telefone:    (31) 99747-4710          E-mail:
E-mail NF-e:     julianapresenterp@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017387  GISELE M S MIRANDA                       DR JOSE NEVES                      293   CENTRO                          36180000 - RIO POMBA - MG
Fantasia:    GISELA MODA                                     CNPJ/CPF:   46.827.882/0001-64      Rep: 22.619     Insc Estad:   004.368.881/0058      Telefone:   3235712278              E-mail:
E-mail NF-e:     lojadgisele@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020205  GISELE MARTINS SOARES MIRANDA               Av Dr. Jose Neves                    293   Centro                            36180000 - RIO POMBA - MG
Fantasia:    GISELE MODAS                                    CNPJ/CPF:   49.726.330/0001-58      Rep: 22.619     Insc Estad:   45567170033           Telefone:    (32) 3571-2278           E-mail:
E-mail NF-e:     lojadgisele@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019979  MARIA APARECIDA BETTI SILVA                     Praça sao Sebastiao                   83     Centro                            36510000 - RODEIRO - MG
Fantasia:    BIEL MODAS                                      CNPJ/CPF:   05.236.736/0001-87      Rep: 13.734     Insc Estad:   5631909420021        Telefone:    (32) 3531-1680           E-mail:
E-mail NF-e:     carlos.kibacana@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000031  HELO VESTUARIO E CALCADOS LTDA             AV CONTAGEM                       2154  ANA LUCIA                        31567000 - SABARA - MG
Fantasia:   HELO VESTUARIO E CALCADOS LTDA                 CNPJ/CPF:   38.617.361/0001-54      Rep: 22.500     Insc Estad:   567.667.064/0051      Telefone:    (31)3485-2210            E-mail:
E-mail NF-e:     helovestuario@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008518  MONICA SOARES DE ASSUNPCAO SILVA 0767694767 RUA FLORALIA                       40    NOSSA SENHORA DE FATIMA         34600630 - SABARA - MG
Fantasia:   MONICA SOARES DE ASSUNPCAO SIL                 CNPJ/CPF:   16.608.711/0001-83      Rep: 22.500     Insc Estad:   0020045610053        Telefone:    (31)3353-7213            E-mail:
E-mail NF-e:     rm40sabara@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

022283  SAPATARIA OLIVEIRA LTDA                    R JOAO FRANCISCO FERREIRA          9     CENTRO                          34505740 - SABARA - MG
Fantasia:    Pé & CIA                                          CNPJ/CPF:   64.303.977/0001-60      Rep: 22.500     Insc Estad:   5676880610060        Telefone:    (31) 3671-1886           E-mail:
E-mail NF-e:     peeciasabara@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 60

Pág. 60 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

017229  COMERCIAL TML LTDA                       RUA INACIO BARROSO                394   CENTRO                          39750000 - SABINÓPOLIS - MG
Fantasia:   CASA 3 IRMAOS                                   CNPJ/CPF:   19.210.889/0001-60      Rep: 22.751     Insc Estad:   5682281780045        Telefone:    (33)3423-1424            E-mail:
E-mail NF-e:    COMLTML@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016599  DROGARIA PIRES MIRANDA EIRELI              RUA INÁCIO BARROSO                384   CENTRO                          39750000 - SABINÓPOLIS - MG
Fantasia:   DROGARIA PIRES                                  CNPJ/CPF:   10.226.122/0001-54      Rep: 22.751     Insc Estad:   0010824160088        Telefone:    (33)3423-1460            E-mail:
E-mail NF-e:    PHARMAVIDA.ADM@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     05/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021619  RODRIGO JUNIOR BELARMINO                     AV. VISCONDE DO RIO BRANCO         85    CENTRO                          38190000 - SACRAMENTO - MG
Fantasia:   PEZAO CALÇADOS                                 CNPJ/CPF:   13.376.574/0001-00      Rep: 21.496     Insc Estad:   0017461700090        Telefone:    (34) 3351-3614           E-mail:
E-mail NF-e:     pezaocalcadosserra@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012560   VINICIUS DOS SANTOS RODRIGUES 14979366678   RUA CLEMENTE ARAUJO               27    CENTRO                          38190000 - SACRAMENTO - MG
Fantasia:    VINICIUS DOS SANTOS RODRIGUES                  CNPJ/CPF:   34.486.481/0001-09      Rep: 17.027     Insc Estad:   0035137790060        Telefone:    (34)3351-3944            E-mail:
E-mail NF-e:     deiasantosr@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     30/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005387  ARAUJO E DUCA COMERCIO DE CALCADOS LTDA    RUA SEBASTIAO MOREIRA DE OLIVEIA    32    CENTRO                          39560000 - SALINAS - MG
Fantasia:   ARAUJO E DUCA COMERCIO DE CALC                 CNPJ/CPF:   14.867.232/0001-56      Rep: 22.941     Insc Estad:   0018977530091        Telefone:    (38)3841-1408            E-mail:
E-mail NF-e:     sapattus10@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011896  BHZ COMERCIO E REPRESENTAÇÕES - EIRELI      RUA AQUAMARINE                    121   ALTO PARAISO                     39560000 - SALINAS - MG
Fantasia:    Guilherme Ormindo Rodrigues Fr                     CNPJ/CPF:   28.961.538/0001-81      Rep: 22.941     Insc Estad:   003.069.519/0040      Telefone:    (31)88311-1712           E-mail:
E-mail NF-e:     guilherme.ormindo@yahoo.com.brr

     Obs.:                                                           Proprietário :

Data Última Compra:     19/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004259  FERREIRA E MENDES COM DE ROUPAS E ACESS LTDA R RAUL SOARES                      65    CENTRO                          39560000 - SALINAS - MG
Fantasia:    FERREIRA E MENDES COM DE ROUPA                 CNPJ/CPF:   09.482.430/0001-61      Rep: 22.941     Insc Estad:   0010670340081        Telefone:    (38) 99152-7306          E-mail:
E-mail NF-e:     taisavitrine@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

002949  JOAO ATADEU MADUREIRA                   DA LIBERDADE                       172   CENTRO                          39560000 - SALINAS - MG
Fantasia:   JOAO ATADEU MADUREIRA                          CNPJ/CPF:   66.441.171/0001-64      Rep: 22.941     Insc Estad:   5707898380006        Telefone:    (38)3841-3682            E-mail:
E-mail NF-e:     ciadasmarcas-2012@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

005604  MARIA AMELIA DE ARAUJO                   DA LIBERDADE                       240   CENTRO                          39560000 - SALINAS - MG
Fantasia:   MARIA AMELIA DE ARAUJO                          CNPJ/CPF:   17.774.805/0001-95      Rep: 22.941     Insc Estad:   0021175720062        Telefone:    (38)3841-3570            E-mail:
E-mail NF-e:     lielumodas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017416  MARIA APARECIDA SILVA                          FREI ROGATO                        108   CENTRO                          39560000 - SALINAS - MG
Fantasia:    K-PRICHO MODAS                                  CNPJ/CPF:   07.476.552/0001-10      Rep: 22.941     Insc Estad:   570.348.809/0055      Telefone:    (38)3841-1773            E-mail:
E-mail NF-e:     kprichomodas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006957  MARLENE ALVES DE ARAUJO DUCA ME              FREI ROGATO                        128   CENTRO                          39560000 - SALINAS - MG
Fantasia:   MARLENE ALVES DE ARAUJO DUCA M                 CNPJ/CPF:   06.125.112/0001-55      Rep: 22.941     Insc Estad:   5702727580049        Telefone:    (38)3841-1794            E-mail:
E-mail NF-e:     realcemodas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016680  ANDERSON EUDES DE CARVALHO               AV GERALDO MAGELA                 125   CENTRO                          35328000 - SANTA BÁRBARA DO LESTE - MG
Fantasia:    PAR PERFEITO                                     CNPJ/CPF:   17.622.088/0001-86      Rep: 22.036     Insc Estad:   0021030730016        Telefone:    (33)99217-7562           E-mail:
E-mail NF-e:    PARPERFEITO2013@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017660  IZABEL LOPES DE SÁ                        RUA ANTÔNIO PEREIRA DA ROCHA       176   CENTRO                          35960000 - SANTA BÁRBARA - MG
Fantasia:    PARIS LOJAS                                      CNPJ/CPF:   24.379.372/0001-39      Rep: 21.495     Insc Estad:   5721082080083        Telefone:    (31)98601-1282           E-mail:
E-mail NF-e:    PARISLOJASB@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     12/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 61

Pág. 61 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

007131  TOCRIS MEL MODAS LTDA ME                  ANTONIO PEREIRA DA ROCHA           297   CENTRO                          35960000 - SANTA BÁRBARA - MG
Fantasia:    TOCRIS MEL MODAS LTDA ME                       CNPJ/CPF:   23.149.255/0001-16      Rep: 21.495     Insc Estad:   5725771240099        Telefone:    (31)3832-1433            E-mail:
E-mail NF-e:    MODAS_IDEAL@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     28/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015467  CLEBER CALCADOS LTDA                       AVENIDA BRASÍLIA                   1888  DUQUESA I (SÃO BENEDITO)         33170000 - SANTA LUZIA - MG
Fantasia:   NALVA CALCADOS                                 CNPJ/CPF:   37.414.147/0001-38      Rep: 22.500     Insc Estad:   003.754.236/0051      Telefone:    (31)3201-0770            E-mail:
E-mail NF-e:    CLEBERSALVADOR13@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010725  LGL CALCADOS ROUPAS E ACESSORIOS LTDA      AV BRASILIA 2104 LOJA C E D        SN   DUQUESA I SÃO BENDITO            33170000 - SANTA LUZIA - MG
Fantasia:    LGL CALCADOS ROUPAS E ACESSORI                 CNPJ/CPF:   32.701.650/0001-50      Rep: 22.500     Insc Estad:   0033741710040        Telefone:    (31)82707-7752           E-mail:
E-mail NF-e:     leandrodias.adm@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007692  MALU MAGAZINE COMERCIAL LTDA              AV FRANCISCO LUCINDO FOSENCA      248   NOSSA SENHORA D                 33030290 - SANTA LUZIA - MG
Fantasia:   MALU MAGAZINE COMERCIAL LTDA                   CNPJ/CPF:   71.463.855/0001-05      Rep: 22.500     Insc Estad:   5788819810070        Telefone:    (31)3641-4611            E-mail:
E-mail NF-e:     malumagazine@oi.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011300  RUN ESPORTES EIRELI                        AV BRASILIA                        2077  DUQUESA I SÃO BENEDITO           33170000 - SANTA LUZIA - MG
Fantasia:   RUN ESPORTES EIRELI                              CNPJ/CPF:   20.824.548/0002-44      Rep: 22.500     Insc Estad:   0024105660101        Telefone:    (31)637-7-7078           E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br;soterrepresentacao3@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014171   VILI BELLA CALÇADOS LTDA                   AV BRASÍLIA                        1871  SÃO BENEDITO                     33105515 - SANTA LUZIA - MG
Fantasia:    VILI BELLA                                        CNPJ/CPF:   41.771.378/0001-76      Rep: 22.482     Insc Estad:   0040356510050        Telefone:    (31)88336-6666           E-mail:
E-mail NF-e:     vivianalice777@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021594  JOÃO ANDRADE RIBEIRO DE SOUZA              PC AURELINA MOTA SANTOS            50    CENTRO                          39928000 - SANTA MARIA DO SALTO - MG
Fantasia:   JOÃO ANDRADE                                    CNPJ/CPF:   45.474.073/0001-53      Rep: 22.941     Insc Estad:   004.281.610/0022      Telefone:   99999999999             E-mail:
E-mail NF-e:     wspeedpr@gmail.com

     Obs.:                                                           Proprietário :

Condição de Pagamento:     161 60/90/120/150 DIAS
Data Última Compra:     13/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004563  JOSE RINALDO TEIXEIRA ME                    PRACA PADRE ALDERIGI               100   CENTRO                          37775000 - SANTA RITA DE CALDAS - MG
Fantasia:    JOSE RINALDO TEIXEIRA ME                        CNPJ/CPF:   26.382.580/0001-12      Rep: 21.564     Insc Estad:   151.567.600/40        Telefone:    (35)3734-1366            E-mail:
E-mail NF-e:     calcadoschaplin@gmail.com; chaplinsrc@gm

     Obs.:                                                           Proprietário :

Data Última Compra:     10/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015421  CASSIO DE MORAIS GARCIA                    AVENIDA DOS PIONEIROS              148   CENTRO                          35326000 - SANTA RITA DE MINAS - MG
Fantasia:    CASSIO DE MORAIS                                CNPJ/CPF:   12.023.201/0001-93      Rep: 22.751     Insc Estad:   0016064270020        Telefone:    (33)99391-1751           E-mail:
E-mail NF-e:    SAPATARIANOSSASENHORAAPARECIDA@BOL.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021692  CASA BRAGANÇA SR LTDA ME                  RUA ANTONIO MOREIRA DA COSTA      28    CENTRO                          37540000 - SANTA RITA DO SAPUCAÍ - MG
Fantasia:   CASA BRAGANÇA                                  CNPJ/CPF:   19.862.585/0001-87      Rep: 21.564     Insc Estad:   0023231280079        Telefone:    (35) 99893-3549          E-mail:
E-mail NF-e:     julioaleme@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021699  CELINA MARIA DE SOUZA DANTAS                  Genesio franco de moraes              1056  Centro                            38320000 - SANTA VITÓRIA - MG
Fantasia:    PE QUENTE                                       CNPJ/CPF:   08.927.237/0001-24      Rep: 21.496     Insc Estad:   0010406130019        Telefone:    (34) 3251-2193           E-mail:
E-mail NF-e:     pequentecalcadossv@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006487  KENIA CRISTINA QUIROZ ME                   AV GENESIO FRANCO DE MORAIS       949   CENTRO                          38320000 - SANTA VITÓRIA - MG
Fantasia:    KENIA CRISTINA QUIROZ ME                        CNPJ/CPF:   03.841.852/0001-08      Rep: 21.496     Insc Estad:   5980825260035        Telefone:    (34)3251-2830            E-mail:
E-mail NF-e:     alternativa_calcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004386  MARIA MARGARIDA ALVES ARAUJO-ME            GOIAS                             474   CENTRO                          38320000 - SANTA VITÓRIA - MG
Fantasia:   MARIA MARGARIDA ALVES ARAUJO-M                 CNPJ/CPF:   03.532.100/0001-57      Rep: 21.496     Insc Estad:   5980553180088        Telefone:    (34)3251-2033            E-mail:
E-mail NF-e:     margarida_andarela@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 62

Pág. 62 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

006435  JAQUELINE FERREIRA DE SOUSA ME             AV SANTANA 74 - A                SN   CENTRO                          35785000 - SANTANA DE PIRAPAMA - MG
Fantasia:    JAQUELINE FERREIRA DE SOUSA ME                  CNPJ/CPF:   17.636.769/0001-01      Rep: 21.495     Insc Estad:   0021044350016        Telefone:    (31)3717-1221            E-mail:
E-mail NF-e:     jaquelineferreira1284@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019873  WELTON RODRIGUES RIBEIRO 09656128648        Rua Francisco Mendes                 101   Centro                            36146000 - SANTANA DO GARAMBÉU - MG
Fantasia:    BELLA PRESENTES                                 CNPJ/CPF:   22.827.775/0001-78      Rep: 13.734     Insc Estad:   259.043.300/73        Telefone:    (32) 98423-9028          E-mail:
E-mail NF-e:     silma.smrp@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018605  GERALDO OLIVEIRA ABREU ME                   Rua Marjo Custodio                   75     Centro                            36940000 - SANTANA DO MANHUAÇU - MG
Fantasia:    LOJA DO GERALDINHO                              CNPJ/CPF:   01.083.485/0001-97      Rep: 13.734     Insc Estad:   5899637030036        Telefone:    (33) 99997-6533          E-mail:
E-mail NF-e:    goempreme@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004757   TJL CALCADOS LTDA                        RUA EXPEDICIONARIO GERALDO RESENDE SN   CENTRO                          35560000 - SANTO ANTÔNIO DO MONTE - MG
Fantasia:    TJL CALCADOS LTDA                               CNPJ/CPF:   04.853.597/0001-78      Rep: 21.564     Insc Estad:   6041588370058        Telefone:    (37)3281-5042            E-mail:
E-mail NF-e:     ciadospes2002@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

011005  GILDEZA MAURICIO DA SILVA - CPF 84497882691   RUA ETELVINO COSTA                 44    CENTRO                          39538000 - SANTO ANTÔNIO DO RETIRO - MG
Fantasia:    GILDEZA MAURICIO DA SILVA - CP                   CNPJ/CPF:   01.017.983/0002-12      Rep: 22.941     Insc Estad:   4339586580125        Telefone:    (38)99774-4633           E-mail:
E-mail NF-e:     genaedaniel.11@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

007328  IVAN SOARES GOMES E CIA LTDA               RUA PADRE PEDRO DOMINGUES         271   CENTRO                          35995000 - SÃO DOMINGOS DO PRATA - MG
Fantasia:    IVAN SOARES GOMES E CIA LTDA                    CNPJ/CPF:   04.055.753/0001-55      Rep: 22.036     Insc Estad:   6100979540048        Telefone:    (31)3856-1926            E-mail:
E-mail NF-e:     ivansoaresgomes@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022016   48.495.155 KALI MORAIS SILVA                 AV 12                              3220  CENTRO                          38260000 - SÃO FRANCISCO DE SALES - MG
Fantasia:    48.495.155 KALI MORAIS SILVA                     CNPJ/CPF:   48.495.155/0001-72      Rep: 21.496     Insc Estad:   004.476.828/0056      Telefone:    (34)3113-1321            E-mail:
E-mail NF-e:     kalimsilva@hotmail.com

     Obs.:                                                           Proprietário :

Condição de Pagamento:     16 30/60/90 DIAS
Data Última Compra:     24/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018991  ALIANCA COMERCIAL RIBEIRINHA LTDA             Praca Centenario                     456   Centro                            39300000 - SÃO FRANCISCO - MG
Fantasia:    ALIANCA RIBEIRINHA                               CNPJ/CPF:   24.634.313/0001-60      Rep: 13.734     Insc Estad:   6110701830001        Telefone:    (38) 3631-1265           E-mail:
E-mail NF-e:     aliancacribeirinhaltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021652  FABIO CONCEICAO ALMEIDA                      av presidente juscelino                1170  centro                            39300000 - SÃO FRANCISCO - MG
Fantasia:    POLLI ROB                                        CNPJ/CPF:   26.779.915/0001-30      Rep: 22.941     Insc Estad:   0028854900010        Telefone:    (38) 99966-6017          E-mail:
E-mail NF-e:     fabioconceicao3@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003023  GERALDA MARISTELA DE MATOS - ME             PRESIDENTE JUSCELINO KUBISTCHECK   1320  CENTRO                          39300000 - SÃO FRANCISCO - MG
Fantasia:   GERALDA MARISTELA DE MATOS - M                 CNPJ/CPF:   00.434.507/0001-53      Rep: 13.734     Insc Estad:   6119175100012        Telefone:    (38)3631-1782            E-mail:
E-mail NF-e:     geraldamaristela@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021653  JOAO PEDRO RODRIGUES VIEIRA                   pç do centenario                      434    centro                            39300000 - SÃO FRANCISCO - MG
Fantasia:    POLLI ROB                                        CNPJ/CPF:   42.582.871/0001-00      Rep: 22.941     Insc Estad:   41655930010           Telefone:    (38) 99722-6917          E-mail:
E-mail NF-e:     pollirobmatriz@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005605  MARIA APARECIDA MOTA                       PRESIDENTE JUSCELINO KUBITSCHEK    900   CENTRO                          39300000 - SÃO FRANCISCO - MG
Fantasia:    PARAISO DOS CALCADOS                           CNPJ/CPF:   02.720.843/0001-98      Rep: 22.941     Insc Estad:   6119886870011        Telefone:    (38)99769-9767           E-mail:
E-mail NF-e:    PARAISODOSCALCADOSLTDA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     25/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019859  CASA SAMPAIO BAZAR LTDA                     Rua 21de Abril                       183   Centro                            36530000 - SÃO GERALDO - MG
Fantasia:   CASA SAMPAIO                                    CNPJ/CPF:   22.567.754/0001-60      Rep: 22.619     Insc Estad:   6150691230058        Telefone:    (32) 3556-1232           E-mail:
E-mail NF-e:     sampaionfe@terra.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     27/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA




                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 63

Pág. 63 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018572  VICTOR ARCANJO CALCADOS LTDA.              BR 262 KM 426                    SN    Zona rural                         35544000 - SAO GONCALO DO PARA - MG
Fantasia:    VICTOR ARCANJO CALCADOS LTDA.                  CNPJ/CPF:   47.092.955/0001-80      Rep: 21.564     Insc Estad:   0043866580053        Telefone:    (37) 99911-2058          E-mail:
E-mail NF-e:     victorarcanjocalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

001267  B L CALCADOS E CONFECCOES LTDA             BENTO FERREIRA DOS SANTOS          68    CENTRO                          38800000 - SÃO GOTARDO - MG
Fantasia:   B L CALCADOS E CONFECCOES LTDA                 CNPJ/CPF:   23.184.062/0001-04      Rep: 21.496     Insc Estad:   6215651010025        Telefone:    (34)3671-1227            E-mail:
E-mail NF-e:     mariana1.unicontas@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     05/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003592  ADEMIAS GOMES DE FARIAS 70859191400        GERONIMO DE AGUIAR                38    CENTRO                          39430000 - SÃO JOÃO DA PONTE - MG
Fantasia:   ADEMIAS GOMES DE FARIAS 708591                 CNPJ/CPF:   22.981.082/0001-35      Rep: 13.734     Insc Estad:   0026029310062        Telefone:    (38)9105-1733            E-mail:
E-mail NF-e:     magazinelorenacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006958  CRISTIANE F DA SILVA CALCADOS E CONFECCOES ME AV GETULIO VARGAS 30 - LETRA A      30    CENTRO                          39430000 - SÃO JOÃO DA PONTE - MG
Fantasia:    CRISTIANE F DA SILVA CALCADOS                   CNPJ/CPF:   15.271.864/0001-15      Rep: 13.734     Insc Estad:   0019369910085        Telefone:    (38)91612-2320           E-mail:
E-mail NF-e:    WECALCADOS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     07/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021276  PONTE FARMA LTDA                           Rua Geronimo Aguiar                  38     Centro                            39430000 - SÃO JOÃO DA PONTE - MG
Fantasia:   PONTE FARMA                                     CNPJ/CPF:   41.056.459/0001-94      Rep: 13.734     Insc Estad:   003.987.081/0047      Telefone:    (38) 99105-1733          E-mail:
E-mail NF-e:     teapcp01@terraeagua.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015806  ANDRAVES JABER CARAZZA VIEIRA              RUA SEBASTIÃO SETTE                43    CENTRO                          36300072 - SÃO JOÃO DEL REI - MG
Fantasia:    OUTLET DOS CALCADOS                            CNPJ/CPF:   36.640.603/0001-03      Rep: 22.619     Insc Estad:   0036912880029        Telefone:    (32)99448-8145           E-mail:
E-mail NF-e:    ANDRAVES80@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     06/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018989  CAMPOS E CAMPOS COMERCIO DE ROUPAS LTDA    RUA ARTHUR BERNARDES              29     Centro                            36300076 - SÃO JOÃO DEL REI - MG
Fantasia:    ZILA CALCADOS                                   CNPJ/CPF:   10.944.605/0001-94      Rep: 22.619     Insc Estad:   0012677040042        Telefone:    (32) 3371-3174           E-mail:
E-mail NF-e:     zilaconfeccoes@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017397  CONFORT OE CALCADOS LTDA                 RUA ARTHUR BERNARDES              81    CENTRO                          36300076 - SÃO JOÃO DEL REI - MG
Fantasia:   VONFORT PE                                      CNPJ/CPF:   32.635.790/0001-78      Rep: 22.619     Insc Estad:   003.369.019/0029      Telefone:   32984495944             E-mail:
E-mail NF-e:     confort.pe.sjdr@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007001  CRIATURA CALCADOS LTDA - ME                AV PRESIDENTE TANCREDO NEVES      363   CENTRO                          36300001 - SÃO JOÃO DEL REI - MG
Fantasia:    CRIATURA CALCADOS LTDA - ME                     CNPJ/CPF:   19.550.789/0001-82      Rep: 22.619     Insc Estad:   6252946070026        Telefone:    (32)3371-7182            E-mail:
E-mail NF-e:     criaturacalcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

012317  GELS MODAS LTDA                           AVENIDA 31 DE MARÇO                1293  COLONIA DO MARCAL               36302016 - SÃO JOÃO DEL REI - MG
Fantasia:    GELS MODAS                                      CNPJ/CPF:   14.041.649/0001-65      Rep: 22.619     Insc Estad:   0018143600033        Telefone:    (32)3373-2076            E-mail:
E-mail NF-e:    GELSPEDIDOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     01/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015311  LUCKS MODAS LTDA                         RUA FREI CANDIDO                   26    FABRICAS                         36301196 - SÃO JOÃO DEL REI - MG
Fantasia:   LUCKS MODAS                                    CNPJ/CPF:   42.816.850/0001-02      Rep: 22.619     Insc Estad:   6258068970002        Telefone:    (32) 99943-8599          E-mail:
E-mail NF-e:     lojalucks@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

020058  SUPERMERCADO BERGAO LTDA                  AVENIDA SETE DE SETEMBRO           161   Matozinhos                        36305134 - SÃO JOÃO DEL REI - MG
Fantasia:    FREE VEST                                        CNPJ/CPF:   25.545.534/0001-24      Rep: 22.619     Insc Estad:   6256269710014        Telefone:    (32) 3372-2003           E-mail:
E-mail NF-e:     freevestmatriz@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020680  LAUANE PAULA SANTOS                        Av Sao Joao Batista                   409   Centro                            36918000 - SÃO JOÃO DO MANHUAÇU - MG
Fantasia:   BARATAO DAS FABRICAS                           CNPJ/CPF:   21.736.462/0001-41      Rep: 13.734     Insc Estad:   0024974570005        Telefone:    (33) 98435-8679          E-mail:
E-mail NF-e:     lauanee@live.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 64

Pág. 64 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019478  MARCIO DA CUNHA                            Rua levindo policarpo de souza         SN    Centro                            36918000 - SÃO JOÃO DO MANHUAÇU - MG
Fantasia:    BELEZA EM SEUS PES                              CNPJ/CPF:   22.656.294/0001-47      Rep: 13.734     Insc Estad:   25753630057           Telefone:    (33) 98435-4716          E-mail:
E-mail NF-e:     guilhermedamaceno232@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019173  MARIA APARECIDA DOS SANTOS RODRIGUES       Rua Vicente Salazar                   331   Centro                            36918000 - SÃO JOÃO DO MANHUAÇU - MG
Fantasia:    BEL MODAS                                       CNPJ/CPF:   27.684.283/0001-94      Rep: 13.734     Insc Estad:   002.962.080/0060      Telefone:    (33) 98437-1268          E-mail:
E-mail NF-e:     belmodas.sjm@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008351  CREUZA LIMA DE CARVALHO - ME               RUA JOSÉ TRANCOSO                 115   CENTRO                          39540000 - SÃO JOÃO DO PARAÍSO - MG
Fantasia:   CARVALHO CONFECCOES E CALCADOS                CNPJ/CPF:   01.361.543/0001-05      Rep: 22.941     Insc Estad:   6279799720001        Telefone:    (38)9980-20618           E-mail:
E-mail NF-e:     carvalho.loja@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003672  EDNA ALMEIDA DE SOUZA - ME                DR OSORIO ADRIAO DA ROCHA         433   CENTRO                          39540000 - SÃO JOÃO DO PARAÍSO - MG
Fantasia:   EDNA ALMEIDA DE SOUZA - ME                      CNPJ/CPF:   02.541.516/0001-79      Rep: 22.941     Insc Estad:   6277428210054        Telefone:    (38)3832-1349            E-mail:
E-mail NF-e:     stefaniecalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     07/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

000040  JOSE CARLOS BANDEIRA BATISTA                Av Doutor Osorio Adrião da Rocha        308   CENTRO                          39540000 - SÃO JOÃO DO PARAÍSO - MG
Fantasia:    JOSE CARLOS BANDEIRA BATISTA                    CNPJ/CPF:   16.926.813/0001-47      Rep: 22.941     Insc Estad:   0020357620020        Telefone:    (38) 99854-3740          E-mail:
E-mail NF-e:     piizanti@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     10/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

006427  JOSE FERREIRA DA ROCHA CPF 737340986-53 - ME  ANTONIO CAPUCHINHO                426   CENTRO                          39540000 - SÃO JOÃO DO PARAÍSO - MG
Fantasia:    JOSE FERREIRA DA ROCHA CPF 737                  CNPJ/CPF:   00.918.139/0001-19      Rep: 22.941     Insc Estad:   6279522590037        Telefone:    (38)99287-7094           E-mail:
E-mail NF-e:     lumar.calcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003788  EMERSON QUEIROGA CABRAL - ME               CAPITAO SEBASTIAO DA COSTA ROCHA   75    CENTRO                          39705000 - SÃO JOÃO EVANGELISTA - MG
Fantasia:   EMERSON QUEIROGA CABRAL - ME                   CNPJ/CPF:   19.723.496/0001-50      Rep: 22.751     Insc Estad:   0023099400033        Telefone:    (33)3412-1148            E-mail:
E-mail NF-e:     reidoscalcados1148@gmail

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

007129  ZECA SPORTS LTDA ME                      DUQUE DE CAXIAS 135 - LOJA          04    CENTRO                          36680000 - SAO JOAO NEPOMUCENO - MG
Fantasia:   ZECA SPORTS LTDA ME                             CNPJ/CPF:   05.385.320/0001-20      Rep: 22.619     Insc Estad:   6292067900099        Telefone:    (32)3261-1191            E-mail:
E-mail NF-e:     je.ayupe@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019401  BEATRIZ FRANCA MIRANDA                     Av Dr rossini de minas                 791   Tereza Cristina                     32920000 - SÃO JOAQUIM DE BICAS - MG
Fantasia:    BELUXE CALCADOS E ACESSORIOS                   CNPJ/CPF:   37.238.210/0001-22      Rep: 22.500     Insc Estad:   003.739.624/0026      Telefone:    (31) 99992-7718          E-mail:
E-mail NF-e:     beatrizfmirandas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016690  HANNA GRACY RIBEIRO LACERDA               RUA BOA VISTA                      43    CENTRO                          39785000 - SÃO JOSÉ DA SAFIRA - MG
Fantasia:   HANNA CALCADOS                                 CNPJ/CPF:   24.510.650/0001-45      Rep: 22.751     Insc Estad:   0027360180015        Telefone:    (33)99731-1151           E-mail:
E-mail NF-e:    ESSENCIAPERFUMARIA22@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     31/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014602  CASA PESSOA JCP LTDA                      RUA MAGALHAES PINTO               161   CENTRO                          35986000 - SÃO JOSÉ DO GOIABAL - MG
Fantasia:   CASA PESSOA                                     CNPJ/CPF:   23.128.473/0001-74      Rep: 22.036     Insc Estad:   6340648430004        Telefone:    (31) 98347-3966          E-mail:
E-mail NF-e:     casa_pessoa@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008770  ANA O GONCALVES - ME                      RUA DOUTOR SIMAO DA CUNHA         53    CENTRO                          39707000 - SÃO JOSÉ DO JACURI - MG
Fantasia:   ANA O GONCALVES - ME                            CNPJ/CPF:   21.912.126/0001-02      Rep: 22.751     Insc Estad:   6354565880065        Telefone:    (33)3433-1242            E-mail:
E-mail NF-e:     redegsjacuri@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011296   17.010.313 MARIA CLARA PERIUS               RUA CEL JOSÉ JUSTINO                812   CENTRO                          37470000 - SAO LOURENCO - MG
Fantasia:    17.010.313 MARIA CLARA PERIUS                    CNPJ/CPF:   17.010.313/0001-23      Rep: 21.564     Insc Estad:   0020437760022        Telefone:    (35)9923-3750            E-mail:
E-mail NF-e:     hlpozzato@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 65

Pág. 65 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

011295  NOVA CASA SAO LOURENCO LTDA               AV D PEDRO II                      487   CENTRO                          37470000 - SAO LOURENCO - MG
Fantasia:   NOVA CASA SCO LOUREN¿O LTDA                    CNPJ/CPF:   24.820.383/0001-02      Rep: 21.564     Insc Estad:   6370279860003        Telefone:    (35)3331-1339            E-mail:
E-mail NF-e:     novacasa487@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     08/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

019279  ANTONIO ADILSON VILARINO LEAL               Rua Professora Sarah Caldeira Brant      185   Centro                            39784000 - SÃO PEDRO DO SUAÇUÍ - MG
Fantasia:   ANTONIO ADILSON VILARINO LEAL                   CNPJ/CPF:   01.971.948/0001-57      Rep: 22.751     Insc Estad:   6404148830056        Telefone:    (33) 98883-1413          E-mail:
E-mail NF-e:     lojinhadalu@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017107  COMERCIAL ALG LTDA ME                      PRAÇA SENADOR CUPERTINO           62    CENTRO                          35360000 - SÃO PEDRO DOS FERROS - MG
Fantasia:    REALCE CALÇADOS                                 CNPJ/CPF:   04.812.002/0001-36      Rep: 22.619     Insc Estad:   6411610760006        Telefone:    (33)87099-9520           E-mail:
E-mail NF-e:    ANDRELUIZGUIMARAES@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017396  NILMA APARECIDA FARIA PEREIRA              RUA CEL JUVENTINO DIAS              6     CENTRO                          37928000 - SÃO ROQUE DE MINAS - MG
Fantasia:    FARIA MODAS                                     CNPJ/CPF:   44.442.040/0001-69      Rep: 21.564     Insc Estad:   004.211.947/0030      Telefone:   37988276567             E-mail:
E-mail NF-e:     fariamodas2021@gmail.com;nisadora488@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

008063  JULIANA E JUNIOR FERREIRA E CIA LTDA          RUA AFFONSO A PEREFIRA             499   CENTRO                          36793000 - SÃO SEBASTIÃO DA VARGEM ALEGRE - MG
Fantasia:    JULIANA E JUNIOR FERREIRA E CI                    CNPJ/CPF:   30.311.934/0001-05      Rep: 13.734     Insc Estad:   0031808750047        Telefone:    (32)84238-8833           E-mail:
E-mail NF-e:    JUNIORBICALHO23@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019074  EFIGENIA DA COSTA MONTEIRO AMARAL           Rua Conego Lafaiete                  395   Centro                            39795000 - SÃO SEBASTIÃO DO MARANHÃO - MG
Fantasia:   CONFECCOES K-LOUCURA                           CNPJ/CPF:   04.091.618/0001-65      Rep: 22.751     Insc Estad:   6451035590022        Telefone:    (33) 3432-1310           E-mail:
E-mail NF-e:     lojaodosprecosbaixos@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

015786  DTALLY MODAS LTDA                        RUA SETE SETEMBRO                 230   CENTRO                          35567000 - SÃO SEBASTIÃO DO OESTE - MG
Fantasia:    DTALLY                                           CNPJ/CPF:   10.820.414/0001-10      Rep: 21.564     Insc Estad:   116.794.900/60        Telefone:    (37)3286-1197            E-mail:
E-mail NF-e:    DTALLYMODAS@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005135  CALCE BEM CALCADOS EIRELI - EPP LJ 35         PRACA COMENDADOR JOSE HONORIO    78    CENTRO                          37950000 - SAO SEBASTIAO DO PARAISO - MG
Fantasia:    CALCE BEM LJ 35                                  CNPJ/CPF:   06.339.264/0001-50      Rep: 21.564     Insc Estad:   4712934160048        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:    NFE@KATUXA.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002910  LOJAS MICALCE LTDA                       DOUTOR PLACIDINO BRIGAGAO         2147  LAGOINHA                        37950000 - SAO SEBASTIAO DO PARAISO - MG
Fantasia:    LOJAS MICALCE LTDA                              CNPJ/CPF:   18.660.308/0001-29      Rep: 21.564     Insc Estad:   6471547730052        Telefone:    (35)3531-2134            E-mail:
E-mail NF-e:     lojasmicalce@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011258  EDNA MARIA AZEVEDO VIEIRA                 RUA JOSÉ LUIZ REZENDE              30    CENTRO                          32450000 - SARZEDO - MG
Fantasia:   EDNA MARIA AZEVEDO VIEIRA                       CNPJ/CPF:   26.686.510/0001-58      Rep: 22.500     Insc Estad:   0028771180087        Telefone:    (31)3522-9459            E-mail:
E-mail NF-e:     elianeozorio13@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

015620  ABRAHAO CARLOS GOMES                    RUA JEQUITIBA                      107   CENTRO                          35368000 - SERICITA - MG
Fantasia:   CASA GUERRA                                     CNPJ/CPF:   00.371.921/0001-60      Rep: 13.734     Insc Estad:   6639148870032        Telefone:    (31)3875-5283            E-mail:
E-mail NF-e:    ABRAHAOSERICITA@ICLOUD.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005702  JAQUELINE PEREIRA CARVALHO                 AV JOÃO MARIANO                   507   CENTRO                          38760000 - SERRA DO SALITRE - MG
Fantasia:    JAQUELINE PEREIRA CARVALHO                      CNPJ/CPF:   09.523.699/0001-49      Rep: 21.496     Insc Estad:   0010692100024        Telefone:    (34)9907-0958            E-mail:
E-mail NF-e:     jaquelinepcarvalho@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     14/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

013871  LUCIANO DE LOIOLA MELO LTDA                RUA RIO ARAGUAIA                   19    CENTRO                          39868000 - SERRA DOS AIMORÉS - MG
Fantasia:   MODA E CIA                                       CNPJ/CPF:   71.005.714/0001-30      Rep: 22.751     Insc Estad:   6688481080007        Telefone:    (33)88615-5540           E-mail:
E-mail NF-e:    GRUPOMODAECIAANA@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 66

Pág. 66 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

018868  MELO E CRUZ SERVICOS LTDA ME               R RIO ARAGUAIA                     15    CENTRO                          39868000 - SERRA DOS AIMORÉS - MG
Fantasia:   MODA E CIA                                       CNPJ/CPF:   18.025.641/0001-66      Rep: 22.751     Insc Estad:                            Telefone:    (33) 3625-1640           E-mail:
E-mail NF-e:     pedidosgrupomodaecia@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020914  ELIDA GARCIA DOS SANTOS                     Rua Joaquim Pires de Souza            103   Centro                            37143000 - SERRANIA - MG
Fantasia:    CINDERELA CALCADOS                             CNPJ/CPF:   31.941.514/0001-75      Rep: 21.564     Insc Estad:   0044257960060        Telefone:    (35) 98849-1742          E-mail:
E-mail NF-e:     cinderelacalcados2010@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

001283  CONFECCOES NUNES MESQUITA LTDA          DOM EPAMINONDAS                  48    CENTRO                          39150000 - SERRO - MG
Fantasia:   CONFECCOES NUNES MESQUITA LTDA                CNPJ/CPF:   06.172.003/0001-99      Rep: 22.941     Insc Estad:   6712808420049        Telefone:    (38)3541-2777            E-mail:
E-mail NF-e:     alternativalevi@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     07/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

006461  A ELEGANCIA LTDA - EPP                     RUA MONSENHOR MESSIAS            270   CENTRO                          35700041 - SETE LAGOAS - MG
Fantasia:   A ELEGANCIA LTDA - EPP                           CNPJ/CPF:   68.519.529/0001-50      Rep: 22.500     Insc Estad:   6728201070080        Telefone:    (31)3771-1025            E-mail:
E-mail NF-e:     elegancialtda@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

002898   GIL CALCADOS EIRELI - EPP                  MONSENHOR MESSIAS                336   CENTRO                          35700041 - SETE LAGOAS - MG
Fantasia:    GIL CALCADOS EIRELI - EPP                         CNPJ/CPF:   18.856.702/0001-37      Rep: 22.500     Insc Estad:   0022212200056        Telefone:    (31)3272-8088            E-mail:
E-mail NF-e:     amigao@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018582  LAGOA COUNTRY LTDA                         Av jose servulo soalheiro               2710  Nova cidade                       35702314 - SETE LAGOAS - MG
Fantasia:    CASSIA COUROS                                   CNPJ/CPF:   37.712.017/0001-81      Rep: 22.500     Insc Estad:   37794160049           Telefone:    (31) 99777-8525          E-mail:
E-mail NF-e:     lucasgarciadc@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019644  MODERNA CALCADOS LTDA                     Av otavio campelo ribeiro               2801  Eldorado                          35702143 - SETE LAGOAS - MG
Fantasia:   AMIGAO                                          CNPJ/CPF:   48.447.256/0001-78      Rep: 22.500     Insc Estad:   0044740340020        Telefone:    (31) 3272-8000           E-mail:
E-mail NF-e:     flavia@amigaocalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018789  RICARDO PATROCINIO DE ARAUJO                Av 3                               689   Cidade de Deus                    35703287 - SETE LAGOAS - MG
Fantasia:    REI DA MODA                                     CNPJ/CPF:   43.635.083/0001-06      Rep: 22.500     Insc Estad:   004.156.321/0088      Telefone:    (31) 3772-0742           E-mail:
E-mail NF-e:     pointcalvados7l@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021621  STUDIO JEANS                               Rua fernando pinto                    290   Centro                            35700042 - SETE LAGOAS - MG
Fantasia:   STUDIO JEANS                                    CNPJ/CPF:   44.198.635/0001-10      Rep: 22.500     Insc Estad:   41951880048           Telefone:    (31) 99538-7584          E-mail:
E-mail NF-e:     nirs@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003064  TONHO CALCADOS E BOLSAS LTDA - ME LOJA 09    MONSENHOR MESSIAS                246   CENTRO                          35700041 - SETE LAGOAS - MG
Fantasia:   TONHO CALCADOS E BOLSAS LTDA -                 CNPJ/CPF:   12.780.050/0001-18      Rep: 22.500     Insc Estad:   0016851620090        Telefone:    (31) 3772-9832           E-mail:
E-mail NF-e:     courobolsasxml@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019568  VITORIA V G RIBEIRO CALCADOS CONFORT LTDA    R conego raimundo                   270   Centro                            35700034 - SETE LAGOAS - MG
Fantasia:   MUNDO CONFORT                                  CNPJ/CPF:   50.185.020/0001-52      Rep: 22.500     Insc Estad:   004.585.997/0064      Telefone:    (31) 3153-5454           E-mail:
E-mail NF-e:     contato@mundoconfort.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     10/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022308  CLAUDINEI AZEVEDO DE SOUZA                R MINERVINA SANTOS PEREIRA         71    CENTRO                          39688000 - SETUBINHA - MG
Fantasia:    4 ESTAÇÕES                                      CNPJ/CPF:   24.727.222/0001-79      Rep: 22.941     Insc Estad:   27541770027           Telefone:    (33) 99838-7537          E-mail:
E-mail NF-e:     maria.batista.freitas@educacao.mg.gov.br

     Obs.:                                                           Proprietário :

Data Última Compra:     12/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019467  ROSEMARY AVELINO COUTINHO                  Av Governador Valadares               276   Centro                            36930000 - SIMONÉSIA - MG
Fantasia:    RANIERE CALCADOS                               CNPJ/CPF:   46.961.159/0001-73      Rep: 13.734     Insc Estad:   43780480093           Telefone:    (33) 98433-5096          E-mail:
E-mail NF-e:     avelinorose75@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 67

Pág. 67 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

007106  GS CALCADOS LTDA                         AV DA LIBERDADE                   447   CENTRO                          39550000 - TAIOBEIRAS - MG
Fantasia:   GS CALÇADOS                                     CNPJ/CPF:   07.228.394/0001-89      Rep: 22.941     Insc Estad:   6802300310049        Telefone:    (38)3845-2310            E-mail:
E-mail NF-e:     gscalcadosecia@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007365   J T CALCADOS LTDA - ME                      AV DA LIBERDADE                   463   CENTRO                          39550000 - TAIOBEIRAS - MG
Fantasia:     J T CALCADOS LTDA - ME                           CNPJ/CPF:   07.868.592/0001-07      Rep: 22.941     Insc Estad:   6809995030038        Telefone:    (38)99741-1240           E-mail:
E-mail NF-e:     jlkcalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012308  JEUSIANE BATISTA ALMEIDA                    AVENIDA DA LIBERDADE               507   CENTRO                          39550000 - TAIOBEIRAS - MG
Fantasia:    JEUSIANE BATISTA ALMEIDA                        CNPJ/CPF:   34.159.727/0001-38      Rep: 22.941     Insc Estad:   0034886060021        Telefone:    (38)99976-2116           E-mail:
E-mail NF-e:    TEOTAIO@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     03/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021601  KERO CALCADOS                                  praça joaquim teixeira                 180    centro                            39550000 - TAIOBEIRAS - MG
Fantasia:   KERO CALCADOS                                  CNPJ/CPF:   06.152.970/0001-99      Rep: 22.941     Insc Estad:   6802828580074        Telefone:    (38) 3845-1048           E-mail:
E-mail NF-e:     kerocalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018700  HILDA GALDINO DE MELO                       Rua Vereador Jose de Resende          57     Centro                            38185000 - TAPIRA - MG
Fantasia:                                                     CNPJ/CPF:   02.158.908/0001-53      Rep: 21.496     Insc Estad:   6817187200020        Telefone:    (34) 3633-1420           E-mail:
E-mail NF-e:     melomagazine@live.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

017001  BRENO OLIVEIRA BARROS                     AV AGNALDO NEIVA                   515   JARDIM DAS ACACIAS               39804006 - TEÓFILO OTONI - MG
Fantasia:   CALCADOS BARROS                                CNPJ/CPF:   42.836.152/0001-79      Rep: 22.751     Insc Estad:   0041021290009        Telefone:    (33)98625-5260           E-mail:
E-mail NF-e:    BRENOREPRESENTANTEJR@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     29/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

018791  COMERCIAL VO EUGENIA LTDA                   Av Getulio Vargas                     370   Centro                            39800015 - TEÓFILO OTONI - MG
Fantasia:    EXTRA MODAS                                     CNPJ/CPF:   34.272.247/0001-89      Rep: 22.751     Insc Estad:   0034973610038        Telefone:    (33) 99153-8023          E-mail:
E-mail NF-e:     pkamyla@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     01/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021082  CONFECCOES SOARES BRITO F21                 Av Getulio Vargas                     889   Centro                            39800015 - TEÓFILO OTONI - MG
Fantasia:    LOJAS MIB                                        CNPJ/CPF:   16.781.138/0001-05      Rep: 22.751     Insc Estad:   0020209540028        Telefone:    (33) 3522-1394           E-mail:
E-mail NF-e:     franquia21@lojasmib.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003726   ELITE CALCADOS LTDA  - ME                    FRANCISCO SA                       480   CENTRO                          39800127 - TEÓFILO OTONI - MG
Fantasia:    ELITE CALCADOS LTDA  - ME                        CNPJ/CPF:   15.652.538/0001-58      Rep: 22.751     Insc Estad:   0019729010021        Telefone:    (33)3523-2554            E-mail:
E-mail NF-e:     elitecalcados480@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     02/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

008234  GONCALVES E EMERICK LTDA                  AV SIDONIO OTONI                  653   JOAQUIM PEDROSA                 39800224 - TEÓFILO OTONI - MG
Fantasia:   BREMAVI CALCADOS                               CNPJ/CPF:   03.348.183/0001-29      Rep: 22.751     Insc Estad:   0031636260020        Telefone:    (33)88778-8391           E-mail:
E-mail NF-e:    BREMAVICALCADOS1@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     22/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

016820  LUCINEIA FERREIRA DE ALCANTARA              AV FRANCISCO SÁ                    441   CENTRO                          39800127 - TEÓFILO OTONI - MG
Fantasia:    DELLU CALCADOS                                  CNPJ/CPF:   43.291.393/0001-42      Rep: 22.751     Insc Estad:   0041314650033        Telefone:    (33)88419-9909           E-mail:
E-mail NF-e:    FALCANTARA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010994  MBC CALCADOS EIRELI                        PRACA TIRADENTES,                  10    CENTRO                          39800001 - TEÓFILO OTONI - MG
Fantasia:   MBC CALCADOS EIRELI                             CNPJ/CPF:   28.087.965/0001-82      Rep: 22.751     Insc Estad:   0029962600049        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     elizangela@katuxa.com

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021084  MIB COMERCIO DE CALCADOS LTDA F16           Av Getulio Vargas                     759   Centro                            39802014 - TEÓFILO OTONI - MG
Fantasia:    LOJAS MIB                                        CNPJ/CPF:   11.753.850/0001-87      Rep: 22.751     Insc Estad:   0015738660005        Telefone:    (33) 3523-5544           E-mail:
E-mail NF-e:     franquia16@lojasmib.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 68

Pág. 68 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020961  RICHARDSON PEREIRA DE ALMEIDA                Avenida Getulio Vargas                487   Centro                            39800015 - TEÓFILO OTONI - MG
Fantasia:    PIZALE SAPATOS                                  CNPJ/CPF:   15.196.001/0001-20      Rep: 22.751     Insc Estad:   19294920062           Telefone:    (33) 99113-8637          E-mail:
E-mail NF-e:     rei_calcados@hotmail.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     28/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003133  SAULO DANIEL GONCALVES E SOUZA - ME         EPAMINONDAS OTONI                 555   CENTRO                          39800013 - TEÓFILO OTONI - MG
Fantasia:    JHIANE CALCADOS                                 CNPJ/CPF:   06.117.999/0001-30      Rep: 22.751     Insc Estad:   6862817220004        Telefone:    (33)3529-2206            E-mail:
E-mail NF-e:    VAREJISTADOBRASIL@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

006483  SPAMER CALCADOS E ACESSORIOS LTDA ME       EPAMINONDAS OTONI                 440   CENTRO                          39800013 - TEÓFILO OTONI - MG
Fantasia:   SPAMER CALCADOS E ACESSORIOS L                 CNPJ/CPF:   24.931.881/0001-22      Rep: 22.751     Insc Estad:   0027714790016        Telefone:    (33)3523-1843            E-mail:
E-mail NF-e:     spamercalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003135  VAREJISTA DO BRASIL LTDA - ME                GETULIO VARGAS                    804   CENTRO                          39800015 - TEÓFILO OTONI - MG
Fantasia:    JHIANE CALCADOS                                 CNPJ/CPF:   18.842.740/0001-30      Rep: 22.751     Insc Estad:   6861783570015        Telefone:    (33)3521-6540            E-mail:
E-mail NF-e:    VAREJISTADOBRASIL@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

003078  GERALDO NUNES E CIA LTDA - ME                PRIMEIRO DE JANEIRO                26    CENTRO COML. ACESITA             35180032 - TIMÓTEO - MG
Fantasia:   GERALDO NUNES E CIA LTDA - ME                   CNPJ/CPF:   19.567.577/0001-08      Rep: 22.751     Insc Estad:   6874086650087        Telefone:    (31)3849-1298            E-mail:
E-mail NF-e:     gecentercalcados@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012195   GIL ALVES PEREIRA                         R SEIS DE JANEIRO                   60    CENTRO                          35180030 - TIMÓTEO - MG
Fantasia:    GIL ALVES                                        CNPJ/CPF:   07.640.511/0001-17      Rep: 22.751     Insc Estad:   3133866240031        Telefone:    (31)3848-1331            E-mail:
E-mail NF-e:    PATTYCALCADOS2009@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016416  LOJAS UNIDAS EIRELI                       RUA 31 DE MARÇO                    222   CENTRO NORTE                    35180028 - TIMÓTEO - MG
Fantasia:    OUTLET CALCADOS                                CNPJ/CPF:   19.602.580/0002-04      Rep: 22.751     Insc Estad:   6872320330193        Telefone:    (31)3669-1905            E-mail:
E-mail NF-e:    FILIALLOJASUNIDAS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     18/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018204  REGIANO ARTHUSO OLIVEIRA                  RUA JOÃO POLICARPO                 65    ANA MOURA                       35183238 - TIMÓTEO - MG
Fantasia:   ARTH CALCADOS                                  CNPJ/CPF:   32.823.954/0001-90      Rep: 22.751     Insc Estad:   0033837060063        Telefone:    (31)90708-8152           E-mail:
E-mail NF-e:    ARTHUSOCALCADOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     29/11/2022                                                                                                          Marca da Última compra :1-TERRA & AGUA

022321  SIMONE TEREZA DOS SANTOS                  R CINCO DE MAIO                    71    CENTRO                          35180036 - TIMÓTEO - MG
Fantasia:   SIMONE STORE                                    CNPJ/CPF:   40.029.418/0001-46      Rep: 22.751     Insc Estad:   39151800012           Telefone:    (31) 97173-9218          E-mail:
E-mail NF-e:     simonesantosstore87@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

018006  VITOR RODRIGUES FARIA ALMEIDA              RUA PRIMEIRO DE NOVEMBRO          115   CENTRO                          35180016 - TIMÓTEO - MG
Fantasia:   MUNDO DOS SAPATOS                              CNPJ/CPF:   44.300.294/0001-42      Rep: 22.751     Insc Estad:   0042019610060        Telefone:    (31)91158-8084           E-mail:
E-mail NF-e:    MUNDODOSSAPATOS1@OUTLOOK.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     17/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020824  MARIA LENITA DA SILVA                            Av. Presidente Antônio Carlos           722   Centro                            38880000 - TIROS - MG
Fantasia:     J.M. CALçADOS                                    CNPJ/CPF:   22.649.693/0001-80      Rep: 21.496     Insc Estad:   6897917660078        Telefone:    (34) 3853-1180           E-mail:
E-mail NF-e:     marialenita27@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     28/11/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014164  COMERCIAL NOVA TOLEDO DE CALCADOS E CONFECC PRAÇA SÃO JOSÉ                     67    CENTRO                          37630000 - TOLEDO - MG
Fantasia:   COMERCIAL NOVA TOLEDO                          CNPJ/CPF:   08.326.038/0001-60      Rep: 17.027     Insc Estad:   0010184190010        Telefone:    (11)64623-3311           E-mail:
E-mail NF-e:     comercialpedidos@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     20/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008903  DRM PINA CALCADOS EIRELI - EPP               AV GETULIO VARGAS                 136   CENTRO                          37410000 - TRÊS CORAÇÕES - MG
Fantasia:   DRM PINA CALCADOS EIRELI - EPP                   CNPJ/CPF:   28.249.409/0001-65      Rep: 21.564     Insc Estad:   0030098640070        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 69

Pág. 69 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

020942  WR DISTRIBUIDORA E INDUSTRIA TEXTIL LTDA     Av Juliao Arbex                       20     Centro                            37410109 - TRÊS CORAÇÕES - MG
Fantasia:   CENTER CALCADOS                                CNPJ/CPF:   25.369.684/0001-24      Rep: 21.564     Insc Estad:   0028082560002        Telefone:    (35) 99235-0440          E-mail:
E-mail NF-e:     rodrigo@centercalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     22/09/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

020983  COMERCIAL DE CALCADOS E VESTUARIO TRES MARIA Rua Matozinhos                      30     Centro                            39205000 - TRÊS MARIAS - MG
Fantasia:    RABELLO CALCADOS                               CNPJ/CPF:   09.686.844/0001-02      Rep: 22.941     Insc Estad:   10773390090           Telefone:    (38) 3251-2889           E-mail:
E-mail NF-e:     rabellocalcados3m@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

005443  CALCADOS TRES PONTAS LTDA - LJ 46           CONEGO VITOR                      185   CENTRO                          37190000 - TRÊS PONTAS - MG
Fantasia:   CALCADOS TRES PONTAS LTDA - LJ                  CNPJ/CPF:   13.229.221/0001-88      Rep: 21.564     Insc Estad:   0017311400090        Telefone:    (37)2101-4300            E-mail:
E-mail NF-e:     nfe@katuxa.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     25/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013776   CINTIA MARIA DE CASTRO                     TRAVESSA MARECHAL RONDÔNIA        46    CENTRO                          37190000 - TRÊS PONTAS - MG
Fantasia:    LOJA DA CINTIA                                   CNPJ/CPF:   07.330.987/0001-51      Rep: 21.564     Insc Estad:   6943346230071        Telefone:    (35)9884-61447           E-mail:
E-mail NF-e:     joaojr@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     17/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

014006  MARIA DA CONCEICAO CARVALHO DA COSTA       AV GETÚLIO VARGAS                  625   CENTRO                          35125000 - TUMIRITINGA - MG
Fantasia:    STILLUS CALCADOS                                CNPJ/CPF:   25.120.886/0001-38      Rep: 22.751     Insc Estad:   0027884390060        Telefone:    (33)98875-5421           E-mail:
E-mail NF-e:    LOJASTYLLOVIP@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     02/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

009211  JASAN CALCADOS LTDA - ME                  RUA BUENO BRANDAO                 294   SÃO CRISTOVAO                   38480000 - TUPACIGUARA - MG
Fantasia:    JASAN CALCADOS LTDA - ME                        CNPJ/CPF:   10.730.200/0001-53      Rep: 21.496     Insc Estad:   0011315150085        Telefone:    (34)3281-3931            E-mail:
E-mail NF-e:     Kaissacalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022312  CASA OLIVEIRA JOAO & JUNIOR ART DO VEST LTDA  PC DUQUE DE CAXIAS                 34    CENTRO                          39660000 - TURMALINA - MG
Fantasia:   CASA OLIVEIRA                                    CNPJ/CPF:   17.556.416/0001-93      Rep: 22.751     Insc Estad:   6973851140025        Telefone:    (38) 9906-6566           E-mail:
E-mail NF-e:     joaojoiasoliveira@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

011124  ELENICE APARECIDA ALVES COSTA - CPF 079 114 18 AV LAURO MACHADO                 177   CENTRO                          39660000 - TURMALINA - MG
Fantasia:    ELENICE APARECIDA ALVES COSTA                   CNPJ/CPF:   11.152.558/0001-09      Rep: 22.751     Insc Estad:   0014078820093        Telefone:    (38)91353-3771           E-mail:
E-mail NF-e:     lojao.bras9@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

001292  EQUILIBRIO CALCADOS E CONFECCOES LTDA      LAURO MACHADO                    162   CENTRO                          39660000 - TURMALINA - MG
Fantasia:    EQUILIBRIO CALCADOS                             CNPJ/CPF:   07.097.511/0001-12      Rep: 22.751     Insc Estad:   1233375400016        Telefone:    (33)91357-7194           E-mail:
E-mail NF-e:    EQUILIBRIOMODASECALCADOS@YAHOO.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003212  HELIO LOPES DE MACEDO - ME                  CACARATIBA                        201   CENTRO                          39660000 - TURMALINA - MG
Fantasia:    HELIO LOPES DE MACEDO - ME                      CNPJ/CPF:   66.224.296/0001-32      Rep: 22.751     Insc Estad:   6977735530010        Telefone:    (38)3527-1378            E-mail:
E-mail NF-e:     lojadamarina@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     24/01/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010058   JUNIA LOPES CARVALHO                      RUA CACARATIBA                     108   CENTRO                          39660000 - TURMALINA - MG
Fantasia:    JUNIA LOPES CARVALHO                            CNPJ/CPF:   24.064.019/0001-60      Rep: 22.751     Insc Estad:   0026953590084        Telefone:    (99)9999-9999            E-mail:
E-mail NF-e:     joseafonso65@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

020639  IMPERIO CALçADOS                                Praça Possidonio Gonçalves             11     Centro                            37496000 - TURVOLÂNDIA - MG
Fantasia:    IMPéRIO CALçADOS                                CNPJ/CPF:   48.901.281/0001-80      Rep: 21.564     Insc Estad:   45042840079           Telefone:    (35) 99753-1847          E-mail:
E-mail NF-e:     dulcebe@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     23/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021197  CALCADOS. PARAIBANAS DE UBA LTDA            Rua sao jose                         150 L 1 Centro                            36500000 - UBÁ - MG
Fantasia:    PARAIBANAS                                      CNPJ/CPF:   09.003.973/0001-59      Rep: 21.080     Insc Estad:   10407750088           Telefone:    (21) 96804-4882          E-mail:
E-mail NF-e:     paraibanasescritorio@yahoo.com

     Obs.:                                                           Proprietário :

Data Última Compra:     03/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 70

Pág. 70 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

019054   CLLEITE COMERCIO DE CALCADOS ROUPAS E ACESSO Rua Carlos Peixoto Filho                191   Centro                            36500097 - UBÁ - MG
Fantasia:    BLISS                                            CNPJ/CPF:   46.189.637/0001-79      Rep: 13.734     Insc Estad:   004.328.638/0083      Telefone:    (32) 3533-0874           E-mail:
E-mail NF-e:     bliss.uba2022@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019867   LUIZ ANTONIO DE OLIVEIRA                     Rua Ines Guiducci                    02     Ponte Preta                        36503136 - UBÁ - MG
Fantasia:   HP MODAS                                        CNPJ/CPF:   31.289.261/0001-05      Rep: 13.734     Insc Estad:   32583000004           Telefone:    (31) 99919-8170          E-mail:
E-mail NF-e:     luizoliveira@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019151  CARLOS F OLIVEIRA CONFECCOES LTDA           AV PADRE RINO                      962   CENTRO                          35338000 - UBAPORANGA - MG
Fantasia:   RENAN E RAYSSA CONFESSOES                      CNPJ/CPF:   45.289.670/0001-08      Rep: 22.751     Insc Estad:   004.269.867/0045      Telefone:    (33) 332-3-1471          E-mail:
E-mail NF-e:     magnerlucas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

014698  PRATICA CALCADOS LTDA                      AVENIDA CRISTIANO ROCAS            103   CENTRO                          36500017 - UBÁ - MG
Fantasia:    PRATICA CALCADOS                                CNPJ/CPF:   23.481.679/0001-83      Rep: 13.734     Insc Estad:   0026446710089        Telefone:    (37)91696-6038           E-mail:
E-mail NF-e:     marina@ondacalcados.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/10/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

019875  WELINGTON JUNIOR DURSO                     Rua Oseas Maranhao                  200   Oseas Maranhao                    36500000 - UBÁ - MG
Fantasia:   WELINGTON JUNIOR DURSO                         CNPJ/CPF:   27.782.256/0001-54      Rep: 13.734     Insc Estad:   29701430026           Telefone:    (32) 3531-5034           E-mail:
E-mail NF-e:     celmadorso@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

021599  ADILSON SEGAVA                                AV. UMUARAMA                      113   VALINHO DE MELO                  38037490 - UBERABA - MG
Fantasia:   NAYARA MODAS                                   CNPJ/CPF:   71.342.158/0001-98      Rep: 21.496     Insc Estad:   7019830450083        Telefone:    (34) 3321-6407           E-mail:
E-mail NF-e:    nayaramodas01@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     22/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009370  ATALIBA CUNHA DE FREITAS C P F 406413336 68 - M RUA SCO BENEDITO                   534   SÃO BENEDITO                     38022100 - UBERABA - MG
Fantasia:    ATALIBA CUNHA DE FREITAS C P F                   CNPJ/CPF:   17.715.137/0001-25      Rep: 21.496     Insc Estad:   7013861890071        Telefone:    (34)3312-5930            E-mail:
E-mail NF-e:     passonobre@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

013863  CALDONO CONFECCOES LTDA                  AV RAMID MAUAD                    94    RESIDENCIAL MORUMBI             38051131 - UBERABA - MG
Fantasia:   CALDONO CONFECCOES LTDA                       CNPJ/CPF:   17.730.793/0001-05      Rep: 21.496     Insc Estad:   0021132250056        Telefone:    (34)98059-9046           E-mail:
E-mail NF-e:     estacaomodas04@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

005205  EDNEY DEIRSON NICODEMOS EPP               RUA SEGISMUNDO CARLOS FERREIRA    432   PARQUE DAS AMÉRICAS             38045350 - UBERABA - MG
Fantasia:   FASHION CALÇADOS                               CNPJ/CPF:   14.158.199/0001-95      Rep: 21.496     Insc Estad:   0018259480026        Telefone:    (34)3311-7687            E-mail:
E-mail NF-e:     fashioncalçados8@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

015127  ELAINE CRISTINA VAZ URZEDO 03198198682      RUA GOIAS,                         657   SANTA MARIA                      38050060 - UBERABA - MG
Fantasia:    ELAINE CRISTINA VAZ URZEDO 031                  CNPJ/CPF:   35.067.068/0001-72      Rep: 21.496     Insc Estad:   0035602800077        Telefone:    (61) 986-126518          E-mail:
E-mail NF-e:     elaine.urzedovaz@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     09/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

013864   JABITANI RIBEIRO                           AV RAMID MAUAD                    401   PACAEMBU II                      38051570 - UBERABA - MG
Fantasia:    JABITANI RIBEIRO                                 CNPJ/CPF:   16.608.703/0001-37      Rep: 21.496     Insc Estad:   0020045600074        Telefone:    (34)3321-6568            E-mail:
E-mail NF-e:    JABITANIRIBEIRO@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021607  MAYSA DE SOUZA                                AV. PRUDENTE DE MORAES             344   NOSSA SENHORA DA ABADIA         38026250 - UBERABA - MG
Fantasia:   ESPAÇO 7                                         CNPJ/CPF:   33.457.430/0001-96      Rep: 21.496     Insc Estad:   003.431.772/0000      Telefone:    (34) 3316-0260           E-mail:
E-mail NF-e:     espaco7calcados@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     19/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

015563  SAFIRA CALÇADOS LTDA                     RUA ARTUR MACHADO                 500   CENTRO                          38010020 - UBERABA - MG
Fantasia:    SAFIRA CALÇADOS LTDA                            CNPJ/CPF:   38.280.364/0001-45      Rep: 21.496     Insc Estad:   0038258110004        Telefone:    (34)3325-8322            E-mail:
E-mail NF-e:    LEOCALCADOS02@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     20/01/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 71

Pág. 71 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

005201  A&A SHOES CALCADOS EIRELI                  FLORIANO PEIXOTO                   623   CENTRO                          38400102 - UBERLANDIA - MG
Fantasia:   A&A SHOES CALCADOS EIRELI                       CNPJ/CPF:   03.759.114/0001-08      Rep: 21.496     Insc Estad:   7020770760091        Telefone:    (34) 323-5-8505          E-mail:
E-mail NF-e:     reisangelocomercial@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

014004  AQUI VESTES CALCADOS E CONFECCOES EIRELI    AV FRANCISCO RIBEIRO               2409  SEGISMUNDO PEREIRA              38406191 - UBERLANDIA - MG
Fantasia:    AQUI VESTES CALCADOS E CONFECC                 CNPJ/CPF:   00.312.093/0001-90      Rep: 21.496     Insc Estad:   7029071890067        Telefone:    (34)3216-3841            E-mail:
E-mail NF-e:    AQUIVESTE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     23/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021552  ATACADAO DO CALCADO LTDA                      Av:Jose Fonseca e Silva                608    Luizote de freitas                   38414073 - UBERLANDIA - MG
Fantasia:   CASA DO CALCADO                                CNPJ/CPF:   54.330.671/0001-40      Rep: 21.496     Insc Estad:   0048461750047        Telefone:    (34) 9197-5999           E-mail:
E-mail NF-e:     comercialcasadocalcado@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     27/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021830  CALCADOS E CONFECCOES ACLIMACAO            Rua Luiz Ferreira da fonseca            385   Aclimacao                         38406013 - UBERLANDIA - MG
Fantasia:    LOJA ACLIMACAO                                  CNPJ/CPF:   04.096.840/0001-50      Rep: 21.496     Insc Estad:   7021142980040        Telefone:    (34) 3226-9310           E-mail:
E-mail NF-e:     lojaaclimacao@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     23/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018195  CARLA DINIZ BELLORE                       RUA CLEZIO MIGUELETO              554   PRESIDENTE ROOSEVELT             38401040 - UBERLANDIA - MG
Fantasia:   CARLA DINIZ                                      CNPJ/CPF:   13.113.858/0001-04      Rep: 21.496     Insc Estad:   0017194270064        Telefone:    (34)3215-4512            E-mail:
E-mail NF-e:    CARLABELLORE@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     05/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

012050  CASA ALVES MAGAZINE                      RUA DOUTOR MANOEL THOMAZ TEIXEIRA D1025  TOCANTINS                       38415270 - UBERLANDIA - MG
Fantasia:   CASA ALVES                                      CNPJ/CPF:   01.873.111/0001-75      Rep: 21.496     Insc Estad:   7026747730080        Telefone:    (34)- 99-229-9333        E-mail:
E-mail NF-e:     orlando2813@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     04/03/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021545   ELINEIA LEMES GONDIM                            Av.Raulino cotta pacheco,1167          1167  Martins                           38400372 - UBERLANDIA - MG
Fantasia:   ZOUK MODAS                                     CNPJ/CPF:   45.243.472/0001-03      Rep: 21.496     Insc Estad:   004.266.701/0086      Telefone:    (34) 99973-4977          E-mail:
E-mail NF-e:     elineialemes0107@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009761  GISLAYNNE SILVA SANTOS 10353544620          AVENIDA JERUSALEM                  985   JARDIM CANAA                     38412392 - UBERLANDIA - MG
Fantasia:    GISLAYNNE SILVA SANTOS 1035354                  CNPJ/CPF:   34.259.401/0001-82      Rep: 21.496     Insc Estad:   0034963310074        Telefone:    (34)9928-25761           E-mail:
E-mail NF-e:     gislaynni_2012@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     15/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021660  HELENA RAMIRES PEREIRA                      Av Jose Abdulmassih                  1387  Shopping park                     38425565 - UBERLANDIA - MG
Fantasia:    VALENCE SHOES                                   CNPJ/CPF:   44.575.237/0001-76      Rep: 21.496     Insc Estad:   0042213190038        Telefone:    (34) 9878-1010           E-mail:
E-mail NF-e:     h.elena_ramires@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     04/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017208  JOSE MARIA ALVES ME                        AV SOLIDARIEDADE                   575   INTEGRACAO                      38407030 - UBERLANDIA - MG
Fantasia:    JOSE MARIA ALVES ME                             CNPJ/CPF:   10.821.083/0001-33      Rep: 21.496     Insc Estad:   0011684310040        Telefone:    (34)98942-2989           E-mail:
E-mail NF-e:    MODAS_KK@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     06/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007315  JOSE RIBEIRO DE SOUZA - ME                 COMETA                            49    JARDIM BRASILIA                   38401434 - UBERLANDIA - MG
Fantasia:    JOSE RIBEIRO DE SOUZA - ME                       CNPJ/CPF:   21.654.421/0003-78      Rep: 21.496     Insc Estad:   7024827890227        Telefone:    (34)3087-0532            E-mail:
E-mail NF-e:     lojassouza2015@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011211   LINARI COMERCIO DE CALCADOS LTDA           AV JOÃO BERNARDES DE SOUZA        420   PRESIDENTE ROOSEVELT             38401016 - UBERLANDIA - MG
Fantasia:    LINARI COMERCIO DE CALCADOS LT                  CNPJ/CPF:   32.510.401/0001-88      Rep: 21.496     Insc Estad:   0033589400021        Telefone:    (34)91924-4161           E-mail:
E-mail NF-e:     lillysapapatilhas@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     21/10/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021616  LOJA DOMINGUES E RIBEIRO LTDA               Rua Simao Pedro                     427    Maravillha                         38401476 - UBERLANDIA - MG
Fantasia:    LOJA FERNANDO                                   CNPJ/CPF:   64.378.359/0001-80      Rep: 21.496     Insc Estad:   7026911420050        Telefone:    (34) 3215-2085           E-mail:
E-mail NF-e:     lojafernando@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 72

Pág. 72 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

021598  LOJA FABRI LTDA                                  Praca sao Francisco de Paula            40     Tubalina                          38412048 - UBERLANDIA - MG
Fantasia:    LOJA FABRI                                       CNPJ/CPF:   00.945.300/0001-43      Rep: 21.496     Insc Estad:   7029527750068        Telefone:    (34) 3238-1411           E-mail:
E-mail NF-e:     michelealineribeiro@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009637  LOJAS CEVAL LTDA - ME                       AVENIDA AFONSO PENA               162   MINAS GERAIS                     38405308 - UBERLANDIA - MG
Fantasia:    LOJAS CEVAL LTDA - ME                            CNPJ/CPF:   03.398.978/0001-41      Rep: 21.496     Insc Estad:   7020443580015        Telefone:    (34)3235-3188            E-mail:
E-mail NF-e:     lojaspassocertoltda@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     20/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

017240  LOJAS PASSO CERTO LTDA                     AV JOAO PESSOA                     99    MARTINS                         38400338 - UBERLANDIA - MG
Fantasia:    LOJAS PASSO CERTO LTDA                          CNPJ/CPF:   01.468.881/0001-32      Rep: 21.496     Insc Estad:   7029850500051        Telefone:    (34)3235-2007            E-mail:
E-mail NF-e:    PASSOCERTOJOAOPESSOA@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     11/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

004446  LUCIENE APARECIDA ALVES PEREIRA ME          AV JERUSALEM 267 267 -           SN   CANAA                           38412392 - UBERLANDIA - MG
Fantasia:    LUCIENE APARECIDA ALVES PEREIR                  CNPJ/CPF:   06.540.559/0001-90      Rep: 21.496     Insc Estad:   7023027580095        Telefone:    (34)3257-2604            E-mail:
E-mail NF-e:     atualkids_modas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     05/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021566  MAGAZINE DA MODA LTDA                      Av Dom pedro II                     1511   Alto umuarama                     38405280 - UBERLANDIA - MG
Fantasia:   MAGAZINE DA MODA                               CNPJ/CPF:   33.916.154/0001-87      Rep: 21.496     Insc Estad:   0034690410054        Telefone:    (34) 99178-2711          E-mail:
E-mail NF-e:     danielyverri@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     31/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008835  MAGAZINE MARIANA MODAS LTDA - EPP          AV FLORIANO PEIXOTO               317   CENTRO                          38400100 - UBERLANDIA - MG
Fantasia:   MAGAZINE MARIANA MODAS LTDA -                  CNPJ/CPF:   10.994.851/0001-50      Rep: 19.689     Insc Estad:   0013072150036        Telefone:    (34)3224-4214            E-mail:
E-mail NF-e:     chohfiuberlandia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021949  MARIA APARECIDA RODRIGUES                  San marino                          347   Jardim europa                      38414554 - UBERLANDIA - MG
Fantasia:   PACTUS MODAS                                   CNPJ/CPF:   07.012.634/0001-03      Rep: 21.496     Insc Estad:   7023337160000        Telefone:    (34) 3236-9892           E-mail:
E-mail NF-e:     pactusmodas@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

009237  MARTA REGINA ARAUJO MUNDIM SILVA 46047735649 AV SEGISMUNDO PEREIRA             824   SANTA MONICA                    38408170 - UBERLANDIA - MG
Fantasia:   MARTA REGINA ARAUJO MUNDIM SIL                 CNPJ/CPF:   25.034.272/0001-33      Rep: 21.496     Insc Estad:   0027804920032        Telefone:    (34)2589-2379            E-mail:
E-mail NF-e:    MARTAMUNDIM@YAHOO.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     20/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021496  MAURO ALEXANDRE REPRESENTACOES LTDA       RUA ANTÔNIO ZEFERINO DE PAULA      661   SANTA MÔNICA                    38408270 - UBERLANDIA - MG
Fantasia:   MAURO ALEXANDRE REPRESENTACOES               CNPJ/CPF:   02.387.554/0001-19      Rep: 21.496     Insc Estad:                            Telefone:    (34)9910-26181           E-mail:
E-mail NF-e:     daduscon@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     17/04/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021729  MTB COMERCIO LTDA                          Av espanha                          1397   Tibery                            38405048 - UBERLANDIA - MG
Fantasia:    TUTTIPE                                          CNPJ/CPF:   52.471.226/0001-74      Rep: 21.496     Insc Estad:   004.733.213/0092      Telefone:    (34) 9111-8081           E-mail:
E-mail NF-e:     financeiro@tuttipe.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     13/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009886   PERFIL MODAS UBERLANDIA LTDA               AV FERNANDO VILELA                832   MARTINS                         38400456 - UBERLANDIA - MG
Fantasia:    PERFIL MODAS UBERLANDIA LTDA                   CNPJ/CPF:   38.462.354/0001-20      Rep: 21.496     Insc Estad:   7026516600040        Telefone:    (34)3235-1976            E-mail:
E-mail NF-e:     perfilmodasltda@outlook.com

     Obs.:                                                           Proprietário :

Data Última Compra:     24/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021551  PITANGA ACESSORIOS E CIA LTDA                 Avenida Jose Fonseca e Silva            506    Luizote de freitas                   38414348 - UBERLANDIA - MG
Fantasia:    PITANGA                                          CNPJ/CPF:   09.175.991/0001-18      Rep: 21.496     Insc Estad:   0010506800075        Telefone:    (34) 3210-5006           E-mail:
E-mail NF-e:     pitangacalcadosudia@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/02/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

017012  ROTACAO REPRESENTACOES LTDA              RUA DOLORITA ELIAS DO NASCIMENTO   787   VIVIANE ( LOTEAMENTO )            38410038 - UBERLANDIA - MG
Fantasia:   ROTACAO REPRESENTACOES LTDA                   CNPJ/CPF:   41.261.483/0001-65      Rep: 21.496     Insc Estad:   0042228920088        Telefone:    (34)98193-3487           E-mail:
E-mail NF-e:    LEYDIANEDEE@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     24/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 73

Pág. 73 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

015584  SAPATARIA MINAS BRASIL LTDA                   AV. AFONSO PENA                    594   CENTRO                          38400130 - UBERLANDIA - MG
Fantasia:   KAZZUAZZE                                       CNPJ/CPF:   10.626.944/0001-22      Rep: 19.033     Insc Estad:   0011085470008        Telefone:    (34)3224-4846            E-mail:
E-mail NF-e:    KAZZUFINANCEIRO@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     10/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

022310  TERCEIRO MILENIO CONFECCOES E CALCADOS LTDA AV CONTINENTAL                     637   PARQUE DAS PAINEIRAS             38402263 - UBERLANDIA - MG
Fantasia:    TERCEIRO MILENIO                                CNPJ/CPF:   22.134.332/0001-00      Rep: 21.496     Insc Estad:   7020612130062        Telefone:    (34) 3255-7946           E-mail:
E-mail NF-e:     terceiro.milenio@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     13/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

021550  UBERLOJAS TEODORO LTDA                     Rua estrela dalva                     859   Jardim brasilia                     38401428 - UBERLANDIA - MG
Fantasia:    LOJAS TEODORO                                   CNPJ/CPF:   26.321.331/0001-17      Rep: 21.496     Insc Estad:   702.651.523/0045      Telefone:    (34) 3215-3494           E-mail:
E-mail NF-e:     lojasteodoro@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007796  UNIAO COMERCIO DE CALCADOS E ARTIGOS ESPORT AV AFONSO PENA                    599   CENTRO                          38400130 - UBERLANDIA - MG
Fantasia:   SAVAN CALÇADOS                                 CNPJ/CPF:   26.645.758/0001-70      Rep: 21.496     Insc Estad:   0028734560068        Telefone:    (62)3521-9900            E-mail:
E-mail NF-e:    NFE@SAVAN.COM.BR

     Obs.:                                                           Proprietário :

Data Última Compra:     21/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

008977  VALDILENE ALVES PEREIRA - ME                AV SILVIO RUGANI 600 LOJA A       SN    TUBALINA                         38412026 - UBERLANDIA - MG
Fantasia:    VALDILENE ALVES PEREIRA - ME                     CNPJ/CPF:   04.935.270/0001-45      Rep: 21.496     Insc Estad:   7021673980083        Telefone:    (34)3238-3462            E-mail:
E-mail NF-e:     valdilene_criatiano@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/05/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021686  VANESSA SILVA FERREIRA                      Av Floriano Peixoto                    810   Centro                            38400100 - UBERLANDIA - MG
Fantasia:   VANESSA SIMARRO                                CNPJ/CPF:   31.528.181/0001-57      Rep: 21.496     Insc Estad:   0032775030068        Telefone:    (34) 9898-3680           E-mail:
E-mail NF-e:     wanessa.simarro@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     10/03/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

010384  VELHO OESTE CALCADOS EIRELI                AV FLORIANO PEIXOTO               703   CENTRO                          38400102 - UBERLANDIA - MG
Fantasia:   VELHO OESTE CALCADOS EIRELI                     CNPJ/CPF:   03.520.823/0001-36      Rep: 21.496     Insc Estad:   7020613120060        Telefone:    (34)3235-8505            E-mail:
E-mail NF-e:     reisangelocomercial@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     26/08/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

010028  VESTE LIVRE CALCADOS E CONFECCOES LTDA      RUA DOS TAROIS                     190   TAIAMAN                         38415069 - UBERLANDIA - MG
Fantasia:    VESTE LIVRE CALCADOS E CONFECC                 CNPJ/CPF:   02.342.963/0001-07      Rep: 21.496     Insc Estad:   7027299180040        Telefone:    (34)3283-4573            E-mail:
E-mail NF-e:     taiaman@vestelivremg.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/07/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

004573  RONALDO RODRIGUES ALVARES                AV GOVERNADOR VALADARES 920 920 - SN   CENTRO                          38610000 - UNAÍ - MG
Fantasia:   RONALDO RODRIGUES ALVARES                     CNPJ/CPF:   19.923.531/0001-84      Rep: 22.941     Insc Estad:   7044162860026        Telefone:    (38)3676-2453            E-mail:
E-mail NF-e:     fabriciodemelo10@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/04/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

011200  CENTER CALCADOS DE URUCANIA LTDA          RUA DONA FRANCISCA                76    CENTRO                          35380000 - URUCÂNIA - MG
Fantasia:   CENTER CALCADOS                                CNPJ/CPF:   26.025.689/0001-00      Rep: 22.619     Insc Estad:   002.819.247/0067      Telefone:    (31)85297-7448           E-mail:
E-mail NF-e:     center.calcado2018@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/08/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

022201  MARIA DAS GRACAS BRUM DA SILVEIRA          RUA PROF MANOEL RUFINO             42    CENTRO                          35380000 - URUCÂNIA - MG
Fantasia:    LOJA DA GRACINHA                                CNPJ/CPF:   01.428.045/0001-24      Rep: 22.619     Insc Estad:   7051977380060        Telefone:    (31) 98375-6069          E-mail:
E-mail NF-e:     chichicocarvalho@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     29/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

019239  JOSE IVANIR PEREIRA                          Av Justiniano dos Reis                 2303  Sion                             37048000 - VARGINHA - MG
Fantasia:    LU CALçADOS                                     CNPJ/CPF:   07.544.051/0001-23      Rep: 21.564     Insc Estad:   7073753790010        Telefone:    (35) 3223-1010           E-mail:
E-mail NF-e:     lu.calcados1010@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     06/03/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

003154  NEW 33 CALCADOS LTDA - ME                 DOUTOR WENCESLAU BRAZ            222   CENTRO                          37002080 - VARGINHA - MG
Fantasia:   NEW 33 CALCADOS LTDA - ME                       CNPJ/CPF:   05.305.980/0001-54      Rep: 21.564     Insc Estad:   6931927110022        Telefone:    (35)3221-3786            E-mail:
E-mail NF-e:     financeironew33@bol.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     29/05/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt


## Página 74

Pág. 74 de 74
                                                           TERRA E AGUA INDUSTRIA DE CALÇADOS S.A.


                                                                Relatório de Colaboradores




Colaborador                                         Logradouro                       Nr Bairro                                    CEP / Cidade / UF

003159  OUTLET 35 CALCADOS EIRELI                  RUA DELFIM MOREIRA 535 LOJA        05    CENTRO                          37002070 - VARGINHA - MG
Fantasia:    OUTLET 35 CALCADOS EIRELI                       CNPJ/CPF:   17.110.967/0001-29      Rep: 21.564     Insc Estad:   0020529930013        Telefone:    (35)3222-8033            E-mail:
E-mail NF-e:     vhc67@protonmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     12/09/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

018933  SEBASTIAO FERREIRA DE QUEIROZ               Rua Tomaz Antonio Gonzaga            174    Pinlar I                           39260000 - VARZEA DA PALMA - MG
Fantasia:    SABRINA CALCADOS                               CNPJ/CPF:   33.318.652/0001-28      Rep: 22.941     Insc Estad:   003.421.566/0084      Telefone:    (38) 99905-6108          E-mail:
E-mail NF-e:     sebastiaofcalcados@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     08/02/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016494  DUOPASSOS DISTRIBUIDORA DE CALCADOS LTDA   Rua Um                            245   Nova Pampulha                    33203440 - VESPASIANO - MG
Fantasia:   DUOPASSOS                                      CNPJ/CPF:   32.808.994/0001-63      Rep: 22.500     Insc Estad:   0033825420060        Telefone:    (31)98535-1344           E-mail:
E-mail NF-e:    FINANCEIROS.DUOPASSOS@GMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     03/01/2023                                                                                                          Marca da Última compra :12-DUO PASSOS

021682  MAZIZA CALCADOS                            Rua sessenta                        94    Nova pampulha                    33203460 - VESPASIANO - MG
Fantasia:   MAZIZA                                          CNPJ/CPF:   52.116.197/0001-22      Rep: 22.500     Insc Estad:   004.710.285/0042      Telefone:    (31) 99617-7677          E-mail:
E-mail NF-e:     mazizaps@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     11/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

007693  VESPA MODAS E CONFECCOES LTDA - MTZ        AV EXISTENTE                       1179  MORRO ALTO                      33200000 - VESPASIANO - MG
Fantasia:    VESPA MODAS E CONFECCOES LTDA                 CNPJ/CPF:   07.453.372/0001-12      Rep: 22.500     Insc Estad:   7123482010047        Telefone:    (31)3621-7045            E-mail:
E-mail NF-e:     maluesporte@hotmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     16/02/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

004774  COMERCIAL DELMO LTDA ME                   TRAVESSA SAGRADOS CORACOES       51    CENTRO                          36570000 - VICOSA - MG
Fantasia:   COMERCIAL DELMO LTDA ME                        CNPJ/CPF:   24.592.762/0001-92      Rep: 22.619     Insc Estad:   0027431330090        Telefone:    (31)3892-3494            E-mail:
E-mail NF-e:     calcadosdelmo@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     03/07/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA

021103  ESPACO CALCADOS LTDA                       Rua Arthur Bernardes                 95     Centro                            36570061 - VICOSA - MG
Fantasia:   ESPACO CALCADOS                                CNPJ/CPF:   23.862.454/0001-77      Rep: 22.619     Insc Estad:   0026772260015        Telefone:    (31) 98898-4314          E-mail:
E-mail NF-e:     grupoavs@gmail.com

     Obs.:                                                           Proprietário :

Data Última Compra:     14/12/2023                                                                                                          Marca da Última compra :1-TERRA & AGUA

016168  EDINEIDE ALVES DOS SANTOS                  AV PRESIDENTE CASTELO BRANCO       283   CENTRO                          39630000 - VIRGEM DA LAPA - MG
Fantasia:   NETO CALCADOS                                  CNPJ/CPF:   23.291.967/0001-75      Rep: 22.941     Insc Estad:   0026287460083        Telefone:    (33)88593-3338           E-mail:
E-mail NF-e:    NETO.008@HOTMAIL.COM

     Obs.:                                                           Proprietário :

Data Última Compra:     30/01/2025                                                                                                          Marca da Última compra :1-TERRA & AGUA

009341  LUCIO E LUCIO LTDA - EPP                     PRACA JOÃO RODRIGUES              80    CENTRO                          39730000 - VIRGINOPOLIS - MG
Fantasia:    LUCIO E LUCIO LTDA - EPP                          CNPJ/CPF:   25.974.775/0001-99      Rep: 22.751     Insc Estad:   7180729920045        Telefone:    (33)3414-1100            E-mail:
E-mail NF-e:     luciocoelhovgp@yahoo.com.br

     Obs.:                                                           Proprietário :

Data Última Compra:     18/06/2024                                                                                                          Marca da Última compra :1-TERRA & AGUA



Total de Registros             958





                            Senda - Sistema de Engenharia                                            ticliente                                               27/10/2025    14:52:56
                                      de Dados
                                                                                                                                                     CAD_01_26R01.rpt
